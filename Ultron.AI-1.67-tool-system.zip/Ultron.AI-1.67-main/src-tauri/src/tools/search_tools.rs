// Search and dependency-inspection tools. Both are plain, dependency-free
// implementations (no external crates like `walkdir`/`grep` pulled in) —
// consistent with this codebase's "small binary, low-power target
// hardware" stance (see the [profile.release] comment in Cargo.toml).

use std::fs;
use std::path::Path;

use serde_json::{json, Value};

use super::workspace::{resolve_within, WorkspaceRecord};
use super::{RiskLevel, Tool, ToolCategory, ToolContext, ToolError, ToolOutput, ToolParam, ToolSpec};

const SKIP_DIRS: &[&str] = &[
    ".git",
    "node_modules",
    "target",
    "dist",
    "build",
    ".next",
    ".venv",
    "venv",
    "__pycache__",
    ".turbo",
    "coverage",
    ".cache",
];

// Extensions worth opening as text for search. Skips binaries, images,
// lockfiles-that-are-huge-and-noisy, etc.
const SEARCHABLE_EXTS: &[&str] = &[
    "rs", "ts", "tsx", "js", "jsx", "json", "toml", "md", "css", "html", "py", "go", "java",
    "kt", "swift", "c", "h", "cpp", "hpp", "cs", "rb", "php", "sql", "yaml", "yml", "sh", "txt",
];

const MAX_FILE_SCAN_BYTES: u64 = 1024 * 1024; // 1MB per file
const MAX_MATCHES: usize = 200;
const MAX_FILES_SCANNED: usize = 6000;

// ---- search_code ------------------------------------------------------

pub struct SearchCodeTool;

#[async_trait::async_trait]
impl Tool for SearchCodeTool {
    fn spec(&self) -> ToolSpec {
        ToolSpec {
            id: "search_code",
            name: "Search code",
            description: "Case-insensitive substring search across text files in the workspace. Returns matching file paths, line numbers, and the matching line.",
            category: ToolCategory::Search,
            risk: RiskLevel::Safe,
            params: vec![
                ToolParam { name: "query", kind: "string", description: "Text to search for.", required: true },
                ToolParam { name: "path", kind: "string", description: "Restrict the search to this subdirectory (relative to the workspace root). Omit to search the whole workspace.", required: false },
            ],
        }
    }

    async fn call(&self, ctx: &ToolContext<'_>, args: &Value) -> Result<ToolOutput, ToolError> {
        let query = args
            .get("query")
            .and_then(Value::as_str)
            .ok_or_else(|| ToolError::InvalidArgs("query is required".into()))?;
        if query.trim().is_empty() {
            return Err(ToolError::InvalidArgs("query must not be empty".into()));
        }
        let rel = args.get("path").and_then(Value::as_str).unwrap_or("");
        let start = if rel.is_empty() {
            ctx.workspace.root.clone()
        } else {
            resolve_within(ctx.workspace, rel, true)?
        };

        let query_lower = query.to_lowercase();
        let mut matches: Vec<Value> = Vec::new();
        let mut files_scanned = 0usize;
        search_dir(&start, &ctx.workspace.root, &query_lower, &mut matches, &mut files_scanned);

        let truncated = matches.len() >= MAX_MATCHES || files_scanned >= MAX_FILES_SCANNED;
        let summary = format!(
            "{} match(es) for \"{query}\" across {files_scanned} file(s){}",
            matches.len(),
            if truncated { " (truncated)" } else { "" }
        );
        Ok(ToolOutput::new(summary, json!({ "query": query, "matches": matches, "truncated": truncated })))
    }
}

fn search_dir(
    dir: &Path,
    workspace_root: &Path,
    query_lower: &str,
    matches: &mut Vec<Value>,
    files_scanned: &mut usize,
) {
    if matches.len() >= MAX_MATCHES || *files_scanned >= MAX_FILES_SCANNED {
        return;
    }
    let entries = match fs::read_dir(dir) {
        Ok(e) => e,
        Err(_) => return,
    };
    let mut children: Vec<_> = entries.filter_map(|e| e.ok()).collect();
    children.sort_by_key(|e| e.file_name());

    for entry in children {
        if matches.len() >= MAX_MATCHES || *files_scanned >= MAX_FILES_SCANNED {
            return;
        }
        let path = entry.path();
        let name = entry.file_name().to_string_lossy().to_string();

        if path.is_dir() {
            if SKIP_DIRS.contains(&name.as_str()) {
                continue;
            }
            search_dir(&path, workspace_root, query_lower, matches, files_scanned);
            continue;
        }

        let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("");
        if !SEARCHABLE_EXTS.contains(&ext) {
            continue;
        }
        let Ok(meta) = fs::metadata(&path) else { continue };
        if meta.len() > MAX_FILE_SCAN_BYTES {
            continue;
        }
        *files_scanned += 1;

        let Ok(content) = fs::read_to_string(&path) else { continue };
        let rel_display = path.strip_prefix(workspace_root).unwrap_or(&path).to_string_lossy().to_string();

        for (i, line) in content.lines().enumerate() {
            if line.to_lowercase().contains(query_lower) {
                matches.push(json!({
                    "path": rel_display,
                    "line": i + 1,
                    "text": line.trim().chars().take(300).collect::<String>(),
                }));
                if matches.len() >= MAX_MATCHES {
                    return;
                }
            }
        }
    }
}

// ---- inspect_dependencies --------------------------------------------------

pub struct InspectDependenciesTool;

#[async_trait::async_trait]
impl Tool for InspectDependenciesTool {
    fn spec(&self) -> ToolSpec {
        ToolSpec {
            id: "inspect_dependencies",
            name: "Inspect dependencies",
            description: "Detect the project's package manifests (package.json, Cargo.toml, requirements.txt, pyproject.toml, go.mod) at the workspace root and list their declared dependencies.",
            category: ToolCategory::Inspect,
            risk: RiskLevel::Safe,
            params: vec![],
        }
    }

    async fn call(&self, ctx: &ToolContext<'_>, _args: &Value) -> Result<ToolOutput, ToolError> {
        let root = &ctx.workspace.root;
        let mut manifests: Vec<Value> = Vec::new();

        if let Some(v) = read_package_json(root) {
            manifests.push(v);
        }
        if let Some(v) = read_cargo_toml(root) {
            manifests.push(v);
        }
        if let Some(v) = read_requirements_txt(root) {
            manifests.push(v);
        }
        if let Some(v) = read_pyproject_toml(root) {
            manifests.push(v);
        }
        if let Some(v) = read_go_mod(root) {
            manifests.push(v);
        }

        let summary = if manifests.is_empty() {
            "No recognized dependency manifest found at the workspace root".to_string()
        } else {
            format!(
                "Found {} manifest(s): {}",
                manifests.len(),
                manifests
                    .iter()
                    .filter_map(|m| m.get("manifest").and_then(Value::as_str))
                    .collect::<Vec<_>>()
                    .join(", ")
            )
        };
        Ok(ToolOutput::new(summary, json!({ "manifests": manifests })))
    }
}

fn read_package_json(root: &Path) -> Option<Value> {
    let content = fs::read_to_string(root.join("package.json")).ok()?;
    let parsed: Value = serde_json::from_str(&content).ok()?;
    let deps = parsed.get("dependencies").cloned().unwrap_or(json!({}));
    let dev_deps = parsed.get("devDependencies").cloned().unwrap_or(json!({}));
    Some(json!({
        "manifest": "package.json",
        "dependencies": deps,
        "dev_dependencies": dev_deps,
    }))
}

fn read_cargo_toml(root: &Path) -> Option<Value> {
    let content = fs::read_to_string(root.join("Cargo.toml")).ok()?;
    // Minimal line-based extraction of the [dependencies] table — good
    // enough for an overview without pulling in a TOML crate dependency
    // (`serde` here is JSON-focused; adding a full TOML parser just for
    // this overview isn't worth the extra dependency weight).
    let deps = extract_toml_table(&content, "dependencies");
    Some(json!({ "manifest": "Cargo.toml", "dependencies": deps }))
}

fn extract_toml_table(content: &str, table: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut in_table = false;
    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.starts_with('[') {
            in_table = trimmed == format!("[{table}]");
            continue;
        }
        if in_table {
            if let Some((name, _)) = trimmed.split_once('=') {
                let name = name.trim();
                if !name.is_empty() {
                    out.push(name.to_string());
                }
            }
        }
    }
    out
}

fn read_requirements_txt(root: &Path) -> Option<Value> {
    let content = fs::read_to_string(root.join("requirements.txt")).ok()?;
    let deps: Vec<String> = content
        .lines()
        .map(str::trim)
        .filter(|l| !l.is_empty() && !l.starts_with('#'))
        .map(String::from)
        .collect();
    Some(json!({ "manifest": "requirements.txt", "dependencies": deps }))
}

fn read_pyproject_toml(root: &Path) -> Option<Value> {
    let content = fs::read_to_string(root.join("pyproject.toml")).ok()?;
    // PEP 621 declares dependencies as an array — `dependencies = [...]`
    // inside `[project]` — not as a sub-table, so this needs its own
    // small parser rather than `extract_toml_table` (which handles
    // `[table]` headers like Cargo.toml's `[dependencies]`).
    let deps = extract_toml_array(&content, "project", "dependencies");
    Some(json!({ "manifest": "pyproject.toml", "dependencies": deps }))
}

/// Finds `key = [...]` inside `[section]` and returns each quoted string
/// element. Handles both a single-line array and one spread across
/// multiple lines (Poetry/PEP 621 style), without a full TOML parser.
fn extract_toml_array(content: &str, section: &str, key: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut in_section = false;
    let mut in_array = false;
    let mut buffer = String::new();

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.starts_with('[') && !in_array {
            in_section = trimmed == format!("[{section}]");
            continue;
        }
        if in_section && !in_array {
            if let Some(rest) = trimmed.strip_prefix(&format!("{key} =")).or_else(|| trimmed.strip_prefix(&format!("{key}="))) {
                buffer.push_str(rest.trim());
                in_array = true;
            } else {
                continue;
            }
        } else if in_array {
            buffer.push(' ');
            buffer.push_str(trimmed);
        } else {
            continue;
        }

        if in_array && buffer.contains(']') {
            let inner = buffer.split(['[', ']']).nth(1).unwrap_or("");
            for item in inner.split(',') {
                let cleaned = item.trim().trim_matches('"').trim_matches('\'');
                if !cleaned.is_empty() {
                    out.push(cleaned.to_string());
                }
            }
            break;
        }
    }
    out
}

fn read_go_mod(root: &Path) -> Option<Value> {
    let content = fs::read_to_string(root.join("go.mod")).ok()?;
    let deps: Vec<String> = content
        .lines()
        .map(str::trim)
        .filter(|l| l.starts_with("require") || (!l.is_empty() && l.contains('/') && !l.starts_with("module")))
        .map(String::from)
        .collect();
    Some(json!({ "manifest": "go.mod", "dependencies": deps }))
}

// Re-exported for use by exec_tools' project-type detection so both
// modules agree on what "this looks like an X project" means.
pub(super) fn has_file(workspace: &WorkspaceRecord, name: &str) -> bool {
    workspace.root.join(name).is_file()
}
