// Filesystem tools, all scoped to the calling workspace root via
// `workspace::resolve_within`. Plain std::fs is used deliberately — these
// run inside Rust command handlers on behalf of an *already-approved*
// workspace, so there's no need to route through a webview-exposed fs
// plugin/capability, which would widen what the frontend JS itself could
// do. The permission boundary is enforced here in Rust, once, for every
// caller (UI or a future agent) alike.

use std::fs;
use std::path::Path;

use serde_json::{json, Value};

use super::workspace::resolve_within;
use super::{RiskLevel, Tool, ToolCategory, ToolContext, ToolError, ToolOutput, ToolParam, ToolSpec};

/// Directories that are never worth walking into: build output, dependency
/// trees, and VCS internals. Keeps `inspect_structure` and `search_code`
/// fast and their output readable instead of drowning in `node_modules`.
const SKIP_DIRS: &[&str] = &[
    ".git",
    "node_modules",
    "target",
    "dist",
    "build",
    ".next",
    ".venv",
    "venv",
    "__pycache__",
    ".turbo",
    "coverage",
    ".cache",
];

fn is_skippable_dir(name: &str) -> bool {
    SKIP_DIRS.contains(&name)
}

// ---- inspect_structure --------------------------------------------------

pub struct InspectStructureTool;

#[async_trait::async_trait]
impl Tool for InspectStructureTool {
    fn spec(&self) -> ToolSpec {
        ToolSpec {
            id: "inspect_structure",
            name: "Inspect project structure",
            description: "List directories and files under a path in the workspace (or the workspace root), depth-limited and skipping build/dependency directories.",
            category: ToolCategory::Inspect,
            risk: RiskLevel::Safe,
            params: vec![
                ToolParam { name: "path", kind: "string", description: "Directory relative to the workspace root. Omit or pass \"\" for the root.", required: false },
                ToolParam { name: "max_depth", kind: "number", description: "How many directory levels to descend (default 3, max 8).", required: false },
            ],
        }
    }

    async fn call(&self, ctx: &ToolContext<'_>, args: &Value) -> Result<ToolOutput, ToolError> {
        let rel = args.get("path").and_then(Value::as_str).unwrap_or("");
        let max_depth = args
            .get("max_depth")
            .and_then(Value::as_u64)
            .unwrap_or(3)
            .min(8) as usize;

        let start = if rel.is_empty() {
            ctx.workspace.root.clone()
        } else {
            resolve_within(ctx.workspace, rel, true)?
        };
        if !start.is_dir() {
            return Err(ToolError::InvalidArgs(format!("'{rel}' is not a directory")));
        }

        let mut entries: Vec<Value> = Vec::new();
        let mut file_count = 0usize;
        walk(&start, &ctx.workspace.root, 0, max_depth, &mut entries, &mut file_count)
            .map_err(|e| ToolError::Io(e.to_string()))?;

        let summary = format!(
            "{} entries under '{}' (depth {max_depth})",
            entries.len(),
            if rel.is_empty() { "." } else { rel }
        );
        Ok(ToolOutput::new(summary, json!({ "root": rel, "entries": entries })))
    }
}

fn walk(
    dir: &Path,
    workspace_root: &Path,
    depth: usize,
    max_depth: usize,
    out: &mut Vec<Value>,
    file_count: &mut usize,
) -> std::io::Result<()> {
    if depth >= max_depth || *file_count > 4000 {
        return Ok(());
    }
    let mut children: Vec<_> = fs::read_dir(dir)?.filter_map(|e| e.ok()).collect();
    children.sort_by_key(|e| e.file_name());

    for entry in children {
        let name = entry.file_name().to_string_lossy().to_string();
        let path = entry.path();
        let rel_display = path
            .strip_prefix(workspace_root)
            .unwrap_or(&path)
            .to_string_lossy()
            .to_string();
        let is_dir = path.is_dir();

        if is_dir && is_skippable_dir(&name) {
            continue;
        }

        *file_count += 1;
        if *file_count > 4000 {
            out.push(json!({ "path": "…", "type": "truncated", "note": "more than 4000 entries, stopped" }));
            return Ok(());
        }

        out.push(json!({
            "path": rel_display,
            "type": if is_dir { "dir" } else { "file" },
        }));

        if is_dir {
            walk(&path, workspace_root, depth + 1, max_depth, out, file_count)?;
        }
    }
    Ok(())
}

// ---- read_file ------------------------------------------------------------

const MAX_READ_BYTES: u64 = 512 * 1024; // 512KB — plenty for source files, avoids loading giant binaries/logs

pub struct ReadFileTool;

#[async_trait::async_trait]
impl Tool for ReadFileTool {
    fn spec(&self) -> ToolSpec {
        ToolSpec {
            id: "read_file",
            name: "Read file",
            description: "Read a text file's contents, optionally a specific line range.",
            category: ToolCategory::Read,
            risk: RiskLevel::Safe,
            params: vec![
                ToolParam { name: "path", kind: "string", description: "File path relative to the workspace root.", required: true },
                ToolParam { name: "start_line", kind: "number", description: "1-indexed first line to include (optional).", required: false },
                ToolParam { name: "end_line", kind: "number", description: "1-indexed last line to include, inclusive (optional).", required: false },
            ],
        }
    }

    async fn call(&self, ctx: &ToolContext<'_>, args: &Value) -> Result<ToolOutput, ToolError> {
        let rel = args
            .get("path")
            .and_then(Value::as_str)
            .ok_or_else(|| ToolError::InvalidArgs("path is required".into()))?;
        let path = resolve_within(ctx.workspace, rel, true)?;
        if !path.is_file() {
            return Err(ToolError::NotFound(rel.to_string()));
        }

        let meta = fs::metadata(&path).map_err(|e| ToolError::Io(e.to_string()))?;
        if meta.len() > MAX_READ_BYTES {
            return Err(ToolError::InvalidArgs(format!(
                "'{rel}' is {} KB, over the {} KB read limit — use search_code to locate the relevant section instead",
                meta.len() / 1024,
                MAX_READ_BYTES / 1024
            )));
        }

        let content = fs::read_to_string(&path).map_err(|e| {
            ToolError::InvalidArgs(format!("'{rel}' doesn't look like a text file: {e}"))
        })?;

        let start_line = args.get("start_line").and_then(Value::as_u64).map(|n| n as usize);
        let end_line = args.get("end_line").and_then(Value::as_u64).map(|n| n as usize);

        let (text, from, to, total) = match (start_line, end_line) {
            (None, None) => {
                let total = content.lines().count();
                (content.clone(), 1, total, total)
            }
            _ => {
                let lines: Vec<&str> = content.lines().collect();
                let total = lines.len();
                let from = start_line.unwrap_or(1).max(1);
                let to = end_line.unwrap_or(total).min(total).max(from);
                let slice = if from <= total {
                    lines[(from - 1)..to].join("\n")
                } else {
                    String::new()
                };
                (slice, from, to, total)
            }
        };

        let summary = format!("Read '{rel}' (lines {from}-{to} of {total})");
        Ok(ToolOutput::new(summary, json!({ "path": rel, "content": text, "start_line": from, "end_line": to, "total_lines": total })))
    }
}

// ---- write_file (create or fully overwrite) --------------------------------

pub struct WriteFileTool;

#[async_trait::async_trait]
impl Tool for WriteFileTool {
    fn spec(&self) -> ToolSpec {
        ToolSpec {
            id: "write_file",
            name: "Create or overwrite file",
            description: "Create a new file, or fully overwrite an existing one, with the given content. Parent directories are created as needed.",
            category: ToolCategory::Write,
            risk: RiskLevel::Write,
            params: vec![
                ToolParam { name: "path", kind: "string", description: "File path relative to the workspace root.", required: true },
                ToolParam { name: "content", kind: "string", description: "Full new file content.", required: true },
            ],
        }
    }

    async fn call(&self, ctx: &ToolContext<'_>, args: &Value) -> Result<ToolOutput, ToolError> {
        let rel = args
            .get("path")
            .and_then(Value::as_str)
            .ok_or_else(|| ToolError::InvalidArgs("path is required".into()))?;
        let content = args
            .get("content")
            .and_then(Value::as_str)
            .ok_or_else(|| ToolError::InvalidArgs("content is required".into()))?;

        let path = resolve_within(ctx.workspace, rel, false)?;
        let existed = path.exists();
        let previous_len = if existed {
            fs::metadata(&path).map(|m| m.len()).unwrap_or(0)
        } else {
            0
        };

        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).map_err(|e| ToolError::Io(e.to_string()))?;
        }
        fs::write(&path, content).map_err(|e| ToolError::Io(e.to_string()))?;

        let summary = if existed {
            format!("Overwrote '{rel}' ({previous_len} → {} bytes)", content.len())
        } else {
            format!("Created '{rel}' ({} bytes)", content.len())
        };
        Ok(ToolOutput::new(
            summary,
            json!({ "path": rel, "created": !existed, "bytes_written": content.len() }),
        ))
    }
}

// ---- patch_file (targeted find/replace) ------------------------------------

pub struct PatchFileTool;

#[async_trait::async_trait]
impl Tool for PatchFileTool {
    fn spec(&self) -> ToolSpec {
        ToolSpec {
            id: "patch_file",
            name: "Patch file",
            description: "Replace one exact, unique occurrence of `find` with `replace` in an existing file — a smaller, more reviewable change than overwriting the whole file. Fails if `find` matches zero or more than one place.",
            category: ToolCategory::Write,
            risk: RiskLevel::Write,
            params: vec![
                ToolParam { name: "path", kind: "string", description: "File path relative to the workspace root.", required: true },
                ToolParam { name: "find", kind: "string", description: "Exact text to locate. Must be unique in the file.", required: true },
                ToolParam { name: "replace", kind: "string", description: "Text to put in its place.", required: true },
            ],
        }
    }

    async fn call(&self, ctx: &ToolContext<'_>, args: &Value) -> Result<ToolOutput, ToolError> {
        let rel = args
            .get("path")
            .and_then(Value::as_str)
            .ok_or_else(|| ToolError::InvalidArgs("path is required".into()))?;
        let find = args
            .get("find")
            .and_then(Value::as_str)
            .ok_or_else(|| ToolError::InvalidArgs("find is required".into()))?;
        let replace = args
            .get("replace")
            .and_then(Value::as_str)
            .ok_or_else(|| ToolError::InvalidArgs("replace is required".into()))?;

        let path = resolve_within(ctx.workspace, rel, true)?;
        let content = fs::read_to_string(&path).map_err(|e| {
            ToolError::InvalidArgs(format!("'{rel}' doesn't look like a text file: {e}"))
        })?;

        let occurrences = content.matches(find).count();
        if occurrences == 0 {
            return Err(ToolError::InvalidArgs(format!(
                "'find' text was not found in '{rel}'"
            )));
        }
        if occurrences > 1 {
            return Err(ToolError::InvalidArgs(format!(
                "'find' text appears {occurrences} times in '{rel}' — it must be unique; include more surrounding context"
            )));
        }

        let updated = content.replacen(find, replace, 1);
        fs::write(&path, &updated).map_err(|e| ToolError::Io(e.to_string()))?;

        let summary = format!(
            "Patched '{rel}' ({} chars → {} chars in the replaced span)",
            find.len(),
            replace.len()
        );
        Ok(ToolOutput::new(
            summary,
            json!({ "path": rel, "find": find, "replace": replace }),
        ))
    }
}

// ---- delete_file (confirmation-gated) --------------------------------------

pub struct DeleteFileTool;

#[async_trait::async_trait]
impl Tool for DeleteFileTool {
    fn spec(&self) -> ToolSpec {
        ToolSpec {
            id: "delete_file",
            name: "Delete file",
            description: "Permanently delete a file in the workspace. Requires explicit confirmation — the first call without `confirmed: true` returns a preview instead of deleting anything.",
            category: ToolCategory::Write,
            risk: RiskLevel::Destructive,
            params: vec![
                ToolParam { name: "path", kind: "string", description: "File path relative to the workspace root.", required: true },
                ToolParam { name: "confirmed", kind: "boolean", description: "Must be true, and set only after the user has explicitly approved this specific deletion.", required: true },
            ],
        }
    }

    async fn call(&self, ctx: &ToolContext<'_>, args: &Value) -> Result<ToolOutput, ToolError> {
        let rel = args
            .get("path")
            .and_then(Value::as_str)
            .ok_or_else(|| ToolError::InvalidArgs("path is required".into()))?;
        let path = resolve_within(ctx.workspace, rel, true)?;
        if !path.is_file() {
            return Err(ToolError::NotFound(rel.to_string()));
        }

        let size = fs::metadata(&path).map(|m| m.len()).unwrap_or(0);
        let preview = format!("Delete '{rel}' ({size} bytes) — this cannot be undone.");

        // ctx.confirmed reflects the `confirmed` flag on this specific
        // dispatch call, set by the caller only after the user has seen
        // and approved this exact deletion — not a standing permission.
        if !ctx.confirmed {
            return Err(ToolError::ConfirmationRequired { preview });
        }

        fs::remove_file(&path).map_err(|e| ToolError::Io(e.to_string()))?;
        Ok(ToolOutput::new(
            format!("Deleted '{rel}' ({size} bytes)"),
            json!({ "path": rel, "bytes_deleted": size }),
        ))
    }
}
