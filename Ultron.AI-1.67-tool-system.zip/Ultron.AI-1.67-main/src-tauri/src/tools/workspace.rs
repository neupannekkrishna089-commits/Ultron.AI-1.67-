// Workspace permission system.
//
// A "workspace" is a directory the user has explicitly approved for the
// Tool System to read and modify. Nothing in this module — or anything
// under `tools/`, `ai/`, or the chat UI — may act on a directory that
// hasn't gone through `WorkspaceStore::approve`. This is intentionally
// separate from AI provider credentials (src-tauri/src/credentials.rs):
// approving a workspace has nothing to do with any provider key, and a
// provider having a key configured grants it no filesystem access by
// itself.
//
// Persistence: a small JSON file in the app's data directory
// (`tool_workspaces.json`), guarded by a mutex. This is deliberately its
// own store rather than reusing the frontend's `kv_store` SQLite table —
// the Tool System is a separate modular layer and should not need the
// frontend's storage plumbing to function (e.g. if driven headlessly by
// the Router with no window open).

use std::fs;
use std::path::{Path, PathBuf};
use std::sync::Mutex;
use std::time::{SystemTime, UNIX_EPOCH};

use serde::{Deserialize, Serialize};

use super::ToolError;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkspaceRecord {
    pub id: String,
    /// Canonicalized absolute path. Every tool call resolves paths
    /// against this, not against whatever string the caller happens to
    /// pass.
    pub root: PathBuf,
    /// Display label — defaults to the directory's own name.
    pub label: String,
    pub approved_at: u64,
}

fn now_secs() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}

pub struct WorkspaceStore {
    file: PathBuf,
    entries: Mutex<Vec<WorkspaceRecord>>,
}

impl WorkspaceStore {
    /// Loads existing approvals from disk, or starts empty. `data_dir` is
    /// the app's own data directory (never a user-chosen path) — this is
    /// ULTRON's own bookkeeping file, not something a workspace tool
    /// could ever read or overwrite, since it lives outside every
    /// workspace root.
    pub fn load(data_dir: &Path) -> Self {
        let file = data_dir.join("tool_workspaces.json");
        let entries = fs::read_to_string(&file)
            .ok()
            .and_then(|s| serde_json::from_str::<Vec<WorkspaceRecord>>(&s).ok())
            .unwrap_or_default();
        Self { file, entries: Mutex::new(entries) }
    }

    fn persist(&self, entries: &[WorkspaceRecord]) {
        if let Some(parent) = self.file.parent() {
            let _ = fs::create_dir_all(parent);
        }
        if let Ok(json) = serde_json::to_string_pretty(entries) {
            let _ = fs::write(&self.file, json);
        }
    }

    /// Approve a new directory (or return the existing record if this
    /// exact directory is already approved). The directory must already
    /// exist — the user picked it via a native folder dialog, so it
    /// always will in practice, but this is re-checked defensively.
    pub fn approve(&self, path: &Path, label: Option<String>) -> Result<WorkspaceRecord, String> {
        let canonical = fs::canonicalize(path)
            .map_err(|e| format!("Can't access '{}': {e}", path.display()))?;
        if !canonical.is_dir() {
            return Err(format!("'{}' is not a directory", canonical.display()));
        }

        let mut entries = self.entries.lock().unwrap();
        if let Some(existing) = entries.iter().find(|w| w.root == canonical) {
            return Ok(existing.clone());
        }

        let label = label.unwrap_or_else(|| {
            canonical
                .file_name()
                .map(|n| n.to_string_lossy().to_string())
                .unwrap_or_else(|| canonical.display().to_string())
        });

        let record = WorkspaceRecord {
            id: uid(),
            root: canonical,
            label,
            approved_at: now_secs(),
        };
        entries.push(record.clone());
        self.persist(&entries);
        Ok(record)
    }

    pub fn revoke(&self, id: &str) {
        let mut entries = self.entries.lock().unwrap();
        entries.retain(|w| w.id != id);
        self.persist(&entries);
    }

    pub fn list(&self) -> Vec<WorkspaceRecord> {
        self.entries.lock().unwrap().clone()
    }

    pub fn get(&self, id: &str) -> Result<WorkspaceRecord, ToolError> {
        self.entries
            .lock()
            .unwrap()
            .iter()
            .find(|w| w.id == id)
            .cloned()
            .ok_or(ToolError::WorkspaceNotApproved)
    }
}

fn uid() -> String {
    // Same lightweight scheme used elsewhere in ULTRON's frontend
    // (src/lib/ultron.ts `uid()`) — good enough for a local-only id with
    // no coordination or collision-sensitivity requirements.
    let nanos = SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0);
    format!("ws_{nanos:x}")
}

/// Resolves a caller-supplied relative path against a workspace root and
/// guarantees the result is still inside that root. This is the one
/// function every fs/search/exec tool must route paths through — it is
/// the actual enforcement point for "the Coding Agent (or any tool
/// caller) can only touch the approved directory".
///
/// `must_exist`: when true (reads, deletes, searches), the resolved path
/// is canonicalized and re-checked against the canonical root, which also
/// catches symlink escapes. When false (the target of a file being
/// created), the parent directory is canonicalized/checked instead, since
/// the file itself doesn't exist yet.
pub fn resolve_within(
    workspace: &WorkspaceRecord,
    relative: &str,
    must_exist: bool,
) -> Result<PathBuf, ToolError> {
    if relative.is_empty() {
        return Err(ToolError::InvalidArgs("path must not be empty".into()));
    }
    let rel_path = Path::new(relative);
    if rel_path.is_absolute() {
        return Err(ToolError::PathEscapesWorkspace(relative.to_string()));
    }

    let joined = workspace.root.join(rel_path);

    if must_exist {
        let canonical = fs::canonicalize(&joined)
            .map_err(|_| ToolError::NotFound(relative.to_string()))?;
        if !canonical.starts_with(&workspace.root) {
            return Err(ToolError::PathEscapesWorkspace(relative.to_string()));
        }
        Ok(canonical)
    } else {
        let parent = joined
            .parent()
            .ok_or_else(|| ToolError::PathEscapesWorkspace(relative.to_string()))?;
        // The parent directory may itself not exist yet (creating a file
        // in a new subdirectory) — walk up to the nearest existing
        // ancestor to canonicalize and check containment, then re-append
        // the non-existent tail lexically.
        let mut existing_ancestor = parent;
        let mut tail: Vec<&std::ffi::OsStr> = Vec::new();
        loop {
            if existing_ancestor.exists() {
                break;
            }
            tail.push(existing_ancestor.file_name().ok_or_else(|| {
                ToolError::PathEscapesWorkspace(relative.to_string())
            })?);
            existing_ancestor = existing_ancestor.parent().ok_or_else(|| {
                ToolError::PathEscapesWorkspace(relative.to_string())
            })?;
        }
        let canonical_ancestor = fs::canonicalize(existing_ancestor)
            .map_err(|_| ToolError::PathEscapesWorkspace(relative.to_string()))?;
        if !canonical_ancestor.starts_with(&workspace.root) {
            return Err(ToolError::PathEscapesWorkspace(relative.to_string()));
        }
        let mut result = canonical_ancestor;
        for part in tail.into_iter().rev() {
            result.push(part);
        }
        // The loop above only walked and reconstructed the *parent*
        // chain; re-append the target's own file name on top of it.
        if let Some(name) = joined.file_name() {
            result.push(name);
        }
        Ok(result)
    }
}
