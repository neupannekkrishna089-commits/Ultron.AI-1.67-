// Tool System: a provider-independent execution layer for filesystem,
// search, and command-line operations against a user-approved project
// directory ("workspace").
//
// Design intent (see also workspace.rs for the permission model):
//   - This module has ZERO dependency on `ai::` or `credentials::`. It
//     never sees a provider API key and never talks to a network AI
//     endpoint itself — it only executes local operations and returns
//     structured results. Any AI model — the Anthropic provider today,
//     any future provider, or the Multi AI Router orchestrating several —
//     can drive it through the same `ToolSpec` list and `dispatch()` call.
//   - This module has ZERO dependency on a "Coding Agent". A Coding Agent
//     is expected to be a future *consumer* of this layer: it would call
//     `dispatch()` repeatedly to inspect, read, search, write, and run
//     commands, then compose those primitive results into a plan/apply/
//     verify workflow of its own. That orchestration logic does not live
//     here, on purpose, so the Tool System stays usable by anything else
//     (chat-triggered one-off tool calls, the Router's own reasoning
//     loop, other future agents) without dragging Coding-Agent-specific
//     assumptions along with it.
//   - Every tool call is scoped to a single approved workspace directory
//     (see `workspace::WorkspaceStore`) and every path a tool touches is
//     re-validated to stay inside that directory. There is no tool that
//     accepts an absolute, unscoped path.
//   - Destructive operations (currently: delete) require the caller to
//     pass `confirmed: true` on the specific call. Without it, the tool
//     returns `ToolError::ConfirmationRequired` with a human-readable
//     preview of what *would* happen, instead of doing it. Callers (UI or
//     an AI loop) are expected to surface that preview to the user and
//     re-issue the call with confirmation only after explicit approval.
//   - Command execution never goes through a shell. Callers supply a
//     program name and an argv array; the program must be on a fixed
//     allowlist of ordinary development tools. There is no code path that
//     interprets `;`, `&&`, `|`, backticks, or redirection — those are
//     just literal argument characters passed straight to `exec`, so
//     shell-injection-style chaining has no effect.

pub mod exec_tools;
pub mod fs_tools;
pub mod search_tools;
pub mod workspace;

use serde::{Deserialize, Serialize};
use serde_json::Value;

use workspace::WorkspaceRecord;

// ---- shared shape -----------------------------------------------------

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ToolCategory {
    Inspect,
    Read,
    Search,
    Write,
    Execute,
}

/// How much scrutiny a tool call deserves before it runs.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RiskLevel {
    /// Read-only; safe to run without asking the user each time, as long
    /// as the workspace itself was approved.
    Safe,
    /// Changes state on disk. Allowed once the workspace is approved, but
    /// callers (UI / an agent) are expected to show a plan before issuing
    /// these in bulk. Not individually confirmation-gated by this layer.
    Write,
    /// Irreversible or hard to undo. This layer itself refuses to run the
    /// call unless `confirmed: true` is passed, regardless of what any
    /// caller "plans" to do.
    Destructive,
}

/// Describes one parameter of a tool's JSON input object. Deliberately a
/// flat, provider-agnostic shape — a thin adapter in the Router (or
/// wherever a specific provider's function-calling format is built) can
/// map this to Anthropic tool_use / OpenAI function-calling / etc. without
/// this module knowing any of those formats exist.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolParam {
    pub name: &'static str,
    /// "string" | "number" | "boolean" | "array" | "object"
    pub kind: &'static str,
    pub description: &'static str,
    pub required: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolSpec {
    pub id: &'static str,
    pub name: &'static str,
    pub description: &'static str,
    pub category: ToolCategory,
    pub risk: RiskLevel,
    pub params: Vec<ToolParam>,
}

/// What a tool call needs to run: which workspace it's scoped to, and
/// whether the caller has attached explicit user confirmation to *this*
/// call (only meaningful for Destructive tools).
pub struct ToolContext<'a> {
    pub workspace: &'a WorkspaceRecord,
    pub confirmed: bool,
}

/// A successful tool result. `summary` is a short human-readable line
/// suitable for showing directly in a change log or chat transcript;
/// `data` is the structured payload for a caller (agent or UI) to work
/// with programmatically.
#[derive(Debug, Clone, Serialize)]
pub struct ToolOutput {
    pub summary: String,
    pub data: Value,
}

impl ToolOutput {
    pub fn new(summary: impl Into<String>, data: Value) -> Self {
        Self { summary: summary.into(), data }
    }
}

#[derive(Debug)]
pub enum ToolError {
    UnknownTool(String),
    /// The referenced workspace id isn't approved (or was revoked).
    WorkspaceNotApproved,
    /// The resolved path fell outside the workspace root — refused
    /// regardless of how the path was spelled (`..`, symlink, etc.).
    PathEscapesWorkspace(String),
    NotFound(String),
    /// A Destructive-risk tool was called without `confirmed: true`.
    /// `preview` is a human-readable description of what would happen.
    ConfirmationRequired { preview: String },
    /// `run_command` / `run_tests` / `inspect_compiler_errors` was asked
    /// to run a program not on the fixed allowlist.
    CommandNotAllowed(String),
    InvalidArgs(String),
    Io(String),
    Timeout,
}

impl std::fmt::Display for ToolError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ToolError::UnknownTool(id) => write!(f, "Unknown tool '{id}'"),
            ToolError::WorkspaceNotApproved => {
                write!(f, "This directory hasn't been approved as a workspace yet.")
            }
            ToolError::PathEscapesWorkspace(p) => {
                write!(f, "Refused: '{p}' resolves outside the approved workspace")
            }
            ToolError::NotFound(p) => write!(f, "Not found: {p}"),
            ToolError::ConfirmationRequired { preview } => {
                write!(f, "Confirmation required before this runs: {preview}")
            }
            ToolError::CommandNotAllowed(cmd) => {
                write!(f, "'{cmd}' is not on the approved command allowlist")
            }
            ToolError::InvalidArgs(e) => write!(f, "Invalid arguments: {e}"),
            ToolError::Io(e) => write!(f, "I/O error: {e}"),
            ToolError::Timeout => write!(f, "Command timed out"),
        }
    }
}

#[async_trait::async_trait]
pub trait Tool: Send + Sync {
    fn spec(&self) -> ToolSpec;
    async fn call(&self, ctx: &ToolContext<'_>, args: &Value) -> Result<ToolOutput, ToolError>;
}

/// The full tool lineup. Order is stable; this is what both the Settings
/// UI (if it ever lists tools) and any AI-facing tool schema builder
/// should iterate over.
pub fn registry() -> Vec<Box<dyn Tool>> {
    vec![
        Box::new(fs_tools::InspectStructureTool),
        Box::new(fs_tools::ReadFileTool),
        Box::new(fs_tools::WriteFileTool),
        Box::new(fs_tools::PatchFileTool),
        Box::new(fs_tools::DeleteFileTool),
        Box::new(search_tools::SearchCodeTool),
        Box::new(search_tools::InspectDependenciesTool),
        Box::new(exec_tools::RunCommandTool),
        Box::new(exec_tools::RunTestsTool),
        Box::new(exec_tools::InspectCompilerErrorsTool),
    ]
}

pub fn find(tool_id: &str) -> Option<Box<dyn Tool>> {
    registry().into_iter().find(|t| t.spec().id == tool_id)
}

pub fn all_specs() -> Vec<ToolSpec> {
    registry().into_iter().map(|t| t.spec()).collect()
}

/// The single choke point every tool call goes through — mirrors
/// `ai::dispatch` being the single choke point for provider calls. This is
/// what ULTRON's own UI calls for one-off actions, and what the Multi AI
/// Router (and, later, the Coding Agent through the Router or directly)
/// should call for every tool invocation rather than reaching into
/// individual tool structs.
pub async fn dispatch(
    workspace: &WorkspaceRecord,
    tool_id: &str,
    args: Value,
    confirmed: bool,
) -> Result<ToolOutput, ToolError> {
    let tool = find(tool_id).ok_or_else(|| ToolError::UnknownTool(tool_id.to_string()))?;

    // Destructive tools are individually responsible for checking
    // ctx.confirmed and returning ConfirmationRequired with a preview
    // built from these same args instead of acting — see
    // fs_tools::DeleteFileTool. Enforcing it once here as well (rather
    // than trusting each tool) would be redundant with that, so the
    // contract is: risk == Destructive implies the tool itself never
    // mutates anything unless ctx.confirmed is true.
    let ctx = ToolContext { workspace, confirmed };
    tool.call(&ctx, &args).await
}
