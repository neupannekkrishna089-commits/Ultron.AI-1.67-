// Command-execution tools.
//
// Security model, read this before touching anything below:
//   1. No shell is ever invoked. Callers supply `program` + an argv array
//      (`args: string[]`); we hand that straight to `Command::new(program)
//      .args(args)`. There is no `sh -c "..."` anywhere in this file, so
//      `;`, `&&`, `|`, backticks, `$()`, and redirection operators are
//      just inert characters inside an argument, not shell syntax.
//   2. `program` must be an exact match (after stripping a path/extension)
//      against a fixed allowlist of ordinary development tools —
//      package-manager, compiler, and test runners. Nothing resembling a
//      shell, an interpreter's `-c`/`eval` flag, `sudo`, `rm`, `del`, disk
//      or network utilities, etc. is on that list, and there is no way
//      for a caller to extend it at runtime.
//   3. Every invocation's cwd is pinned to the approved workspace root —
//      never a caller-supplied path — so even an allowlisted tool can
//      only act inside the workspace.
//   4. The child process's environment is NOT inherited from ULTRON's own
//      process. We start from empty and copy over only PATH (and a
//      couple of platform essentials needed for the OS loader to find
//      shared libraries/tools), so nothing in ULTRON's own environment —
//      including anything an AI provider integration might ever set —
//      can leak into a tool the model asked to run. Provider API keys
//      specifically never touch process env at all (see
//      credentials.rs / ai::dispatch) — this is defense in depth on top
//      of that, not a substitute for it.
//   5. Every call has a hard wall-clock timeout so a hung test suite or
//      dev server can't block the Tool System indefinitely.

use std::path::Path;
use std::process::Stdio;
use std::time::Duration;

use serde_json::{json, Value};
use tokio::process::Command;
use tokio::time::timeout;

use super::search_tools::has_file;
use super::workspace::WorkspaceRecord;
use super::{RiskLevel, Tool, ToolCategory, ToolContext, ToolError, ToolOutput, ToolParam, ToolSpec};

/// Ordinary development-tool binaries. Matched against the program name
/// only (case-insensitive, extension stripped) — never a full path, so a
/// caller can't smuggle an arbitrary executable in by giving it an
/// allowlisted basename's absolute path elsewhere on disk pointing to
/// something else; `resolve_program` below only ever resolves through the
/// sanitized PATH we hand the child process.
const ALLOWED_PROGRAMS: &[&str] = &[
    // JS/TS
    "npm", "npx", "pnpm", "yarn", "bun", "tsc", "node", "vite", "eslint", "prettier", "vitest",
    "jest",
    // Rust
    "cargo",
    // Python
    "python", "python3", "pip", "pip3", "pytest", "ruff", "mypy", "black",
    // Go
    "go",
    // Java/Kotlin
    "mvn", "gradle", "gradlew",
    // Read-only / informational git — see is_git_arg_safe below for the
    // subcommand-level restriction that actually gates this one.
    "git",
    "make",
];

const MAX_OUTPUT_BYTES: usize = 200 * 1024; // 200KB captured per stream, then truncated
const COMMAND_TIMEOUT_SECS: u64 = 180;

fn program_basename(program: &str) -> String {
    Path::new(program)
        .file_stem()
        .map(|s| s.to_string_lossy().to_lowercase())
        .unwrap_or_else(|| program.to_lowercase())
}

fn is_allowed_program(program: &str) -> bool {
    ALLOWED_PROGRAMS.contains(&program_basename(program).as_str())
}

/// `git` is allowlisted for its binary name, but only a short list of
/// read-only subcommands are permitted through — this tool is for
/// inspection (status/diff/log/show), not for a model to push, reset
/// --hard, clean -fdx, or rewrite history unattended.
const GIT_SAFE_SUBCOMMANDS: &[&str] = &["status", "diff", "log", "show", "branch", "remote"];

fn validate_args(program: &str, args: &[String]) -> Result<(), ToolError> {
    if program_basename(program) == "git" {
        match args.first() {
            Some(sub) if GIT_SAFE_SUBCOMMANDS.contains(&sub.as_str()) => {}
            other => {
                return Err(ToolError::CommandNotAllowed(format!(
                    "git {}",
                    other.map(String::as_str).unwrap_or("<none>")
                )));
            }
        }
    }
    Ok(())
}

fn sanitized_env() -> Vec<(String, String)> {
    let mut env = Vec::new();
    for key in ["PATH", "HOME", "USERPROFILE", "SystemRoot", "TEMP", "TMP"] {
        if let Ok(val) = std::env::var(key) {
            env.push((key.to_string(), val));
        }
    }
    env
}

struct RunOutcome {
    exit_code: Option<i32>,
    stdout: String,
    stderr: String,
    timed_out: bool,
}

async fn run(workspace: &WorkspaceRecord, program: &str, args: &[String]) -> Result<RunOutcome, ToolError> {
    if !is_allowed_program(program) {
        return Err(ToolError::CommandNotAllowed(program.to_string()));
    }
    validate_args(program, args)?;

    let mut cmd = Command::new(program);
    cmd.args(args)
        .current_dir(&workspace.root)
        .env_clear()
        .envs(sanitized_env())
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .kill_on_drop(true);

    let child = cmd.spawn().map_err(|e| {
        ToolError::Io(format!("Failed to start '{program}': {e}"))
    })?;

    let result = timeout(Duration::from_secs(COMMAND_TIMEOUT_SECS), child.wait_with_output()).await;

    match result {
        Ok(Ok(output)) => Ok(RunOutcome {
            exit_code: output.status.code(),
            stdout: truncate(&String::from_utf8_lossy(&output.stdout)),
            stderr: truncate(&String::from_utf8_lossy(&output.stderr)),
            timed_out: false,
        }),
        Ok(Err(e)) => Err(ToolError::Io(e.to_string())),
        Err(_) => Ok(RunOutcome {
            exit_code: None,
            stdout: String::new(),
            stderr: format!("Command exceeded the {COMMAND_TIMEOUT_SECS}s timeout and was killed."),
            timed_out: true,
        }),
    }
}

fn truncate(s: &str) -> String {
    if s.len() <= MAX_OUTPUT_BYTES {
        s.to_string()
    } else {
        format!("{}\n… (truncated, {} more bytes)", &s[..MAX_OUTPUT_BYTES], s.len() - MAX_OUTPUT_BYTES)
    }
}

fn parse_args(args: &Value) -> Result<Vec<String>, ToolError> {
    match args.get("args") {
        None => Ok(vec![]),
        Some(Value::Array(items)) => items
            .iter()
            .map(|v| {
                v.as_str()
                    .map(String::from)
                    .ok_or_else(|| ToolError::InvalidArgs("args must be an array of strings".into()))
            })
            .collect(),
        Some(_) => Err(ToolError::InvalidArgs("args must be an array of strings".into())),
    }
}

fn outcome_output(program: &str, args: &[String], outcome: RunOutcome) -> ToolOutput {
    let ok = outcome.exit_code == Some(0);
    let summary = if outcome.timed_out {
        format!("`{program} {}` timed out", args.join(" "))
    } else {
        format!(
            "`{program} {}` exited {} ({})",
            args.join(" "),
            outcome.exit_code.map(|c| c.to_string()).unwrap_or_else(|| "killed".to_string()),
            if ok { "success" } else { "failure" }
        )
    };
    ToolOutput::new(
        summary,
        json!({
            "program": program,
            "args": args,
            "exit_code": outcome.exit_code,
            "success": ok,
            "timed_out": outcome.timed_out,
            "stdout": outcome.stdout,
            "stderr": outcome.stderr,
        }),
    )
}

// ---- run_command ------------------------------------------------------

pub struct RunCommandTool;

#[async_trait::async_trait]
impl Tool for RunCommandTool {
    fn spec(&self) -> ToolSpec {
        ToolSpec {
            id: "run_command",
            name: "Run development command",
            description: "Run an approved development-tool command (npm, cargo, pytest, tsc, read-only git, etc.) in the workspace root. No shell is used — args are passed literally, so shell operators have no special meaning. Not on the allowlist? The call is refused, not sandboxed.",
            category: ToolCategory::Execute,
            risk: RiskLevel::Write,
            params: vec![
                ToolParam { name: "program", kind: "string", description: "Executable name, e.g. \"npm\", \"cargo\", \"pytest\".", required: true },
                ToolParam { name: "args", kind: "array", description: "Argument list, e.g. [\"run\", \"build\"]. Never a single shell string.", required: false },
            ],
        }
    }

    async fn call(&self, ctx: &ToolContext<'_>, args: &Value) -> Result<ToolOutput, ToolError> {
        let program = args
            .get("program")
            .and_then(Value::as_str)
            .ok_or_else(|| ToolError::InvalidArgs("program is required".into()))?;
        let argv = parse_args(args)?;
        let outcome = run(ctx.workspace, program, &argv).await?;
        Ok(outcome_output(program, &argv, outcome))
    }
}

// ---- project-type detection (shared by run_tests / inspect_compiler_errors) --

enum ProjectKind {
    Node,
    Rust,
    Python,
    Go,
}

fn detect_project(workspace: &WorkspaceRecord) -> Option<ProjectKind> {
    if has_file(workspace, "Cargo.toml") {
        Some(ProjectKind::Rust)
    } else if has_file(workspace, "package.json") {
        Some(ProjectKind::Node)
    } else if has_file(workspace, "pyproject.toml") || has_file(workspace, "requirements.txt") {
        Some(ProjectKind::Python)
    } else if has_file(workspace, "go.mod") {
        Some(ProjectKind::Go)
    } else {
        None
    }
}

fn node_has_test_script(workspace: &WorkspaceRecord) -> bool {
    let Ok(content) = std::fs::read_to_string(workspace.root.join("package.json")) else {
        return false;
    };
    let Ok(parsed) = serde_json::from_str::<Value>(&content) else {
        return false;
    };
    parsed
        .get("scripts")
        .and_then(|s| s.get("test"))
        .and_then(Value::as_str)
        .map(|t| !t.trim().is_empty() && !t.contains("no test specified"))
        .unwrap_or(false)
}

// ---- run_tests ----------------------------------------------------------

pub struct RunTestsTool;

#[async_trait::async_trait]
impl Tool for RunTestsTool {
    fn spec(&self) -> ToolSpec {
        ToolSpec {
            id: "run_tests",
            name: "Run tests",
            description: "Detect the project type from the workspace root (Cargo.toml / package.json / pyproject.toml or requirements.txt / go.mod) and run its standard test command, reporting pass/fail honestly from the exit code.",
            category: ToolCategory::Execute,
            risk: RiskLevel::Write,
            params: vec![],
        }
    }

    async fn call(&self, ctx: &ToolContext<'_>, _args: &Value) -> Result<ToolOutput, ToolError> {
        let (program, argv): (&str, Vec<String>) = match detect_project(ctx.workspace) {
            Some(ProjectKind::Rust) => ("cargo", vec!["test".into()]),
            Some(ProjectKind::Node) if node_has_test_script(ctx.workspace) => {
                ("npm", vec!["test".into(), "--silent".into()])
            }
            Some(ProjectKind::Node) => {
                return Err(ToolError::InvalidArgs(
                    "package.json has no usable \"test\" script".into(),
                ))
            }
            Some(ProjectKind::Python) => ("pytest", vec!["-q".into()]),
            Some(ProjectKind::Go) => ("go", vec!["test".into(), "./...".into()]),
            None => {
                return Err(ToolError::InvalidArgs(
                    "Couldn't detect a recognized project type at the workspace root".into(),
                ))
            }
        };

        let outcome = run(ctx.workspace, program, &argv).await?;
        Ok(outcome_output(program, &argv, outcome))
    }
}

// ---- inspect_compiler_errors ---------------------------------------------

pub struct InspectCompilerErrorsTool;

#[async_trait::async_trait]
impl Tool for InspectCompilerErrorsTool {
    fn spec(&self) -> ToolSpec {
        ToolSpec {
            id: "inspect_compiler_errors",
            name: "Inspect compiler / type errors",
            description: "Run the project's standard check/build step (cargo check, tsc --noEmit, or a Python syntax pass) and return its raw output for diagnosis. Does not attempt to interpret the errors itself.",
            category: ToolCategory::Execute,
            risk: RiskLevel::Write,
            params: vec![],
        }
    }

    async fn call(&self, ctx: &ToolContext<'_>, _args: &Value) -> Result<ToolOutput, ToolError> {
        let (program, argv): (&str, Vec<String>) = match detect_project(ctx.workspace) {
            Some(ProjectKind::Rust) => ("cargo", vec!["check".into(), "--message-format=short".into()]),
            Some(ProjectKind::Node) if has_file(ctx.workspace, "tsconfig.json") => {
                ("tsc", vec!["--noEmit".into()])
            }
            Some(ProjectKind::Node) => {
                return Err(ToolError::InvalidArgs(
                    "No tsconfig.json found — nothing to type-check for this Node project".into(),
                ))
            }
            Some(ProjectKind::Python) => {
                ("python3", vec!["-m".into(), "compileall".into(), "-q".into(), ".".into()])
            }
            Some(ProjectKind::Go) => ("go", vec!["build".into(), "./...".into()]),
            None => {
                return Err(ToolError::InvalidArgs(
                    "Couldn't detect a recognized project type at the workspace root".into(),
                ))
            }
        };

        let outcome = run(ctx.workspace, program, &argv).await?;
        Ok(outcome_output(program, &argv, outcome))
    }
}
