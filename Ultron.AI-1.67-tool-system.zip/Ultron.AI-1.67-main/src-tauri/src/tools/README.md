# Tool System

`src-tauri/src/tools/` — a provider-independent execution layer for
filesystem, search, and command-line operations against a
user-approved project directory (a "workspace").

## Why it's separate

- **No dependency on `ai::`.** The Tool System never sees a provider API
  key and never talks to a network AI endpoint. Any model — the
  Anthropic provider, a future provider, or the Multi AI Router
  orchestrating several — drives it through the same `ToolSpec` list and
  `dispatch()` call.
- **No dependency on a Coding Agent.** A Coding Agent is a future
  *consumer* of this layer: it calls `dispatch()` repeatedly (inspect,
  read, search, write, run) and composes those primitive results into
  its own plan/apply/verify/summarize workflow. That orchestration does
  not live here, so the layer stays usable by anything else too — a
  one-off tool call from chat, the Router's own reasoning loop, other
  future agents.

## The permission model

Nothing acts on a directory until the user explicitly approves it
(`approve_workspace`). Every tool call is scoped to one approved
workspace id, and every path a tool touches is re-resolved and checked
against that workspace's root (`workspace::resolve_within`) — there is
no tool that accepts an absolute, unscoped path. `delete_file` is
additionally gated per-call: without `confirmed: true` it returns a
`ConfirmationRequired` preview instead of deleting anything.

Command execution (`run_command`, `run_tests`,
`inspect_compiler_errors`) never goes through a shell — callers supply a
program name and an argv array, `program` must be on a fixed allowlist
of ordinary dev tools, and the child process's environment is rebuilt
from scratch (PATH + platform essentials only), so nothing in ULTRON's
own environment can leak into a spawned command.

## The tool lineup

| id | category | risk | maps to the spec's… |
|---|---|---|---|
| `inspect_structure` | inspect | safe | inspect project structure |
| `read_file` | read | safe | read files |
| `search_code` | search | safe | search code |
| `inspect_dependencies` | inspect | safe | understand dependencies |
| `write_file` | write | write | create files / modify files |
| `patch_file` | write | write | modify files (targeted find/replace) |
| `delete_file` | write | **destructive** | delete files only with confirmation |
| `run_command` | execute | write | run approved development commands |
| `run_tests` | execute | write | run tests |
| `inspect_compiler_errors` | execute | write | inspect compiler errors |

"debug", "produce a change plan", "apply changes", "verify changes",
"summarize modifications" are agent-level behaviors composed from these
primitives by whatever calls `dispatch()` — intentionally not
implemented inside the Tool System itself (see "Why it's separate").

## Integration contract for the Multi AI Router / a future Coding Agent

Everything goes through one choke point, `tools::dispatch()` in Rust
(exposed over IPC as the `call_tool` command):

```
dispatch(workspace: &WorkspaceRecord, tool_id: &str, args: Value, confirmed: bool)
    -> Result<ToolOutput, ToolError>
```

- `tools::all_specs()` gives the full tool list with JSON-schema-like
  parameter descriptions (`ToolSpec` / `ToolParam`) — a provider-specific
  adapter (Anthropic tool_use, OpenAI function-calling, etc.) maps these
  to whatever format that provider expects. Nothing in this module
  hardcodes a provider's schema.
- A `ConfirmationRequired { preview }` result means: show `preview` to
  the user, and only re-issue the same call with `confirmed: true` after
  they explicitly approve it. Never auto-confirm on an agent's own
  judgment.
- A workspace id comes from `approve_workspace` / `list_workspaces`
  (frontend: `src/lib/tools.ts`) — the Router/agent should never invent
  or guess one; it should ask the user (via the existing Workspace
  settings panel, `src/components/WorkspaceSettings.tsx`) to approve a
  directory first if none is approved yet.

## Frontend

- `src/lib/tools.ts` — thin IPC client (`listToolSpecs`, `selectWorkspaceDialog`,
  `approveWorkspace`, `listWorkspaces`, `revokeWorkspace`, `callTool`).
- `src/components/WorkspaceSettings.tsx` — the approval UI, mounted in
  Settings under the existing Providers panel.

## Known limitations (by design, for this phase)

- `search_code` / `inspect_dependencies` are dependency-free, line-based
  implementations (no `walkdir`/TOML-parser crate), consistent with this
  project's small-binary stance. Good for an overview, not a substitute
  for a real language server.
- `run_command`'s allowlist is deliberately short (npm/pnpm/yarn/bun,
  cargo, python/pytest, go, git status/diff/log/show/branch/remote,
  make, a few linters/type-checkers). Extending it should stay in
  `exec_tools.rs::ALLOWED_PROGRAMS`/`GIT_SAFE_SUBCOMMANDS` deliberately,
  not by accepting a caller-supplied allowlist.

## Not yet compiled

This was built without a local Rust toolchain available in the build
environment — run `cargo check` inside `src-tauri/` before relying on
it. The trickiest external API used (`tauri-plugin-dialog`'s
`DialogExt::pick_folder`, and the `dialog:allow-open` capability) was
verified against current docs, but nothing here has been through an
actual compiler yet.
