// Real, working implementation — the one provider Phase 1 actually calls
// over the network. Uses the Messages API directly (no SDK dependency, to
// keep the binary small for the target hardware).

use serde::Deserialize;
use serde_json::json;

use super::{AiProvider, ChatMessage, ProviderCapabilities, ProviderError};

const API_URL: &str = "https://api.anthropic.com/v1/messages";
const API_VERSION: &str = "2023-06-01";

pub struct AnthropicProvider;

#[async_trait::async_trait]
impl AiProvider for AnthropicProvider {
    fn id(&self) -> &'static str {
        "anthropic"
    }

    fn display_name(&self) -> &'static str {
        "Claude (Anthropic)"
    }

    fn implemented(&self) -> bool {
        true
    }

    fn default_model(&self) -> &'static str {
        "claude-sonnet-4-6"
    }

    fn capabilities(&self) -> ProviderCapabilities {
        ProviderCapabilities {
            vision: true,
            tool_calling: true,
            context_window: 200_000,
            reasoning: true,
            research: false,
            coding: true,
        }
    }

    async fn send_message(
        &self,
        client: &reqwest::Client,
        api_key: &str,
        model: &str,
        messages: &[ChatMessage],
    ) -> Result<String, ProviderError> {
        // Anthropic's API takes "system" as a top-level field, not as a
        // message in the array — pull any system messages out and join them.
        let system: String = messages
            .iter()
            .filter(|m| m.role == "system")
            .map(|m| m.content.as_str())
            .collect::<Vec<_>>()
            .join("\n\n");

        let turns: Vec<serde_json::Value> = messages
            .iter()
            .filter(|m| m.role == "user" || m.role == "assistant")
            .map(|m| json!({ "role": m.role, "content": m.content }))
            .collect();

        if turns.is_empty() {
            return Err(ProviderError::InvalidResponse(
                "No user/assistant messages to send".to_string(),
            ));
        }

        let mut body = json!({
            "model": model,
            "max_tokens": 4096,
            "messages": turns,
        });
        if !system.trim().is_empty() {
            body["system"] = json!(system);
        }

        let resp = client
            .post(API_URL)
            .header("x-api-key", api_key)
            .header("anthropic-version", API_VERSION)
            .header("content-type", "application/json")
            .json(&body)
            .send()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;

        let status = resp.status();
        let text = resp
            .text()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;

        if !status.is_success() {
            let message = extract_error_message(&text).unwrap_or(text);
            return Err(ProviderError::Api {
                status: status.as_u16(),
                message,
            });
        }

        let parsed: AnthropicResponse = serde_json::from_str(&text)
            .map_err(|e| ProviderError::InvalidResponse(e.to_string()))?;

        let combined = parsed
            .content
            .into_iter()
            .filter_map(|block| block.text)
            .collect::<Vec<_>>()
            .join("\n");

        if combined.trim().is_empty() {
            return Err(ProviderError::InvalidResponse(
                "Provider returned no text content".to_string(),
            ));
        }

        Ok(combined)
    }
}

#[derive(Deserialize)]
struct AnthropicResponse {
    content: Vec<AnthropicContentBlock>,
}

#[derive(Deserialize)]
struct AnthropicContentBlock {
    #[serde(default)]
    text: Option<String>,
}

fn extract_error_message(body: &str) -> Option<String> {
    let v: serde_json::Value = serde_json::from_str(body).ok()?;
    v.get("error")?.get("message")?.as_str().map(String::from)
}
