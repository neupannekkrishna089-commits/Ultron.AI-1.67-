// Placeholder providers for the rest of the up-to-6 lineup.
//
// These exist so the Settings UI and capability metadata can show the full
// team roster (per the product spec) without pretending any of them work.
// `send_message` always returns `ProviderError::NotImplemented` — it makes
// no network call and fabricates no response. Capability numbers below are
// each vendor's current publicly documented figures at time of writing, not
// invented; `implemented` is what actually gates behavior, not this data.

use super::{AiProvider, ChatMessage, ProviderCapabilities, ProviderError};

pub struct StubProvider {
    id: &'static str,
    display_name: &'static str,
    default_model: &'static str,
    capabilities: ProviderCapabilities,
}

impl StubProvider {
    pub fn openai() -> Self {
        Self {
            id: "openai",
            display_name: "OpenAI",
            default_model: "gpt-5.1",
            capabilities: ProviderCapabilities {
                vision: true,
                tool_calling: true,
                context_window: 128_000,
                reasoning: true,
                research: false,
                coding: true,
            },
        }
    }

    pub fn gemini() -> Self {
        Self {
            id: "gemini",
            display_name: "Gemini (Google)",
            default_model: "gemini-3-pro",
            capabilities: ProviderCapabilities {
                vision: true,
                tool_calling: true,
                context_window: 1_000_000,
                reasoning: true,
                research: false,
                coding: true,
            },
        }
    }

    pub fn grok() -> Self {
        Self {
            id: "grok",
            display_name: "Grok (xAI)",
            default_model: "grok-4",
            capabilities: ProviderCapabilities {
                vision: true,
                tool_calling: true,
                context_window: 128_000,
                reasoning: true,
                research: false,
                coding: true,
            },
        }
    }

    pub fn perplexity() -> Self {
        Self {
            id: "perplexity",
            display_name: "Perplexity",
            default_model: "sonar-pro",
            capabilities: ProviderCapabilities {
                vision: false,
                tool_calling: false,
                context_window: 128_000,
                reasoning: false,
                research: true,
                coding: false,
            },
        }
    }

    pub fn deepseek() -> Self {
        Self {
            id: "deepseek",
            display_name: "DeepSeek",
            default_model: "deepseek-v3",
            capabilities: ProviderCapabilities {
                vision: false,
                tool_calling: true,
                context_window: 128_000,
                reasoning: true,
                research: false,
                coding: true,
            },
        }
    }
}

#[async_trait::async_trait]
impl AiProvider for StubProvider {
    fn id(&self) -> &'static str {
        self.id
    }

    fn display_name(&self) -> &'static str {
        self.display_name
    }

    fn implemented(&self) -> bool {
        false
    }

    fn default_model(&self) -> &'static str {
        self.default_model
    }

    fn capabilities(&self) -> ProviderCapabilities {
        self.capabilities.clone()
    }

    async fn send_message(
        &self,
        _client: &reqwest::Client,
        _api_key: &str,
        _model: &str,
        _messages: &[ChatMessage],
    ) -> Result<String, ProviderError> {
        Err(ProviderError::NotImplemented(self.display_name.to_string()))
    }
}
