// AI Core: provider abstraction.
//
// This module defines the one contract every AI provider must implement
// (`AiProvider`) plus a small registry. Phase 1 ships exactly one *real*
// implementation (Anthropic) and several honest stubs for the rest of the
// up-to-6-provider lineup the product spec calls for. Stubs exist so the
// Settings UI, capability metadata, and (future) orchestrator can already
// see the full provider shape — they never fabricate a response; calling
// one returns `ProviderError::NotImplemented`.
//
// Adding a real provider later means: write a new file in this folder that
// implements `AiProvider`, then swap its stub for the real struct in
// `registry()`. Nothing in main.rs, credentials.rs, or the frontend needs
// to change.

pub mod anthropic;
pub mod stub;

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChatMessage {
    pub role: String, // "system" | "user" | "assistant"
    pub content: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProviderCapabilities {
    pub vision: bool,
    pub tool_calling: bool,
    /// Approximate max context tokens. 0 means "unknown / not yet configured".
    pub context_window: u32,
    pub reasoning: bool,
    pub research: bool,
    pub coding: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProviderStatus {
    pub id: String,
    pub display_name: String,
    /// False for stub providers with no real HTTP implementation yet.
    pub implemented: bool,
    /// True if a key is present in the OS credential store.
    pub configured: bool,
    pub capabilities: ProviderCapabilities,
    pub default_model: String,
}

#[derive(Debug)]
pub enum ProviderError {
    NotImplemented(String),
    NotConfigured,
    Network(String),
    Api { status: u16, message: String },
    InvalidResponse(String),
}

impl std::fmt::Display for ProviderError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ProviderError::NotImplemented(name) => write!(
                f,
                "{name} isn't wired up yet — its client hasn't been implemented in this build."
            ),
            ProviderError::NotConfigured => {
                write!(f, "No API key is configured for this provider yet.")
            }
            ProviderError::Network(e) => write!(f, "Network error reaching provider: {e}"),
            ProviderError::Api { status, message } => {
                write!(f, "Provider returned an error (HTTP {status}): {message}")
            }
            ProviderError::InvalidResponse(e) => {
                write!(f, "Could not parse the provider's response: {e}")
            }
        }
    }
}

#[async_trait::async_trait]
pub trait AiProvider: Send + Sync {
    fn id(&self) -> &'static str;
    fn display_name(&self) -> &'static str;
    fn implemented(&self) -> bool;
    fn capabilities(&self) -> ProviderCapabilities;
    fn default_model(&self) -> &'static str;

    /// Send a full message history and get back the assistant's reply text.
    /// `api_key` is passed in by the dispatcher (read from secure storage) —
    /// implementations must never persist or log it themselves.
    async fn send_message(
        &self,
        client: &reqwest::Client,
        api_key: &str,
        model: &str,
        messages: &[ChatMessage],
    ) -> Result<String, ProviderError>;
}

/// The full lineup. Order is stable and matches what the Settings UI shows.
pub fn registry() -> Vec<Box<dyn AiProvider>> {
    vec![
        Box::new(anthropic::AnthropicProvider),
        Box::new(stub::StubProvider::openai()),
        Box::new(stub::StubProvider::gemini()),
        Box::new(stub::StubProvider::grok()),
        Box::new(stub::StubProvider::perplexity()),
        Box::new(stub::StubProvider::deepseek()),
    ]
}

pub fn find(provider_id: &str) -> Option<Box<dyn AiProvider>> {
    registry().into_iter().find(|p| p.id() == provider_id)
}

pub fn all_statuses() -> Vec<ProviderStatus> {
    registry()
        .into_iter()
        .map(|p| ProviderStatus {
            id: p.id().to_string(),
            display_name: p.display_name().to_string(),
            implemented: p.implemented(),
            configured: crate::credentials::has_key(p.id()),
            capabilities: p.capabilities(),
            default_model: p.default_model().to_string(),
        })
        .collect()
}

/// Look up a provider, load its key from secure storage, and dispatch the
/// request. This is the single choke point every chat send goes through —
/// it's what "ULTRON as orchestrator" will call into for each team member
/// once multi-provider modes exist; today it's used in SINGLE-provider mode
/// with whichever provider the user picked as default in Settings.
pub async fn dispatch(
    client: &reqwest::Client,
    provider_id: &str,
    model: &str,
    messages: &[ChatMessage],
) -> Result<String, ProviderError> {
    let provider = find(provider_id)
        .ok_or_else(|| ProviderError::NotImplemented(format!("Unknown provider '{provider_id}'")))?;

    if !provider.implemented() {
        return Err(ProviderError::NotImplemented(provider.display_name().to_string()));
    }

    let key = crate::credentials::get_key(provider_id)
        .map_err(ProviderError::Network)?
        .ok_or(ProviderError::NotConfigured)?;

    provider.send_message(client, &key, model, messages).await
}
