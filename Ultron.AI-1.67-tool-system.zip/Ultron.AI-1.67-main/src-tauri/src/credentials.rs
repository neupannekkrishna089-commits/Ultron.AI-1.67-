// Secure credential storage for AI provider API keys.
//
// Keys are written to the OS-native credential store (Windows Credential
// Manager via the `keyring` crate's default backend; Keychain/Secret
// Service on other platforms during dev). They are NEVER written to the
// SQLite kv_store, never logged, and never returned to the frontend — the
// only things that cross the Tauri IPC boundary for a key are:
//   - "was this saved successfully?" (bool / unit)
//   - "does a key already exist for this provider?" (bool)
// The raw key value itself is read back only inside this process, for the
// single purpose of attaching it to an outgoing HTTPS request in ai::dispatch.

const SERVICE_NAME: &str = "com.ultron.ai";

fn entry_for(provider: &str) -> Result<keyring::Entry, String> {
    keyring::Entry::new(SERVICE_NAME, provider)
        .map_err(|e| format!("Could not open secure credential store: {e}"))
}

/// Save (or overwrite) the API key for a provider. Never logs the key.
pub fn save_key(provider: &str, api_key: &str) -> Result<(), String> {
    if api_key.trim().is_empty() {
        return Err("API key cannot be empty".to_string());
    }
    let entry = entry_for(provider)?;
    entry
        .set_password(api_key.trim())
        .map_err(|e| format!("Failed to store key securely: {e}"))
}

/// Fetch the raw key for internal use only (e.g. building an HTTP request).
/// This must never be exposed via a #[tauri::command] return value.
pub fn get_key(provider: &str) -> Result<Option<String>, String> {
    let entry = entry_for(provider)?;
    match entry.get_password() {
        Ok(pw) => Ok(Some(pw)),
        Err(keyring::Error::NoEntry) => Ok(None),
        Err(e) => Err(format!("Failed to read secure credential store: {e}")),
    }
}

/// Whether a key is currently stored for a provider — safe to expose to the frontend.
pub fn has_key(provider: &str) -> bool {
    matches!(get_key(provider), Ok(Some(_)))
}

/// Remove a stored key entirely.
pub fn delete_key(provider: &str) -> Result<(), String> {
    let entry = entry_for(provider)?;
    match entry.delete_credential() {
        Ok(()) | Err(keyring::Error::NoEntry) => Ok(()),
        Err(e) => Err(format!("Failed to delete key: {e}")),
    }
}
