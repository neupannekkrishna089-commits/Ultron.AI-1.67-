import { useEffect, useState } from "react";
import {
  approveWorkspace,
  listWorkspaces,
  revokeWorkspace,
  selectWorkspaceDialog,
  type WorkspaceRecord,
} from "~/lib/tools";
import { IconCheck, IconFolder, IconTrash } from "~/components/icons";

type WorkspaceSettingsProps = {
  desktop: boolean;
};

/**
 * The permission surface for the Tool System (src-tauri/src/tools/):
 * nothing there will touch a directory the user hasn't explicitly
 * approved here. This panel only grants/revokes that approval — it has
 * no knowledge of what any tool or agent later does with it.
 */
export function WorkspaceSettings({ desktop }: WorkspaceSettingsProps) {
  const [workspaces, setWorkspaces] = useState<WorkspaceRecord[]>([]);
  const [loading, setLoading] = useState(desktop);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!desktop) {
      setLoading(false);
      return;
    }
    let cancelled = false;
    listWorkspaces()
      .then((ws) => {
        if (!cancelled) setWorkspaces(ws);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof Error ? err.message : String(err));
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [desktop]);

  const handleAddWorkspace = async () => {
    setBusy(true);
    setError(null);
    try {
      const picked = await selectWorkspaceDialog();
      if (!picked) return; // user cancelled the dialog
      const record = await approveWorkspace(picked);
      setWorkspaces((prev) => {
        const withoutDup = prev.filter((w) => w.id !== record.id);
        return [...withoutDup, record];
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  };

  const handleRevoke = async (id: string) => {
    setBusy(true);
    setError(null);
    try {
      await revokeWorkspace(id);
      setWorkspaces((prev) => prev.filter((w) => w.id !== id));
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="ultron-elevate mb-5 rounded-[14px] border border-graphite-700/70 bg-graphite-900">
      <div className="flex items-start gap-3 border-b border-graphite-700/60 px-5 py-4">
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[9px] bg-graphite-800 text-crimson ring-1 ring-inset ring-graphite-700">
          <IconFolder size={15} />
        </span>
        <div>
          <h2 className="text-[13px] font-medium text-ink">Tool workspaces</h2>
          <p className="mt-0.5 text-[12px] leading-relaxed text-ink-muted">
            Project directories you've approved for the Tool System to read and modify. Nothing —
            not ULTRON's own actions, not any AI provider, not a future coding agent — can touch a
            directory that isn't listed here. Add one only if you want it to be modifiable.
          </p>
        </div>
      </div>

      {!desktop && (
        <div className="mx-5 mt-4 rounded-[10px] border border-crimson/30 bg-crimson-soft/30 px-3.5 py-2.5 text-[11.5px] leading-relaxed text-crimson">
          Running in browser-preview mode — the Tool System operates on real files and processes,
          which requires the installed desktop app.
        </div>
      )}

      <div className="divide-y divide-graphite-700/50">
        {loading ? (
          <p className="px-5 py-5 text-[12.5px] text-ink-muted">Loading workspaces…</p>
        ) : workspaces.length === 0 ? (
          <p className="px-5 py-5 text-[12.5px] text-ink-muted">
            {desktop
              ? "No workspace approved yet. Add one below to let tools act on a project."
              : "Workspace list is unavailable in preview mode."}
          </p>
        ) : (
          workspaces.map((ws) => (
            <div key={ws.id} className="flex items-center gap-3 px-5 py-3.5">
              <div className="min-w-0 flex-1">
                <p className="truncate text-[12.5px] font-medium text-ink">{ws.label}</p>
                <p className="truncate text-[11px] text-ink-muted/80">{ws.root}</p>
              </div>
              <span className="flex shrink-0 items-center gap-1 rounded-full border border-emerald-700/50 bg-emerald-950/30 px-2 py-0.5 text-[10px] font-medium text-emerald-400">
                <IconCheck size={9} /> Approved
              </span>
              <button
                type="button"
                onClick={() => handleRevoke(ws.id)}
                disabled={busy}
                title="Revoke access"
                className="shrink-0 rounded-[8px] border border-graphite-700 p-1.5 text-ink-muted transition-colors duration-150 ease-out hover:border-crimson/40 hover:text-crimson disabled:opacity-50"
              >
                <IconTrash size={13} />
              </button>
            </div>
          ))
        )}
      </div>

      <div className="px-5 py-4">
        <button
          type="button"
          onClick={handleAddWorkspace}
          disabled={!desktop || busy}
          className="rounded-[9px] bg-crimson px-3.5 py-1.5 text-[12px] font-semibold text-white transition-all duration-150 ease-out hover:bg-crimson-hover active:scale-[0.97] disabled:cursor-not-allowed disabled:opacity-50"
        >
          {busy ? "Working…" : "Approve a project folder…"}
        </button>
        {error && <p className="mt-2.5 text-[11.5px] text-crimson">{error}</p>}
      </div>
    </section>
  );
}
