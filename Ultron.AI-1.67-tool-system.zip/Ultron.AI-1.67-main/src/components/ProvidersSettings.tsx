import { useState } from "react";
import type { ProviderId, ProviderStatus } from "~/lib/providers";
import type { ProviderPreference, Settings } from "~/lib/ultron";
import { IconCheck } from "~/components/icons";

type ProvidersSettingsProps = {
  settings: Settings;
  desktop: boolean;
  providerStatuses: ProviderStatus[];
  onSaveProviderKey: (provider: ProviderId, key: string) => Promise<void>;
  onDeleteProviderKey: (provider: ProviderId) => Promise<void>;
  onSetProviderPref: (provider: ProviderId, patch: Partial<ProviderPreference>) => void;
  onSetDefaultProvider: (provider: ProviderId) => void;
};

export function ProvidersSettings({
  settings,
  desktop,
  providerStatuses,
  onSaveProviderKey,
  onDeleteProviderKey,
  onSetProviderPref,
  onSetDefaultProvider,
}: ProvidersSettingsProps) {
  return (
    <section className="ultron-elevate mb-5 rounded-[14px] border border-graphite-700/70 bg-graphite-900">
      <div className="border-b border-graphite-700/60 px-5 py-4">
        <h2 className="text-[13px] font-medium text-ink">AI Team</h2>
        <p className="mt-0.5 text-[12px] leading-relaxed text-ink-muted">
          Add API keys for up to 6 providers. Keys are stored in your OS's secure credential
          store and never leave this device — ULTRON's frontend never sees them again once
          saved. Only one provider is wired up to actually respond right now (Claude); the rest
          are shown so you can see the planned lineup, but calling them will tell you plainly
          that they aren't implemented yet rather than faking a reply.
        </p>
      </div>

      {!desktop && (
        <div className="mx-5 mt-4 rounded-[10px] border border-crimson/30 bg-crimson-soft/30 px-3.5 py-2.5 text-[11.5px] leading-relaxed text-crimson">
          Running in browser-preview mode — secure key storage requires the installed desktop
          app.
        </div>
      )}

      <div className="divide-y divide-graphite-700/50">
        {providerStatuses.length === 0 ? (
          <p className="px-5 py-5 text-[12.5px] text-ink-muted">
            {desktop ? "Loading provider list…" : "Provider list is unavailable in preview mode."}
          </p>
        ) : (
          providerStatuses.map((status) => (
            <ProviderRow
              key={status.id}
              status={status}
              pref={settings.providers[status.id]}
              isDefault={settings.defaultProvider === status.id}
              desktop={desktop}
              onSaveKey={(key) => onSaveProviderKey(status.id, key)}
              onDeleteKey={() => onDeleteProviderKey(status.id)}
              onSetPref={(patch) => onSetProviderPref(status.id, patch)}
              onMakeDefault={() => onSetDefaultProvider(status.id)}
            />
          ))
        )}
      </div>
    </section>
  );
}

function ProviderRow({
  status,
  pref,
  isDefault,
  desktop,
  onSaveKey,
  onDeleteKey,
  onSetPref,
  onMakeDefault,
}: {
  status: ProviderStatus;
  pref: ProviderPreference | undefined;
  isDefault: boolean;
  desktop: boolean;
  onSaveKey: (key: string) => Promise<void>;
  onDeleteKey: () => Promise<void>;
  onSetPref: (patch: Partial<ProviderPreference>) => void;
  onMakeDefault: () => void;
}) {
  const [keyInput, setKeyInput] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [justSaved, setJustSaved] = useState(false);

  const model = pref?.model ?? status.defaultModel;
  const enabled = pref?.enabled ?? false;

  const handleSave = async () => {
    if (!keyInput.trim()) return;
    setSaving(true);
    setError(null);
    try {
      await onSaveKey(keyInput.trim());
      setKeyInput("");
      setJustSaved(true);
      window.setTimeout(() => setJustSaved(false), 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    setSaving(true);
    setError(null);
    try {
      await onDeleteKey();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="px-5 py-4">
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-[13px] font-medium text-ink">{status.displayName}</span>

        {!status.implemented && (
          <span className="rounded-full border border-graphite-600 px-2 py-0.5 text-[10px] font-medium text-ink-muted">
            Not implemented yet
          </span>
        )}

        {status.implemented && status.configured && (
          <span className="flex items-center gap-1 rounded-full border border-emerald-700/50 bg-emerald-950/30 px-2 py-0.5 text-[10px] font-medium text-emerald-400">
            <IconCheck size={9} /> Key configured
          </span>
        )}

        {isDefault && (
          <span className="rounded-full border border-crimson/40 bg-crimson-soft/30 px-2 py-0.5 text-[10px] font-medium text-crimson">
            Default
          </span>
        )}

        <div className="ml-auto flex items-center gap-3">
          {status.implemented && status.configured && !isDefault && (
            <button
              type="button"
              onClick={onMakeDefault}
              className="text-[11.5px] text-ink-muted underline-offset-2 hover:text-ink hover:underline"
            >
              Make default
            </button>
          )}
          <label className="flex items-center gap-1.5 text-[11.5px] text-ink-muted">
            <input
              type="checkbox"
              checked={enabled}
              disabled={!status.implemented || !status.configured}
              onChange={(e) => onSetPref({ enabled: e.target.checked, model })}
              className="h-3.5 w-3.5 accent-crimson"
            />
            Enabled
          </label>
        </div>
      </div>

      <p className="mt-1 text-[11px] text-ink-muted/80">
        {[
          status.capabilities.vision && "vision",
          status.capabilities.toolCalling && "tools",
          status.capabilities.reasoning && "reasoning",
          status.capabilities.research && "research",
          status.capabilities.coding && "coding",
        ]
          .filter(Boolean)
          .join(" · ") || "no capability data"}
        {status.capabilities.contextWindow > 0 &&
          ` · ${Math.round(status.capabilities.contextWindow / 1000)}k context`}
      </p>

      {status.implemented && (
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <input
            type="text"
            value={model}
            onChange={(e) => onSetPref({ model: e.target.value, enabled })}
            placeholder={status.defaultModel}
            className="w-44 rounded-[8px] border border-graphite-700 bg-graphite-850 px-2.5 py-1.5 text-[12px] text-ink placeholder:text-ink-muted/50 focus:border-crimson/50 focus:outline-none"
          />
          <input
            type="password"
            value={keyInput}
            onChange={(e) => setKeyInput(e.target.value)}
            placeholder={status.configured ? "Replace API key…" : "Paste API key…"}
            disabled={!desktop || saving}
            className="min-w-0 flex-1 rounded-[8px] border border-graphite-700 bg-graphite-850 px-2.5 py-1.5 text-[12px] text-ink placeholder:text-ink-muted/50 focus:border-crimson/50 focus:outline-none disabled:opacity-50"
          />
          <button
            type="button"
            onClick={handleSave}
            disabled={!desktop || saving || !keyInput.trim()}
            className="rounded-[8px] bg-crimson px-3 py-1.5 text-[11.5px] font-semibold text-white transition-colors duration-150 ease-out hover:bg-crimson-hover disabled:cursor-not-allowed disabled:opacity-50"
          >
            Save
          </button>
          {status.configured && (
            <button
              type="button"
              onClick={handleDelete}
              disabled={!desktop || saving}
              className="rounded-[8px] border border-graphite-700 px-3 py-1.5 text-[11.5px] text-ink-muted transition-colors duration-150 ease-out hover:border-graphite-600 hover:text-ink disabled:opacity-50"
            >
              Remove
            </button>
          )}
          {justSaved && (
            <span className="flex items-center gap-1 text-[11px] font-medium text-emerald-400">
              <IconCheck size={11} /> Saved
            </span>
          )}
        </div>
      )}

      {error && <p className="mt-2 text-[11.5px] text-crimson">{error}</p>}
    </div>
  );
}
