// Thin client over the Rust-side AI Core commands (see src-tauri/src/ai/).
//
// Nothing here ever sees a raw API key except the moment the user types one
// in to save it — from then on the frontend only ever asks "is <provider>
// configured?" (bool) and "send this message" (returns text or an error).
// The key itself lives in the OS credential store on the Rust side.

import { isDesktop } from "~/lib/storage";

export type ProviderId = "anthropic" | "openai" | "gemini" | "grok" | "perplexity" | "deepseek";

export type ProviderCapabilities = {
  vision: boolean;
  toolCalling: boolean;
  contextWindow: number;
  reasoning: boolean;
  research: boolean;
  coding: boolean;
};

export type ProviderStatus = {
  id: ProviderId;
  displayName: string;
  /** False for providers that don't have a real HTTP client wired up yet. */
  implemented: boolean;
  /** True if a key is currently stored for this provider. */
  configured: boolean;
  capabilities: ProviderCapabilities;
  defaultModel: string;
};

export type ChatRole = "system" | "user" | "assistant";
export type AiChatMessage = { role: ChatRole; content: string };

// The Rust side uses snake_case field names (serde default); this is the
// shape that actually crosses IPC before we normalize it below.
type RawProviderStatus = {
  id: string;
  display_name: string;
  implemented: boolean;
  configured: boolean;
  capabilities: {
    vision: boolean;
    tool_calling: boolean;
    context_window: number;
    reasoning: boolean;
    research: boolean;
    coding: boolean;
  };
  default_model: string;
};

function normalize(raw: RawProviderStatus): ProviderStatus {
  return {
    id: raw.id as ProviderId,
    displayName: raw.display_name,
    implemented: raw.implemented,
    configured: raw.configured,
    defaultModel: raw.default_model,
    capabilities: {
      vision: raw.capabilities.vision,
      toolCalling: raw.capabilities.tool_calling,
      contextWindow: raw.capabilities.context_window,
      reasoning: raw.capabilities.reasoning,
      research: raw.capabilities.research,
      coding: raw.capabilities.coding,
    },
  };
}

async function invokeTauri<T>(cmd: string, args?: Record<string, unknown>): Promise<T> {
  const { invoke } = await import("@tauri-apps/api/core");
  return invoke<T>(cmd, args);
}

const DESKTOP_ONLY_MESSAGE =
  "AI providers require the desktop app — keys are stored in your OS's secure credential store, which isn't available in this browser preview.";

export async function listProviders(): Promise<ProviderStatus[]> {
  if (!isDesktop()) return [];
  const raw = await invokeTauri<RawProviderStatus[]>("list_providers");
  return raw.map(normalize);
}

export async function saveProviderKey(provider: ProviderId, apiKey: string): Promise<void> {
  if (!isDesktop()) throw new Error(DESKTOP_ONLY_MESSAGE);
  await invokeTauri<void>("save_provider_key", { provider, apiKey });
}

export async function deleteProviderKey(provider: ProviderId): Promise<void> {
  if (!isDesktop()) return;
  await invokeTauri<void>("delete_provider_key", { provider });
}

export async function hasProviderKey(provider: ProviderId): Promise<boolean> {
  if (!isDesktop()) return false;
  return invokeTauri<boolean>("has_provider_key", { provider });
}

/** Sends the full message history to one provider and returns its reply text. */
export async function sendAiMessage(
  provider: ProviderId,
  model: string,
  messages: AiChatMessage[],
): Promise<string> {
  if (!isDesktop()) throw new Error(DESKTOP_ONLY_MESSAGE);
  return invokeTauri<string>("send_ai_message", { provider, model, messages });
}
