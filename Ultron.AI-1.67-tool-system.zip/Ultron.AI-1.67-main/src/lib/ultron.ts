// ULTRON core library: types, persistence (via ~/lib/storage), formatting
// helpers, shortcut matching, and the local mock reply. No AI, no network.

import { getItem, setItem } from "~/lib/storage";
import type { ProviderId } from "~/lib/providers";

export type Shortcut = {
  ctrl: boolean;
  alt: boolean;
  shift: boolean;
  meta: boolean;
  key: string; // normalized: " " for space, lowercase for letters, else raw e.key
};

// Per-provider preferences the user controls from Settings. This is
// deliberately everything EXCEPT the secret: the API key itself never
// touches this object or the kv_store it's persisted through — it lives
// only in the OS credential store, reachable solely via src/lib/providers.ts.
export type ProviderPreference = {
  model: string;
  /** User's on/off toggle — independent of whether a key is configured. */
  enabled: boolean;
};

export type Settings = {
  activationShortcut: Shortcut;
  /** Which configured provider ULTRON uses in single-provider mode. */
  defaultProvider: ProviderId;
  providers: Partial<Record<ProviderId, ProviderPreference>>;
};

export type Attachment = {
  name: string;
  size: number;
};

export type Message = {
  id: string;
  role: "user" | "assistant";
  text: string;
  attachment?: Attachment;
  at: number; // epoch ms
  /** Set when this assistant message reports a failure rather than a real reply. */
  isError?: boolean;
};

export type Conversation = {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: Message[];
};

export const APP_VERSION = "0.1.0";
export const APP_NAME = "ULTRON";
export const APP_TAGLINE = "Personal AI for Windows";

const CONVERSATIONS_KEY = "ultron.conversations.v1";
const ACTIVE_KEY = "ultron.activeConversation.v1";
const SETTINGS_KEY = "ultron.settings.v1";

export const DEFAULT_SHORTCUT: Shortcut = {
  ctrl: true,
  alt: false,
  shift: false,
  meta: false,
  key: " ",
};

export const DEFAULT_SETTINGS: Settings = {
  activationShortcut: DEFAULT_SHORTCUT,
  defaultProvider: "anthropic",
  providers: {},
};

export function uid(): string {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

async function loadJSON<T>(key: string): Promise<T | null> {
  const raw = await getItem(key);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

async function saveJSON(key: string, value: unknown): Promise<void> {
  await setItem(key, JSON.stringify(value));
}

export async function loadConversations(): Promise<Conversation[] | null> {
  return loadJSON<Conversation[]>(CONVERSATIONS_KEY);
}
export async function saveConversations(convs: Conversation[]): Promise<void> {
  await saveJSON(CONVERSATIONS_KEY, convs);
}
export async function loadActiveId(): Promise<string | null> {
  return loadJSON<string>(ACTIVE_KEY);
}
export async function saveActiveId(id: string): Promise<void> {
  await saveJSON(ACTIVE_KEY, id);
}
export async function loadSettings(): Promise<Settings | null> {
  const s = await loadJSON<Partial<Settings>>(SETTINGS_KEY);
  if (
    s &&
    s.activationShortcut &&
    typeof s.activationShortcut.key === "string" &&
    typeof s.activationShortcut.ctrl === "boolean"
  ) {
    // Merge onto defaults so settings saved before providers/defaultProvider
    // existed (older versions of this file) still load cleanly.
    return {
      activationShortcut: s.activationShortcut,
      defaultProvider: s.defaultProvider ?? DEFAULT_SETTINGS.defaultProvider,
      providers: s.providers ?? {},
    };
  }
  return null;
}
export async function saveSettings(s: Settings): Promise<void> {
  await saveJSON(SETTINGS_KEY, s);
}

export function createWelcomeConversation(): Conversation {
  const now = Date.now();
  return {
    id: uid(),
    title: "New chat",
    createdAt: now,
    updatedAt: now,
    messages: [
      {
        id: uid(),
        role: "assistant",
        text:
          "Welcome to ULTRON — your personal AI assistant for Windows.\n\nOpen Settings to add an API key for a provider (Claude is the one fully wired up so far). Once configured, messages you send here go straight to that provider — nothing is faked or mocked.",
        at: now,
      },
    ],
  };
}

// ---- formatting -----------------------------------------------------------

export function formatTime(ts: number): string {
  return new Date(ts).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  const m = Math.floor(diff / 60_000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d}d ago`;
  return new Date(ts).toLocaleDateString([], { month: "short", day: "numeric" });
}

export function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function deriveTitle(text: string): string {
  const clean = text.replace(/\s+/g, " ").trim();
  return clean.length > 36 ? clean.slice(0, 36).trimEnd() + "…" : clean;
}

// ---- shortcuts ------------------------------------------------------------

/** Normalize an e.key value so matching is case/name stable. */
export function normalizeKey(key: string): string {
  if (key === " ") return " ";
  if (key.length === 1) return key.toLowerCase();
  return key; // "ArrowUp", "F5", "Tab", ...
}

export type KeyEventLike = {
  key: string;
  ctrlKey: boolean;
  altKey: boolean;
  shiftKey: boolean;
  metaKey: boolean;
};

export function matchesShortcut(e: KeyEventLike, s: Shortcut): boolean {
  return (
    e.ctrlKey === s.ctrl &&
    e.altKey === s.alt &&
    e.shiftKey === s.shift &&
    e.metaKey === s.meta &&
    normalizeKey(e.key) === s.key
  );
}

export function shortcutParts(s: Shortcut): string[] {
  const parts: string[] = [];
  if (s.ctrl) parts.push("Ctrl");
  if (s.alt) parts.push("Alt");
  if (s.shift) parts.push("Shift");
  if (s.meta) parts.push("Win");
  parts.push(s.key === " " ? "Space" : s.key.length === 1 ? s.key.toUpperCase() : s.key);
  return parts;
}

export function shortcutToLabel(s: Shortcut): string {
  return shortcutParts(s).join(" + ");
}

export function shortcutsEqual(a: Shortcut, b: Shortcut): boolean {
  return (
    a.ctrl === b.ctrl &&
    a.alt === b.alt &&
    a.shift === b.shift &&
    a.meta === b.meta &&
    normalizeKey(a.key) === normalizeKey(b.key)
  );
}


