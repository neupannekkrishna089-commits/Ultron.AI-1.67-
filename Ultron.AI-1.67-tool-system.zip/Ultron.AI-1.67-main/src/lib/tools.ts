// Thin client over the Rust-side Tool System commands (see
// src-tauri/src/tools/). Mirrors the shape of ~/lib/providers.ts: this
// file has no dependency on that one and no dependency on anything
// chat/agent-specific — it's usable by any future caller (a coding-agent
// panel, a generic "run a tool" debug view, the Router) that wants to
// list tools, manage workspace approval, or invoke a tool call.

import { isDesktop } from "~/lib/storage";

export type ToolCategory = "inspect" | "read" | "search" | "write" | "execute";
export type RiskLevel = "safe" | "write" | "destructive";

export type ToolParam = {
  name: string;
  kind: "string" | "number" | "boolean" | "array" | "object";
  description: string;
  required: boolean;
};

export type ToolSpec = {
  id: string;
  name: string;
  description: string;
  category: ToolCategory;
  risk: RiskLevel;
  params: ToolParam[];
};

export type WorkspaceRecord = {
  id: string;
  root: string;
  label: string;
  approvedAt: number;
};

// Rust's serde default is snake_case for struct fields; normalize here so
// the rest of the app only ever sees camelCase, same pattern as
// ~/lib/providers.ts's `normalize()`.
type RawWorkspaceRecord = { id: string; root: string; label: string; approved_at: number };

function normalizeWorkspace(raw: RawWorkspaceRecord): WorkspaceRecord {
  return { id: raw.id, root: raw.root, label: raw.label, approvedAt: raw.approved_at };
}

export type ToolCallResult =
  | { status: "ok"; summary: string; data: unknown }
  | { status: "confirmation_required"; preview: string };

async function invokeTauri<T>(cmd: string, args?: Record<string, unknown>): Promise<T> {
  const { invoke } = await import("@tauri-apps/api/core");
  return invoke<T>(cmd, args);
}

const DESKTOP_ONLY_MESSAGE =
  "The Tool System requires the desktop app — it operates on real files and processes on this device, which isn't available in this browser preview.";

/** The full tool lineup and their JSON-schema-like parameter shapes. */
export async function listToolSpecs(): Promise<ToolSpec[]> {
  if (!isDesktop()) return [];
  return invokeTauri<ToolSpec[]>("list_tool_specs");
}

/** Opens a native folder picker. Resolves to null if the user cancelled. */
export async function selectWorkspaceDialog(): Promise<string | null> {
  if (!isDesktop()) throw new Error(DESKTOP_ONLY_MESSAGE);
  return invokeTauri<string | null>("select_workspace_dialog");
}

/** Explicit approval step — required before any tool call against `path` will work. */
export async function approveWorkspace(path: string, label?: string): Promise<WorkspaceRecord> {
  if (!isDesktop()) throw new Error(DESKTOP_ONLY_MESSAGE);
  const raw = await invokeTauri<RawWorkspaceRecord>("approve_workspace", { path, label });
  return normalizeWorkspace(raw);
}

export async function listWorkspaces(): Promise<WorkspaceRecord[]> {
  if (!isDesktop()) return [];
  const raw = await invokeTauri<RawWorkspaceRecord[]>("list_workspaces");
  return raw.map(normalizeWorkspace);
}

export async function revokeWorkspace(id: string): Promise<void> {
  if (!isDesktop()) return;
  await invokeTauri<void>("revoke_workspace", { id });
}

/**
 * The single entry point for every tool invocation. `confirmed` should
 * only ever be `true` when the user has explicitly approved *this*
 * specific destructive call (e.g. after being shown the
 * `confirmation_required` preview from a prior call with the same args).
 */
export async function callTool(
  workspaceId: string,
  toolId: string,
  args: Record<string, unknown>,
  confirmed = false,
): Promise<ToolCallResult> {
  if (!isDesktop()) throw new Error(DESKTOP_ONLY_MESSAGE);
  return invokeTauri<ToolCallResult>("call_tool", {
    workspaceId,
    toolId,
    args,
    confirmed,
  });
}
