// ULTRON Web Research Engine — network primitives (Rust side).
//
// This module owns exactly two privileged operations: searching the web and
// fetching+extracting a single page. Everything else in the research
// pipeline (planning, source-quality scoring, cross-checking, synthesis,
// citations) is orchestrated in TypeScript (see src/lib/research) and calls
// these two commands as tools — the same "Rust owns the network/keys,
// TypeScript owns the logic" boundary already used by the AI Core.
//
// Search: Brave Search API (chosen as the one implemented backend, same
// reasoning as Anthropic being the one implemented AI provider). The API key
// is stored via the same keyring-backed set_api_key/has_api_key/clear_api_key
// commands already used for AI provider keys, just under the id
// "brave_search" — no new key-management commands needed.
//
// Fetch: a capped, best-effort HTML text extractor. Pages are read up to a
// hard byte limit (never the whole internet loaded into memory on a
// low-power machine), then reduced to visible text with `scraper` — no
// JavaScript execution, no arbitrary code from the page ever runs.

use futures_util::StreamExt;
use serde::Serialize;

use crate::ai::get_api_key;

const MAX_FETCH_BYTES: usize = 1_500_000; // ~1.5MB cap per page
const MAX_EXTRACTED_CHARS: usize = 6_000; // per-page cap handed back to the caller

#[derive(Clone, Serialize)]
pub struct SearchResultDto {
    pub title: String,
    pub url: String,
    pub snippet: String,
}

#[derive(Clone, Serialize)]
pub struct ExtractedPageDto {
    pub url: String,
    pub domain: String,
    pub title: String,
    pub published_at: Option<String>,
    pub content: String,
    pub truncated: bool,
}

fn domain_of(url: &str) -> String {
    let without_scheme = url.split("://").nth(1).unwrap_or(url);
    without_scheme.split('/').next().unwrap_or(without_scheme).to_string()
}

#[tauri::command]
pub async fn web_search(query: String) -> Result<Vec<SearchResultDto>, String> {
    let api_key = get_api_key("brave_search")
        .map_err(|e| e.to_string())?
        .ok_or_else(|| "no_api_key".to_string())?;

    let client = reqwest::Client::new();
    let response = client
        .get("https://api.search.brave.com/res/v1/web/search")
        .query(&[("q", query.as_str()), ("count", "8")])
        .header("Accept", "application/json")
        .header("X-Subscription-Token", api_key)
        .send()
        .await
        .map_err(|e| format!("network_error: {e}"))?;

    if !response.status().is_success() {
        let status = response.status().as_u16();
        let body = response.text().await.unwrap_or_default();
        return Err(format!("search_failed: HTTP {status} — {body}"));
    }

    let json: serde_json::Value = response.json().await.map_err(|e| format!("bad_response: {e}"))?;
    let results = json
        .pointer("/web/results")
        .and_then(|v| v.as_array())
        .cloned()
        .unwrap_or_default();

    Ok(results
        .into_iter()
        .filter_map(|r| {
            let title = r.get("title")?.as_str()?.to_string();
            let url = r.get("url")?.as_str()?.to_string();
            let snippet = r
                .get("description")
                .and_then(|v| v.as_str())
                .unwrap_or("")
                .to_string();
            Some(SearchResultDto { title, url, snippet })
        })
        .collect())
}

#[tauri::command]
pub async fn fetch_page(url: String) -> Result<ExtractedPageDto, String> {
    let client = reqwest::Client::builder()
        .timeout(std::time::Duration::from_secs(12))
        .build()
        .map_err(|e| e.to_string())?;

    let response = client
        .get(&url)
        .header("User-Agent", "Mozilla/5.0 (compatible; ULTRON-desktop-assistant/0.1)")
        .send()
        .await
        .map_err(|e| format!("network_error: {e}"))?;

    if !response.status().is_success() {
        return Err(format!("http_error: HTTP {}", response.status().as_u16()));
    }

    let content_type = response
        .headers()
        .get("content-type")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("")
        .to_string();
    if !content_type.is_empty() && !content_type.contains("html") && !content_type.contains("text") {
        return Err(format!("unsupported_content_type: {content_type}"));
    }

    let mut body = Vec::with_capacity(64 * 1024);
    let mut stream = response.bytes_stream();
    while let Some(chunk) = stream.next().await {
        let bytes = chunk.map_err(|e| format!("network_error: {e}"))?;
        body.extend_from_slice(&bytes);
        if body.len() >= MAX_FETCH_BYTES {
            break;
        }
    }

    let html = String::from_utf8_lossy(&body).to_string();
    let (title, text, published_at) = extract_html(&html);
    let truncated = text.chars().count() > MAX_EXTRACTED_CHARS;
    let content: String = text.chars().take(MAX_EXTRACTED_CHARS).collect();

    Ok(ExtractedPageDto {
        domain: domain_of(&url),
        url,
        title,
        published_at,
        content,
        truncated,
    })
}

/// Reduces a raw HTML document to (title, visible body text, best-effort
/// publish date). No JavaScript is executed and nothing from the page is
/// ever treated as instructions — this is plain text extraction, and the
/// result is handed to the AI Core only as untrusted reference content.
///
/// Deliberately pulls text only from content-bearing tags (paragraphs,
/// headings, list items, table cells, article/section text) rather than
/// walking the whole DOM tree — this naturally excludes script/style/nav
/// noise without needing a custom recursive tree walker, at the cost of
/// occasionally missing text in less-common tags.
fn extract_html(html: &str) -> (String, String, Option<String>) {
    use scraper::{Html, Selector};

    let doc = Html::parse_document(html);

    let title = Selector::parse("title")
        .ok()
        .and_then(|sel| doc.select(&sel).next())
        .map(|el| el.text().collect::<String>().trim().to_string())
        .unwrap_or_default();

    let published_at = ["meta[property='article:published_time']", "meta[name='date']", "time[datetime]"]
        .iter()
        .find_map(|sel_str| {
            let sel = Selector::parse(sel_str).ok()?;
            let el = doc.select(&sel).next()?;
            el.value()
                .attr("content")
                .or_else(|| el.value().attr("datetime"))
                .map(|s| s.to_string())
        });

    let content_selector =
        Selector::parse("p, h1, h2, h3, h4, h5, h6, li, td, th, article, blockquote, figcaption")
            .unwrap_or_else(|_| Selector::parse("p").unwrap());

    let mut parts: Vec<String> = doc
        .select(&content_selector)
        .map(|el| el.text().collect::<Vec<_>>().join(" ").trim().to_string())
        .filter(|s| !s.is_empty())
        .collect();

    if parts.is_empty() {
        // Fallback for pages that don't use conventional content tags —
        // less clean (may include some nav/script text) but better than
        // returning nothing.
        parts.push(doc.root_element().text().collect::<Vec<_>>().join(" "));
    }

    let joined = parts.join("\n\n");
    let normalized = joined
        .lines()
        .map(|l| l.split_whitespace().collect::<Vec<_>>().join(" "))
        .filter(|l| !l.is_empty())
        .collect::<Vec<_>>()
        .join("\n\n");

    (title, normalized, published_at)
}
