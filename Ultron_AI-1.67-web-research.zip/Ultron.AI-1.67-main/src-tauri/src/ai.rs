// ULTRON AI Core (Rust side) — foundation phase.
//
// This module is the ONLY place that holds provider API keys or makes
// outbound AI requests. The frontend never sees a raw key: it calls
// `set_api_key`/`has_api_key`/`clear_api_key` (which only report yes/no,
// never the value), and `send_chat_message`/`cancel_ai_request` to run or
// stop a request. That boundary is deliberate — see the security notes in
// the top-level project report.
//
// Only the Anthropic provider is implemented right now (chosen as the
// easiest to integrate reliably for this project). OpenAI/Gemini/Grok/
// OpenRouter are named in `KNOWN_PROVIDERS` so the frontend can list them as
// "coming soon" without pretending they work — calling them returns a clear
// `provider_unavailable` error rather than silently failing or faking a
// reply.

use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};

use futures_util::StreamExt;
use serde::{Deserialize, Serialize};
use tauri::{AppHandle, Emitter, State};

const KEYRING_SERVICE: &str = "ultron";

/// Providers ULTRON knows the *name* of. Only "anthropic" is wired up to an
/// actual implementation this phase — the rest exist so Settings/the router
/// have stable ids to reference ahead of time.
pub const KNOWN_PROVIDERS: &[&str] = &["anthropic", "openai", "google", "xai", "openrouter"];
const IMPLEMENTED_PROVIDERS: &[&str] = &["anthropic"];

#[derive(Clone, Serialize, Deserialize)]
pub struct ChatMessage {
    pub role: String, // "user" | "assistant" — system goes in `system` below, not here
    pub content: String,
}

#[derive(Deserialize)]
pub struct SendChatRequest {
    pub request_id: String,
    pub provider: String,
    pub model: String,
    pub system: Option<String>,
    pub messages: Vec<ChatMessage>,
    pub temperature: Option<f32>,
    pub max_tokens: Option<u32>,
}

#[derive(Clone, Serialize)]
pub struct AiUsage {
    #[serde(rename = "inputTokens")]
    pub input_tokens: Option<u32>,
    #[serde(rename = "outputTokens")]
    pub output_tokens: Option<u32>,
}

#[derive(Clone, Serialize)]
pub struct AiErrorPayload {
    #[serde(rename = "requestId")]
    pub request_id: String,
    /// Stable machine-readable code the frontend switches on — see
    /// src/lib/ai/types.ts `AIErrorCode` for the matching union.
    pub code: &'static str,
    pub message: String,
}

#[derive(Clone, Serialize)]
struct AiStreamPayload {
    #[serde(rename = "requestId")]
    request_id: String,
    delta: String,
}

#[derive(Clone, Serialize)]
struct AiDonePayload {
    #[serde(rename = "requestId")]
    request_id: String,
    usage: AiUsage,
}

#[derive(Default)]
pub struct AiState {
    cancel_flags: Mutex<HashMap<String, Arc<AtomicBool>>>,
}

fn emit_error(app: &AppHandle, request_id: &str, code: &'static str, message: impl Into<String>) {
    let message = message.into();
    // Deliberately no key material ever reaches this log line — only the
    // error class and provider-supplied message text.
    log::warn!("[ai] request {request_id} failed ({code}): {message}");
    let _ = app.emit(
        "ultron://ai-error",
        AiErrorPayload { request_id: request_id.to_string(), code, message },
    );
}

// ---- secure key storage ----------------------------------------------------

#[tauri::command]
pub fn set_api_key(provider: String, key: String) -> Result<(), String> {
    let entry = keyring::Entry::new(KEYRING_SERVICE, &provider).map_err(|e| e.to_string())?;
    entry.set_password(&key).map_err(|e| e.to_string())?;
    log::info!("[ai] API key saved for provider '{provider}'"); // never logs the key itself
    Ok(())
}

#[tauri::command]
pub fn has_api_key(provider: String) -> Result<bool, String> {
    let entry = keyring::Entry::new(KEYRING_SERVICE, &provider).map_err(|e| e.to_string())?;
    match entry.get_password() {
        Ok(_) => Ok(true),
        Err(keyring::Error::NoEntry) => Ok(false),
        Err(e) => Err(e.to_string()),
    }
}

#[tauri::command]
pub fn clear_api_key(provider: String) -> Result<(), String> {
    let entry = keyring::Entry::new(KEYRING_SERVICE, &provider).map_err(|e| e.to_string())?;
    match entry.delete_credential() {
        Ok(()) | Err(keyring::Error::NoEntry) => {
            log::info!("[ai] API key cleared for provider '{provider}'");
            Ok(())
        }
        Err(e) => Err(e.to_string()),
    }
}

/// Shared with other tool subsystems (e.g. research.rs) that also need a
/// user-configured API key looked up by provider id — no logic here
/// changes, only visibility, so the AI Core's own behavior is untouched.
pub(crate) fn get_api_key(provider: &str) -> Result<Option<String>, String> {
    let entry = keyring::Entry::new(KEYRING_SERVICE, provider).map_err(|e| e.to_string())?;
    match entry.get_password() {
        Ok(pw) => Ok(Some(pw)),
        Err(keyring::Error::NoEntry) => Ok(None),
        Err(e) => Err(e.to_string()),
    }
}

// ---- request lifecycle ------------------------------------------------------

#[tauri::command]
pub async fn cancel_ai_request(state: State<'_, AiState>, request_id: String) -> Result<(), String> {
    if let Some(flag) = state.cancel_flags.lock().unwrap().get(&request_id) {
        flag.store(true, Ordering::SeqCst);
    }
    Ok(())
}

#[tauri::command]
pub async fn send_chat_message(
    app: AppHandle,
    state: State<'_, AiState>,
    req: SendChatRequest,
) -> Result<(), String> {
    let request_id = req.request_id.clone();
    let cancel_flag = Arc::new(AtomicBool::new(false));
    state
        .cancel_flags
        .lock()
        .unwrap()
        .insert(request_id.clone(), cancel_flag.clone());

    let result = run_request(&app, &req, &cancel_flag).await;

    state.cancel_flags.lock().unwrap().remove(&request_id);

    if let Err((code, message)) = result {
        emit_error(&app, &request_id, code, message);
    }
    Ok(())
}

async fn run_request(
    app: &AppHandle,
    req: &SendChatRequest,
    cancel_flag: &Arc<AtomicBool>,
) -> Result<(), (&'static str, String)> {
    if !IMPLEMENTED_PROVIDERS.contains(&req.provider.as_str()) {
        return Err((
            "provider_unavailable",
            format!("'{}' isn't wired up to a real implementation yet.", req.provider),
        ));
    }

    let api_key = get_api_key(&req.provider)
        .map_err(|e| ("provider_unavailable", e))?
        .ok_or(("no_api_key", "No API key is saved for this provider yet.".to_string()))?;

    match req.provider.as_str() {
        "anthropic" => run_anthropic(app, req, &api_key, cancel_flag).await,
        _ => unreachable!("checked by IMPLEMENTED_PROVIDERS above"),
    }
}

// ---- Anthropic adapter -------------------------------------------------------
//
// Talks to the Messages API (https://docs.anthropic.com/en/api/messages-streaming)
// with `stream: true` and parses the server-sent-events body chunk by chunk,
// forwarding text deltas to the frontend as they arrive rather than
// buffering the whole reply.

async fn run_anthropic(
    app: &AppHandle,
    req: &SendChatRequest,
    api_key: &str,
    cancel_flag: &Arc<AtomicBool>,
) -> Result<(), (&'static str, String)> {
    let client = reqwest::Client::new();

    let body = serde_json::json!({
        "model": req.model,
        "system": req.system,
        "messages": req.messages.iter().map(|m| serde_json::json!({
            "role": m.role,
            "content": m.content,
        })).collect::<Vec<_>>(),
        "max_tokens": req.max_tokens.unwrap_or(1024),
        "temperature": req.temperature,
        "stream": true,
    });

    let response = client
        .post("https://api.anthropic.com/v1/messages")
        .header("x-api-key", api_key)
        .header("anthropic-version", "2023-06-01")
        .header("content-type", "application/json")
        .json(&body)
        .send()
        .await
        .map_err(|e| classify_reqwest_error(&e))?;

    let status = response.status();
    if !status.is_success() {
        let text = response.text().await.unwrap_or_default();
        return Err(classify_http_status(status.as_u16(), &text));
    }

    let mut stream = response.bytes_stream();
    let mut buf = String::new();
    let mut usage = AiUsage { input_tokens: None, output_tokens: None };

    while let Some(chunk) = stream.next().await {
        if cancel_flag.load(Ordering::SeqCst) {
            return Err(("cancelled", "Cancelled by the user.".to_string()));
        }
        let bytes = chunk.map_err(|e| classify_reqwest_error(&e))?;
        buf.push_str(&String::from_utf8_lossy(&bytes));

        // SSE frames are separated by a blank line; process complete frames
        // as they accumulate and leave any partial trailing frame in `buf`.
        while let Some(pos) = buf.find("\n\n") {
            let frame = buf[..pos].to_string();
            buf.drain(..pos + 2);
            handle_sse_frame(app, &req.request_id, &frame, &mut usage)?;
        }
    }

    let _ = app.emit(
        "ultron://ai-done",
        AiDonePayload { request_id: req.request_id.clone(), usage },
    );
    Ok(())
}

fn handle_sse_frame(
    app: &AppHandle,
    request_id: &str,
    frame: &str,
    usage: &mut AiUsage,
) -> Result<(), (&'static str, String)> {
    let mut data_line: Option<&str> = None;
    for line in frame.lines() {
        if let Some(rest) = line.strip_prefix("data:") {
            data_line = Some(rest.trim());
        }
    }
    let Some(data) = data_line else { return Ok(()) };
    let Ok(json) = serde_json::from_str::<serde_json::Value>(data) else { return Ok(()) };

    match json.get("type").and_then(|v| v.as_str()) {
        Some("content_block_delta") => {
            if let Some(text) = json
                .pointer("/delta/text")
                .and_then(|v| v.as_str())
            {
                let _ = app.emit(
                    "ultron://ai-stream",
                    AiStreamPayload { request_id: request_id.to_string(), delta: text.to_string() },
                );
            }
        }
        Some("message_start") => {
            if let Some(n) = json.pointer("/message/usage/input_tokens").and_then(|v| v.as_u64()) {
                usage.input_tokens = Some(n as u32);
            }
        }
        Some("message_delta") => {
            if let Some(n) = json.pointer("/usage/output_tokens").and_then(|v| v.as_u64()) {
                usage.output_tokens = Some(n as u32);
            }
        }
        Some("error") => {
            let message = json
                .pointer("/error/message")
                .and_then(|v| v.as_str())
                .unwrap_or("The provider reported an error.")
                .to_string();
            let kind = json.pointer("/error/type").and_then(|v| v.as_str()).unwrap_or("");
            let code = match kind {
                "rate_limit_error" => "rate_limited",
                "authentication_error" | "permission_error" => "invalid_api_key",
                "overloaded_error" => "provider_unavailable",
                "not_found_error" => "model_unavailable",
                _ => "provider_unavailable",
            };
            return Err((code, message));
        }
        _ => {}
    }
    Ok(())
}

fn classify_http_status(status: u16, body: &str) -> (&'static str, String) {
    let message = extract_error_message(body).unwrap_or_else(|| format!("HTTP {status}"));
    let code = match status {
        401 | 403 => "invalid_api_key",
        404 => "model_unavailable",
        408 => "timeout",
        429 => "rate_limited",
        500..=599 => "provider_unavailable",
        _ => "provider_unavailable",
    };
    (code, message)
}

fn extract_error_message(body: &str) -> Option<String> {
    let json: serde_json::Value = serde_json::from_str(body).ok()?;
    json.pointer("/error/message")
        .and_then(|v| v.as_str())
        .map(|s| s.to_string())
}

fn classify_reqwest_error(e: &reqwest::Error) -> (&'static str, String) {
    if e.is_timeout() {
        ("timeout", "The request timed out.".to_string())
    } else if e.is_connect() {
        ("network_error", "Couldn't reach the provider — check your internet connection.".to_string())
    } else {
        ("network_error", e.to_string())
    }
}
