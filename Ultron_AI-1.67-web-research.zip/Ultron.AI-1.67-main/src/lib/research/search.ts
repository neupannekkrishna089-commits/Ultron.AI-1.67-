// Search stage — thin wrapper around the Rust `web_search` command
// (src-tauri/src/research.rs). All network access and the search API key
// live there; this file just calls it and shapes errors consistently.

import { isDesktop } from "~/lib/storage";
import type { SearchResult } from "~/lib/research/types";

export class ResearchUnavailableError extends Error {
  code: "no_api_key" | "network_error" | "search_failed" | "not_desktop";
  constructor(code: ResearchUnavailableError["code"], message: string) {
    super(message);
    this.code = code;
  }
}

export async function searchWeb(query: string): Promise<SearchResult[]> {
  if (!isDesktop()) {
    throw new ResearchUnavailableError(
      "not_desktop",
      "Web research needs the installed desktop app — it can't run in this browser preview.",
    );
  }
  const { invoke } = await import("@tauri-apps/api/core");
  try {
    return await invoke<SearchResult[]>("web_search", { query });
  } catch (err) {
    const message = String(err);
    if (message.includes("no_api_key")) {
      throw new ResearchUnavailableError(
        "no_api_key",
        "No web search API key is saved yet — add one in Settings to let ULTRON search the web.",
      );
    }
    if (message.includes("network_error")) {
      throw new ResearchUnavailableError("network_error", "Couldn't reach the search service.");
    }
    throw new ResearchUnavailableError("search_failed", message);
  }
}
