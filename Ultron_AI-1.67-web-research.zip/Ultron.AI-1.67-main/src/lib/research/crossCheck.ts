// Cross-checking stage (Deep Research only — Quick Search skips this to
// stay fast).
//
// Asks the AI Core to compare the collected sources for a task and note
// where they agree, where they conflict, and — if they conflict — which
// source looks stronger and why. The result is folded into the synthesis
// instruction as its own labeled section; it never overwrites or hides the
// underlying source text.

import type { AISettings } from "~/lib/ultron";
import { completePrompt } from "~/lib/ai";
import type { ExtractedSource } from "~/lib/research/types";

const CROSS_CHECK_INSTRUCTION = `
You're comparing multiple sources gathered for a research question. For any
important factual claim that more than one source addresses, note whether
they agree or disagree. If they disagree:
- State the disagreement plainly.
- Say which source looks stronger for this claim and briefly why (e.g.
  official/manufacturer source vs. a forum post, more recent vs. older,
  primary vs. secondary) — the sources you're given already indicate their
  type and a rough quality tier.
- Do not resolve the disagreement with false confidence if the sources
  genuinely don't allow it — say the claim is unresolved instead.

If the sources mostly agree, say so briefly rather than inventing
disagreements. Keep this compact — a findings list, not an essay.
`.trim();

export async function crossCheckSources(sources: ExtractedSource[], settings: AISettings): Promise<string> {
  if (sources.length < 2) return "";

  const sourceBlock = sources
    .map(
      (s, i) =>
        `[${i + 1}] ${s.title} — ${s.domain} (type: ${s.sourceType}, quality tier: ${s.qualityScore}/3)${
          s.publishedAt ? `, published: ${s.publishedAt}` : ""
        }\n${s.content.slice(0, 1500)}`,
    )
    .join("\n\n");

  try {
    return await completePrompt(settings, CROSS_CHECK_INSTRUCTION, sourceBlock);
  } catch {
    return "";
  }
}
