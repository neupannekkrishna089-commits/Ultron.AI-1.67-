// Web Research Engine types.
//
// Pipeline: intent detection -> planning -> search -> extraction ->
// quality scoring -> cross-checking (deep mode) -> synthesis -> citations.
// See src/lib/research/orchestrator.ts for the stage that ties these
// together, and each stage's own file for its piece.

export type ResearchMode = "quick" | "deep";

export type SourceType =
  | "official"
  | "academic"
  | "manufacturer"
  | "documentation"
  | "journalism"
  | "technical"
  | "community"
  | "unknown";

export type SearchResult = {
  title: string;
  url: string;
  snippet: string;
};

export type ExtractedSource = {
  url: string;
  domain: string;
  title: string;
  publishedAt: string | null;
  sourceType: SourceType;
  qualityScore: number; // 0-3, higher = more authoritative (see sourceQuality.ts)
  content: string;
  truncated: boolean;
  fetchedAt: number;
};

export type ResearchTask = {
  question: string;
};

export type ResearchProgressStage =
  | "understanding"
  | "searching"
  | "reading"
  | "cross-checking"
  | "synthesizing";

export type ResearchProgressEvent = {
  stage: ResearchProgressStage;
  label: string;
  detail?: string;
};

/** A citation as it's actually stored on a finished message — see
 *  ~/lib/ultron.ts Message.sources. Only ever built from sources that were
 *  genuinely fetched and used; never invented. */
export type SourceCitation = {
  index: number;
  title: string;
  url: string;
  domain: string;
  sourceType: SourceType;
};

export type ResearchResult = {
  answerText: string;
  citations: SourceCitation[];
};
