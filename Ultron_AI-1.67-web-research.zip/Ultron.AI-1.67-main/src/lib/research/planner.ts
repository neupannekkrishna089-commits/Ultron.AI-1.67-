// Research planner.
//
// Quick Search: no decomposition — the query is searched as-is.
//
// Deep Research: for a complex question, breaks it into several concrete
// sub-questions (e.g. "best laptop under my budget" -> available models,
// current prices, specifications, performance, reviews, limitations,
// availability, alternatives) so the search stage runs several targeted
// searches instead of one blind search of the exact sentence.
//
// Uses the AI Core's completePrompt (not the streamed user-facing reply) to
// do the decomposition — if that call fails for any reason, falls back to
// treating the original query as a single task rather than failing the
// whole research run.

import type { AISettings } from "~/lib/ultron";
import { completePrompt } from "~/lib/ai";
import type { ResearchMode, ResearchTask } from "~/lib/research/types";

const PLANNER_INSTRUCTION = `
Break the user's research question into 3-6 concrete, independently
searchable sub-questions that together would let someone answer the
original question well. Think about what distinct facts need to be found —
e.g. for "find the best X under my budget and compare everything" that
might be: available models, current prices, specifications, performance,
reviews, limitations, availability, alternatives.

Respond with ONLY a numbered list, one sub-question per line, nothing else.
`.trim();

export async function planResearch(query: string, mode: ResearchMode, settings: AISettings): Promise<ResearchTask[]> {
  if (mode === "quick") {
    return [{ question: query }];
  }

  try {
    const raw = await completePrompt(settings, PLANNER_INSTRUCTION, query);
    const tasks = parseNumberedList(raw);
    if (tasks.length > 0) return tasks.map((question) => ({ question }));
  } catch {
    // Planning is a nice-to-have, not a hard requirement.
  }
  return [{ question: query }];
}

function parseNumberedList(text: string): string[] {
  return text
    .split("\n")
    .map((line) => line.replace(/^\s*[\d.)\-•]+\s*/, "").trim())
    .filter((line) => line.length > 3)
    .slice(0, 6);
}
