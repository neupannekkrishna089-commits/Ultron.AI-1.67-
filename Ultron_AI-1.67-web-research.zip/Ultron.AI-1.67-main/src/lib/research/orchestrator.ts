// Research orchestrator — the one function App.tsx calls. Ties together
// every stage: plan -> search -> collect -> extract -> quality-rank ->
// cross-check (deep only) -> synthesize -> stream the final answer.
//
// Cancellation is coarse-grained: a shared `cancelToken.cancelled` flag is
// checked between stages and between per-source operations (each search/
// fetch call is quick), so cancelling stops the run promptly. Once the
// final answer starts streaming, cancellation goes through the normal
// cancelAiReply path (same as any other in-progress reply).

import type { AISettings } from "~/lib/ultron";
import type { AIStreamHandlers, AIError } from "~/lib/ai/types";
import { streamWithCustomInstruction } from "~/lib/ai";
import { planResearch } from "~/lib/research/planner";
import { searchWeb, ResearchUnavailableError } from "~/lib/research/search";
import { extractPages } from "~/lib/research/extract";
import { crossCheckSources } from "~/lib/research/crossCheck";
import { buildResearchSystemInstruction } from "~/lib/research/synthesize";
import { classifySource } from "~/lib/research/sourceQuality";
import type {
  ExtractedSource,
  ResearchMode,
  ResearchProgressEvent,
  SourceCitation,
} from "~/lib/research/types";

const MAX_SOURCES_QUICK = 4;
const MAX_SOURCES_DEEP = 10;
const MAX_RESULTS_PER_TASK = 5;

export type CancelToken = { cancelled: boolean };

export type ResearchDispatchResult = { requestId: string; providerId: string; citations: SourceCitation[] };

class ResearchCancelled extends Error {
  constructor() {
    super("cancelled");
  }
}

function checkCancelled(token: CancelToken): void {
  if (token.cancelled) throw new ResearchCancelled();
}

export async function runResearch(
  query: string,
  mode: ResearchMode,
  settings: AISettings,
  cancelToken: CancelToken,
  onProgress: (e: ResearchProgressEvent) => void,
  streamHandlers: AIStreamHandlers,
): Promise<ResearchDispatchResult | null> {
  try {
    onProgress({ stage: "understanding", label: "Understanding request" });
    const tasks = await planResearch(query, mode, settings);
    checkCancelled(cancelToken);

    onProgress({
      stage: "searching",
      label: "Searching sources",
      detail: mode === "deep" ? `${tasks.length} sub-questions` : undefined,
    });

    const seenUrls = new Set<string>();
    const rankedUrls: string[] = [];
    for (const task of tasks) {
      checkCancelled(cancelToken);
      let results;
      try {
        results = await searchWeb(task.question);
      } catch (err) {
        if (err instanceof ResearchUnavailableError) {
          streamHandlers.onError(mapUnavailableError(err));
          return null;
        }
        continue;
      }
      const scored = results
        .filter((r) => !seenUrls.has(r.url))
        .map((r) => ({ result: r, score: classifySource(domainFromUrl(r.url)).qualityScore }))
        .sort((a, b) => b.score - a.score)
        .slice(0, MAX_RESULTS_PER_TASK);
      for (const s of scored) {
        seenUrls.add(s.result.url);
        rankedUrls.push(s.result.url);
      }
    }

    if (rankedUrls.length === 0) {
      streamHandlers.onError({
        code: "unknown",
        message: "No search results came back for this question — try rephrasing it.",
      });
      return null;
    }

    checkCancelled(cancelToken);
    const maxSources = mode === "deep" ? MAX_SOURCES_DEEP : MAX_SOURCES_QUICK;
    const urlsToFetch = rankedUrls.slice(0, maxSources);

    onProgress({ stage: "reading", label: "Reading sources", detail: `0/${urlsToFetch.length}` });
    let read = 0;
    const sources: ExtractedSource[] = [];
    for (const url of urlsToFetch) {
      checkCancelled(cancelToken);
      const fetched = await extractPages([url]);
      read += 1;
      onProgress({ stage: "reading", label: "Reading sources", detail: `${read}/${urlsToFetch.length}` });
      if (fetched.length > 0) sources.push(fetched[0]);
    }

    if (sources.length === 0) {
      streamHandlers.onError({
        code: "unknown",
        message: "Found search results, but couldn't successfully read any of the pages.",
      });
      return null;
    }

    let crossCheckFindings = "";
    if (mode === "deep") {
      checkCancelled(cancelToken);
      onProgress({ stage: "cross-checking", label: "Cross-checking sources" });
      crossCheckFindings = await crossCheckSources(sources, settings);
    }

    checkCancelled(cancelToken);
    onProgress({ stage: "synthesizing", label: "Preparing answer" });

    const systemInstruction = buildResearchSystemInstruction(sources, crossCheckFindings, mode);
    const citations: SourceCitation[] = sources.map((s, i) => ({
      index: i + 1,
      title: s.title,
      url: s.url,
      domain: s.domain,
      sourceType: s.sourceType,
    }));

    const { requestId, providerId } = await streamWithCustomInstruction(
      settings,
      systemInstruction,
      [{ role: "user", content: query }],
      streamHandlers,
    );

    return { requestId, providerId, citations };
  } catch (err) {
    if (err instanceof ResearchCancelled) {
      streamHandlers.onError({ code: "cancelled", message: "Research cancelled." });
      return null;
    }
    streamHandlers.onError({ code: "unknown", message: String(err) });
    return null;
  }
}

function mapUnavailableError(err: ResearchUnavailableError): AIError {
  const code = err.code === "no_api_key" ? "no_api_key" : err.code === "network_error" ? "network_error" : "unknown";
  return { code, message: err.message };
}

function domainFromUrl(url: string): string {
  const withoutScheme = url.split("://")[1] ?? url;
  return withoutScheme.split("/")[0] ?? withoutScheme;
}
