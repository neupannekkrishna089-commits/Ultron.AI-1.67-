// Source quality classification.
//
// A domain-based heuristic — not a fact-checking system, just enough
// structure to (a) prefer authoritative sources when they exist, (b) still
// surface community sources for real-world experience, clearly labeled as
// such, and (c) give cross-checking something to reason about when sources
// disagree ("which source is stronger" needs some notion of stronger).
//
// This is necessarily incomplete — thousands of domains aren't in any list
// here. Unknown domains get sourceType "unknown" and a middling score
// rather than being over-classified with false confidence.

import type { SourceType } from "~/lib/research/types";

const GOVERNMENT_TLDS = [".gov", ".gov.uk", ".gov.au", ".mil"];
const ACADEMIC_TLDS = [".edu", ".ac.uk"];

const OFFICIAL_DOMAINS = ["who.int", "un.org", "europa.eu", "nist.gov", "cdc.gov", "fda.gov"];

const ACADEMIC_DOMAINS = [
  "arxiv.org", "nature.com", "sciencedirect.com", "springer.com", "ieee.org",
  "acm.org", "jstor.org", "pubmed.ncbi.nlm.nih.gov", "scholar.google.com",
];

const DOCUMENTATION_DOMAINS = [
  "developer.mozilla.org", "docs.microsoft.com", "learn.microsoft.com",
  "docs.python.org", "developer.apple.com", "developer.android.com",
  "docs.rs", "doc.rust-lang.org", "kubernetes.io", "docs.docker.com",
];

const MANUFACTURER_HINTS = ["apple.com", "microsoft.com", "google.com", "samsung.com", "intel.com", "amd.com", "nvidia.com", "dell.com", "lenovo.com", "hp.com", "asus.com"];

const JOURNALISM_DOMAINS = [
  "reuters.com", "apnews.com", "bbc.com", "bbc.co.uk", "nytimes.com",
  "washingtonpost.com", "theguardian.com", "wsj.com", "bloomberg.com",
  "npr.org", "economist.com",
];

const TECHNICAL_PUBLICATIONS = [
  "arstechnica.com", "theverge.com", "techcrunch.com", "wired.com",
  "engadget.com", "tomshardware.com", "anandtech.com", "stackoverflow.com",
  "github.com",
];

const COMMUNITY_DOMAINS = [
  "reddit.com", "quora.com", "medium.com", "forums.", "forum.",
  "news.ycombinator.com",
];

function hostMatches(domain: string, list: string[]): boolean {
  return list.some((d) => domain === d || domain.endsWith("." + d) || domain.includes(d));
}

/** Higher is more authoritative for a factual claim: 3 = official/academic,
 *  2 = documentation/manufacturer/journalism/technical press, 1 = community,
 *  0 = unclassified. Used to rank sources and to decide "which source is
 *  stronger" during cross-checking, not as an absolute trust score. */
export function classifySource(domain: string): { sourceType: SourceType; qualityScore: number } {
  const d = domain.toLowerCase().replace(/^www\./, "");

  if (GOVERNMENT_TLDS.some((tld) => d.endsWith(tld)) || hostMatches(d, OFFICIAL_DOMAINS)) {
    return { sourceType: "official", qualityScore: 3 };
  }
  if (ACADEMIC_TLDS.some((tld) => d.endsWith(tld)) || hostMatches(d, ACADEMIC_DOMAINS)) {
    return { sourceType: "academic", qualityScore: 3 };
  }
  if (hostMatches(d, DOCUMENTATION_DOMAINS)) {
    return { sourceType: "documentation", qualityScore: 2 };
  }
  if (hostMatches(d, MANUFACTURER_HINTS)) {
    return { sourceType: "manufacturer", qualityScore: 2 };
  }
  if (hostMatches(d, JOURNALISM_DOMAINS)) {
    return { sourceType: "journalism", qualityScore: 2 };
  }
  if (hostMatches(d, TECHNICAL_PUBLICATIONS)) {
    return { sourceType: "technical", qualityScore: 2 };
  }
  if (hostMatches(d, COMMUNITY_DOMAINS)) {
    return { sourceType: "community", qualityScore: 1 };
  }
  return { sourceType: "unknown", qualityScore: 0 };
}
