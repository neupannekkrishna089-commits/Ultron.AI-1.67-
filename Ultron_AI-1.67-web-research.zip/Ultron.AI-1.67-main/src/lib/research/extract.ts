// Extraction stage — fetches and extracts a single page via the Rust
// `fetch_page` command, then classifies its source quality. Per-URL
// failures are caught here and simply skipped by the caller — one bad
// source never aborts the whole research run.

import { classifySource } from "~/lib/research/sourceQuality";
import type { ExtractedSource } from "~/lib/research/types";

type FetchPageDto = {
  url: string;
  domain: string;
  title: string;
  publishedAt: string | null;
  content: string;
  truncated: boolean;
};

export async function extractPage(url: string): Promise<ExtractedSource> {
  const { invoke } = await import("@tauri-apps/api/core");
  const dto = await invoke<FetchPageDto>("fetch_page", { url });
  const { sourceType, qualityScore } = classifySource(dto.domain);
  return {
    url: dto.url,
    domain: dto.domain,
    title: dto.title || dto.domain,
    publishedAt: dto.publishedAt,
    sourceType,
    qualityScore,
    content: dto.content,
    truncated: dto.truncated,
    fetchedAt: Date.now(),
  };
}

/** Fetches several URLs, skipping any that fail rather than aborting the
 *  whole batch. */
export async function extractPages(
  urls: string[],
  onFailure?: (url: string, error: unknown) => void,
): Promise<ExtractedSource[]> {
  const results: ExtractedSource[] = [];
  for (const url of urls) {
    try {
      results.push(await extractPage(url));
    } catch (err) {
      onFailure?.(url, err);
    }
  }
  return results;
}
