// Research intent detection.
//
// Deliberately NOT an AI call — running a model just to decide "should I
// research this?" on every single message would violate the performance
// requirement (avoid excessive requests) and add latency to every plain
// chat message for a decision that a keyword check answers just as well.
// This is a plain, deterministic phrase match: cheap, predictable, and easy
// to reason about why a message did or didn't trigger research.
//
// This is intentionally conservative — a phrase that's ambiguous is treated
// as NOT a research request. The explicit Quick Search / Deep Research
// toggle in the composer (see ChatView) is the reliable path for anything
// this heuristic misses; this function only handles the "user typed a
// request in plain language" case.

import type { ResearchMode } from "~/lib/research/types";

const DEEP_PHRASES = [
  "deep research",
  "thoroughly research",
  "thorough research",
  "compare everything",
  "detailed comparison",
  "in-depth",
  "comprehensive research",
  "research this thoroughly",
];

const RESEARCH_PHRASES = [
  "search the web",
  "search online",
  "search the internet",
  "browse the web",
  "look up",
  "look this up",
  "google ",
  "find current information",
  "find the latest",
  "what's the latest",
  "what is the latest",
  "current price",
  "current version",
  "latest version",
  "latest news",
  "recent news",
  "verify this",
  "verify that",
  "fact check",
  "fact-check",
  "is it true that",
  "compare current",
  "check online",
  "find out online",
  "research ",
];

function normalize(text: string): string {
  return text.toLowerCase().trim();
}

/** Returns the research mode to use for this message, or null if nothing in
 *  the message text asked for research. `forcedMode` (from the composer's
 *  explicit toggle) always wins over the heuristic when set. */
export function detectResearchIntent(text: string, forcedMode: ResearchMode | null): ResearchMode | null {
  if (forcedMode) return forcedMode;

  const normalized = normalize(text);
  if (!normalized) return null;

  if (DEEP_PHRASES.some((p) => normalized.includes(p))) return "deep";
  if (RESEARCH_PHRASES.some((p) => normalized.includes(p))) return "quick";
  return null;
}
