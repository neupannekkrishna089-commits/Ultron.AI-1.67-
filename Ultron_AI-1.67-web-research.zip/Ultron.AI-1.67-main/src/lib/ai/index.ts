// AI Core orchestrator — the one function App.tsx calls to get a streamed
// reply. Ties together the router (which provider/model), the context
// builder (which messages to send), and the provider registry (how to
// actually send them). Nothing else in the app needs to know those three
// pieces exist separately.

import type { AISettings, Message } from "~/lib/ultron";
import type { AIStreamHandlers, AITaskType } from "~/lib/ai/types";
import { buildContext } from "~/lib/ai/context";
import { routeTask } from "~/lib/ai/router";
import { getProvider } from "~/lib/ai/registry";

export type { AIError, AIErrorCode, AIProviderId, AIUsage } from "~/lib/ai/types";
export { AI_ERROR_FALLBACK } from "~/lib/ai/types";
export { getProvider, PROVIDER_LIST } from "~/lib/ai/registry";

/** Starts a streaming AI reply for the given conversation history. Returns
 *  a requestId (for cancellation) plus which provider ended up handling it,
 *  once the request has actually been dispatched. */
export async function streamAiReply(
  history: Message[],
  settings: AISettings,
  handlers: AIStreamHandlers,
  taskType: AITaskType = "CHAT",
): Promise<{ requestId: string; providerId: string }> {
  const latestUserMessage = [...history].reverse().find((m) => m.role === "user")?.text ?? "";
  const decision = await routeTask(taskType, settings, latestUserMessage);
  const provider = getProvider(decision.providerId);

  const requestId = await provider.sendMessage(
    {
      taskType,
      systemInstruction: decision.systemInstruction,
      messages: buildContext(history),
      model: decision.model,
      temperature: settings.temperature,
      maxOutputTokens: settings.maxOutputTokens,
    },
    handlers,
  );

  return { requestId, providerId: decision.providerId };
}

export async function cancelAiReply(providerId: string, requestId: string): Promise<void> {
  if (!requestId) return;
  const provider = getProvider(providerId as Parameters<typeof getProvider>[0]);
  await provider.cancel(requestId);
}

/** Streams a reply using a caller-supplied system instruction and message
 *  list, bypassing the router (no automatic personalization/vault/memory
 *  injection — the caller already built exactly the context it wants).
 *  Used for the Web Research Engine's final synthesized answer, which has
 *  its own system instruction (identity + personalization + source
 *  material) assembled in ~/lib/research/synthesize.ts. */
export async function streamWithCustomInstruction(
  settings: AISettings,
  systemInstruction: string,
  messages: { role: "user" | "assistant"; content: string }[],
  handlers: AIStreamHandlers,
): Promise<{ requestId: string; providerId: string }> {
  const provider = getProvider(settings.provider);
  const requestId = await provider.sendMessage(
    {
      taskType: "RESEARCH",
      systemInstruction,
      messages,
      model: settings.model || provider.defaultModel,
      temperature: settings.temperature,
      maxOutputTokens: settings.maxOutputTokens,
    },
    handlers,
  );
  return { requestId, providerId: settings.provider };
}

/** Runs a one-off prompt to completion and resolves with the full text —
 *  for internal tool subsystems (e.g. the Web Research Engine's planning
 *  and cross-checking steps) that need an answer to reason with, not a
 *  live-streamed reply for the user to watch. Bypasses the router entirely
 *  (no personalization/vault/memory injection, no conversation history) —
 *  callers pass exactly the system instruction and messages they need.
 *  This is additive; it doesn't change how streamAiReply or the router
 *  behave for ordinary chat. */
export async function completePrompt(
  settings: AISettings,
  systemInstruction: string,
  userMessage: string,
): Promise<string> {
  const provider = getProvider(settings.provider);
  let text = "";
  await new Promise<void>((resolve, reject) => {
    void provider.sendMessage(
      {
        taskType: "PLANNING",
        systemInstruction,
        messages: [{ role: "user", content: userMessage }],
        model: settings.model || provider.defaultModel,
        temperature: settings.temperature,
        maxOutputTokens: settings.maxOutputTokens,
      },
      {
        onDelta: (delta) => {
          text += delta;
        },
        onDone: () => resolve(),
        onError: (err) => reject(new Error(err.message)),
      },
    );
  });
  return text;
}
