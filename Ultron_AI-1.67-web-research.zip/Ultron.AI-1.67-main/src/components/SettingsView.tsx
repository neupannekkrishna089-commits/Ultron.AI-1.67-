import { useState } from "react";
import type { Settings } from "~/lib/ultron";
import {
  APP_NAME,
  APP_TAGLINE,
  APP_VERSION,
  shortcutParts,
  shortcutsEqual,
} from "~/lib/ultron";
import { DEFAULT_SHORTCUT } from "~/lib/ultron";
import type { ShortcutStatus } from "~/App";
import type { AIProviderId } from "~/lib/ai";
import { PROVIDER_LIST, getProvider } from "~/lib/ai";
import { PersonalizationSection } from "~/components/PersonalizationSection";
import { WebResearchSection } from "~/components/WebResearchSection";
import {
  IconCheck,
  IconEye,
  IconEyeOff,
  IconKeyboard,
  IconSparkle,
  ULTRONMark,
} from "~/components/icons";

type SettingsViewProps = {
  settings: Settings;
  recording: boolean;
  recordError: string | null;
  justSaved: boolean;
  desktop: boolean;
  shortcutStatus: ShortcutStatus | null;
  hasApiKey: boolean | null;
  onSaveApiKey: (key: string) => void | Promise<void>;
  onClearApiKey: () => void | Promise<void>;
  onAiSettingsChange: (patch: Partial<Settings["ai"]>) => void;
  hasSearchApiKey: boolean | null;
  onSaveSearchApiKey: (key: string) => void | Promise<void>;
  onClearSearchApiKey: () => void | Promise<void>;
  onResearchSettingsChange: (patch: Partial<Settings["research"]>) => void;
  onStartRecording: () => void;
  onCancelRecording: () => void;
  onResetShortcut: () => void;
};

export function SettingsView({
  settings,
  recording,
  recordError,
  justSaved,
  desktop,
  shortcutStatus,
  hasApiKey,
  onSaveApiKey,
  onClearApiKey,
  onAiSettingsChange,
  hasSearchApiKey,
  onSaveSearchApiKey,
  onClearSearchApiKey,
  onResearchSettingsChange,
  onStartRecording,
  onCancelRecording,
  onResetShortcut,
}: SettingsViewProps) {
  const current = settings.activationShortcut;
  const isDefault = shortcutsEqual(current, DEFAULT_SHORTCUT);

  const [apiKeyInput, setApiKeyInput] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [customModel, setCustomModel] = useState("");
  const provider = getProvider(settings.ai.provider);
  const usingCustomModel = !provider.models.includes(settings.ai.model);

  return (
    <main className="ultron-canvas ultron-scroll h-full min-w-0 flex-1 overflow-y-auto">
      <div className="mx-auto w-full max-w-2xl px-6 py-10">
        <header className="mb-7">
          <h1 className="text-[19px] font-medium tracking-[-0.01em] text-ink">Settings</h1>
          <p className="mt-1 text-[12.5px] text-ink-muted">
            Tune ULTRON to your liking — changes apply instantly and are stored on this device.
          </p>
        </header>

        {/* AI Provider */}
        <section className="ultron-elevate mb-5 rounded-[14px] border border-graphite-700/70 bg-graphite-900">
          <div className="flex items-start gap-3 border-b border-graphite-700/60 px-5 py-4">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[9px] bg-graphite-800 text-crimson ring-1 ring-inset ring-graphite-700">
              <IconSparkle size={15} />
            </span>
            <div>
              <h2 className="text-[13px] font-medium text-ink">AI provider</h2>
              <p className="mt-0.5 text-[12px] leading-relaxed text-ink-muted">
                {desktop
                  ? "Your API key is stored in the Windows Credential Manager, never in this app's settings file, and only ever sent directly to the provider you choose."
                  : "API keys can only be saved from the installed desktop app — this browser preview can't reach the OS credential store."}
              </p>
            </div>
          </div>

          <div className="space-y-4 px-5 py-4.5">
            {/* Provider */}
            <div>
              <label className="mb-1.5 block text-[11.5px] font-medium text-ink-soft" htmlFor="provider-select">
                Provider
              </label>
              <select
                id="provider-select"
                value={settings.ai.provider}
                onChange={(e) => {
                  const id = e.target.value as AIProviderId;
                  onAiSettingsChange({ provider: id, model: getProvider(id).defaultModel });
                }}
                className="w-full rounded-[9px] border border-graphite-700 bg-graphite-800 px-3 py-2 text-[12.5px] text-ink outline-none transition-colors focus:border-graphite-500"
              >
                {PROVIDER_LIST.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.label}
                    {p.implemented ? "" : " (coming soon)"}
                  </option>
                ))}
              </select>
              {!provider.implemented && (
                <p className="mt-1.5 text-[11px] text-ink-muted">
                  {provider.label} isn't wired up yet in this build — Anthropic is the only working
                  provider right now.
                </p>
              )}
            </div>

            {/* Model */}
            <div>
              <label className="mb-1.5 block text-[11.5px] font-medium text-ink-soft" htmlFor="model-select">
                Model
              </label>
              <div className="flex gap-2">
                <select
                  id="model-select"
                  value={usingCustomModel ? "__custom__" : settings.ai.model}
                  onChange={(e) => {
                    if (e.target.value === "__custom__") {
                      setCustomModel(settings.ai.model);
                    } else {
                      onAiSettingsChange({ model: e.target.value });
                    }
                  }}
                  className="w-full rounded-[9px] border border-graphite-700 bg-graphite-800 px-3 py-2 text-[12.5px] text-ink outline-none transition-colors focus:border-graphite-500"
                >
                  {provider.models.map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                  <option value="__custom__">Custom model ID…</option>
                </select>
              </div>
              {usingCustomModel && (
                <input
                  type="text"
                  value={customModel || settings.ai.model}
                  onChange={(e) => setCustomModel(e.target.value)}
                  onBlur={() => customModel.trim() && onAiSettingsChange({ model: customModel.trim() })}
                  placeholder="e.g. claude-sonnet-5"
                  className="mt-2 w-full rounded-[9px] border border-graphite-700 bg-graphite-800 px-3 py-2 text-[12.5px] text-ink outline-none transition-colors focus:border-graphite-500"
                />
              )}
            </div>

            {/* API key */}
            <div>
              <label className="mb-1.5 block text-[11.5px] font-medium text-ink-soft" htmlFor="api-key-input">
                API key
              </label>
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <input
                    id="api-key-input"
                    type={showKey ? "text" : "password"}
                    value={apiKeyInput}
                    disabled={!desktop}
                    onChange={(e) => setApiKeyInput(e.target.value)}
                    placeholder={hasApiKey ? "•••••••••••••••••••• (key saved)" : "Paste your API key"}
                    className="w-full rounded-[9px] border border-graphite-700 bg-graphite-800 py-2 pl-3 pr-9 text-[12.5px] text-ink outline-none transition-colors focus:border-graphite-500 disabled:cursor-not-allowed disabled:opacity-50"
                  />
                  <button
                    type="button"
                    onClick={() => setShowKey((v) => !v)}
                    aria-label={showKey ? "Hide key" : "Show key"}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-ink-muted hover:text-ink"
                  >
                    {showKey ? <IconEyeOff size={13.5} /> : <IconEye size={13.5} />}
                  </button>
                </div>
                <button
                  type="button"
                  disabled={!desktop || !apiKeyInput.trim()}
                  onClick={() => {
                    void onSaveApiKey(apiKeyInput.trim());
                    setApiKeyInput("");
                  }}
                  className="rounded-[9px] bg-crimson px-3.5 py-2 text-[12px] font-semibold text-white transition-all duration-150 ease-out hover:bg-crimson-hover active:scale-[0.97] disabled:cursor-not-allowed disabled:bg-graphite-700 disabled:text-ink-muted/40"
                >
                  Save
                </button>
                {hasApiKey && (
                  <button
                    type="button"
                    disabled={!desktop}
                    onClick={() => void onClearApiKey()}
                    className="rounded-[9px] border border-graphite-700 px-3 py-2 text-[12px] text-ink-muted transition-colors duration-150 ease-out hover:border-graphite-600 hover:text-ink disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    Remove
                  </button>
                )}
              </div>
              <p className="mt-1.5 text-[11px] text-ink-muted">
                {hasApiKey === null
                  ? " "
                  : hasApiKey
                    ? `A key is saved for ${provider.label}.`
                    : `No key saved for ${provider.label} yet — ULTRON will tell you honestly if you send a message without one.`}
              </p>
            </div>

            {/* Temperature */}
            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <span className="text-[11.5px] font-medium text-ink-soft">Temperature</span>
                <span className="text-[11px] tabular-nums text-ink-muted">
                  {settings.ai.temperature.toFixed(2)}
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={2}
                step={0.05}
                value={settings.ai.temperature}
                onChange={(e) => onAiSettingsChange({ temperature: parseFloat(e.target.value) })}
                className="ultron-range w-full"
              />
            </div>

            {/* Max output tokens */}
            <div>
              <label className="mb-1.5 block text-[11.5px] font-medium text-ink-soft" htmlFor="max-tokens-input">
                Maximum output tokens
              </label>
              <input
                id="max-tokens-input"
                type="number"
                min={64}
                max={8192}
                step={64}
                value={settings.ai.maxOutputTokens}
                onChange={(e) => {
                  const n = parseInt(e.target.value, 10);
                  if (!Number.isNaN(n)) onAiSettingsChange({ maxOutputTokens: n });
                }}
                className="w-full rounded-[9px] border border-graphite-700 bg-graphite-800 px-3 py-2 text-[12.5px] text-ink outline-none transition-colors focus:border-graphite-500"
              />
            </div>
          </div>
        </section>

        <WebResearchSection
          desktop={desktop}
          researchSettings={settings.research}
          hasSearchApiKey={hasSearchApiKey}
          onSaveSearchApiKey={onSaveSearchApiKey}
          onClearSearchApiKey={onClearSearchApiKey}
          onResearchSettingsChange={onResearchSettingsChange}
        />

        <PersonalizationSection />

        {/* Activation shortcut */}
        <section className="ultron-elevate mb-5 rounded-[14px] border border-graphite-700/70 bg-graphite-900">
          <div className="flex items-start gap-3 border-b border-graphite-700/60 px-5 py-4">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[9px] bg-graphite-800 text-crimson ring-1 ring-inset ring-graphite-700">
              <IconKeyboard size={15} />
            </span>
            <div>
              <h2 className="text-[13px] font-medium text-ink">Activation shortcut</h2>
              <p className="mt-0.5 text-[12px] leading-relaxed text-ink-muted">
                Press this combination anywhere in ULTRON (while not typing) to jump to the
                composer. It won't fire inside text fields.
              </p>
            </div>
          </div>

          <div className="px-5 py-4.5">
            <div className="flex flex-wrap items-center gap-3">
              <span className="text-[12px] text-ink-muted">Current:</span>
              <span className="flex items-center gap-1">
                {shortcutParts(current).map((p, i) => (
                  <kbd
                    key={p + i}
                    className="rounded-md border border-graphite-600 bg-graphite-800 px-2 py-1 text-[11.5px] font-semibold text-ink shadow-[0_1px_0_rgba(0,0,0,0.4)]"
                  >
                    {p}
                  </kbd>
                ))}
              </span>

              <span className="flex items-center gap-2">
                {justSaved && (
                  <span className="flex animate-fade-up items-center gap-1 text-[11.5px] font-medium text-crimson">
                    <IconCheck size={12} /> Applied
                  </span>
                )}
              </span>

              <div className="ml-auto flex items-center gap-2">
                {!isDefault && (
                  <button
                    type="button"
                    onClick={onResetShortcut}
                    className="rounded-[9px] border border-graphite-700 px-3 py-1.5 text-[12px] text-ink-muted transition-colors duration-150 ease-out hover:border-graphite-600 hover:text-ink"
                  >
                    Reset to default
                  </button>
                )}
                {recording ? (
                  <button
                    type="button"
                    onClick={onCancelRecording}
                    className="rounded-[9px] border border-graphite-700 bg-graphite-800 px-3 py-1.5 text-[12px] text-ink transition-colors duration-150 ease-out hover:bg-graphite-700"
                  >
                    Cancel (Esc)
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={onStartRecording}
                    className="rounded-[9px] bg-crimson px-3.5 py-1.5 text-[12px] font-semibold text-white transition-all duration-150 ease-out hover:bg-crimson-hover active:scale-[0.97]"
                  >
                    Record new shortcut
                  </button>
                )}
              </div>
            </div>

            {recording ? (
              <div
                className="mt-4 flex items-center gap-2.5 rounded-[10px] border border-crimson/30 bg-crimson-soft/40 px-3.5 py-2.5"
                role="status"
              >
                <span className="relative flex h-2 w-2 shrink-0">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-crimson/50" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-crimson" />
                </span>
                <span className="text-[12.5px] text-ink">
                  Listening for keys — press the new combination…
                </span>
                <span className="ml-auto text-[11px] text-ink-muted">Esc to cancel</span>
              </div>
            ) : (
              <p className="mt-3.5 text-[11px] leading-relaxed text-ink-muted/80">
                The shortcut must include Ctrl, Alt or Win — single keys are rejected because they
                conflict with typing. This works while ULTRON is focused and you're not in a text
                field.
              </p>
            )}

            {recordError && (
              <p
                className="mt-3 flex animate-fade-up items-center gap-1.5 rounded-[10px] border border-crimson/30 bg-crimson-soft/40 px-3.5 py-2 text-[12px] text-crimson"
                role="alert"
              >
                {recordError}
              </p>
            )}

            {/* OS-level global shortcut status — desktop only. The in-app
                shortcut above always works while ULTRON is focused; this
                reports whether the same combo was also registered with
                Windows as a true global hotkey. */}
            {desktop ? (
              shortcutStatus && (
                <div
                  className={
                    "mt-3 rounded-[10px] border px-3.5 py-2.5 text-[11.5px] leading-relaxed " +
                    (shortcutStatus.registered
                      ? "border-graphite-700 bg-graphite-800/60 text-ink-muted"
                      : "border-crimson/30 bg-crimson-soft/30 text-crimson")
                  }
                >
                  {shortcutStatus.registered ? (
                    <>
                      <span className="text-ink-soft">{shortcutStatus.requested}</span> is
                      registered as a system-wide hotkey — it works even when ULTRON isn't
                      focused.
                    </>
                  ) : (
                    <>
                      Windows wouldn't register{" "}
                      <span className="font-medium">{shortcutStatus.requested}</span> as a global
                      hotkey{shortcutStatus.error ? ` (${shortcutStatus.error})` : ""} — it's
                      likely already reserved by the system. The shortcut above still works while
                      ULTRON's window is focused; pick a different combination above to try
                      registering a free one globally.
                    </>
                  )}
                </div>
              )
            ) : (
              <p className="mt-3 rounded-[10px] border border-graphite-700 bg-graphite-800/60 px-3.5 py-2.5 text-[11.5px] leading-relaxed text-ink-muted">
                Running in browser-preview mode — system-wide hotkeys are only available in the
                installed desktop app.
              </p>
            )}
          </div>
        </section>

        {/* About */}
        <section className="ultron-elevate rounded-[14px] border border-graphite-700/70 bg-graphite-900">
          <div className="flex items-center gap-4 px-5 py-5">
            <ULTRONMark size={42} />
            <div>
              <h2 className="text-[14px] font-semibold tracking-[0.1em] text-ink">
                {APP_NAME}
                <span className="ml-2 text-[11px] font-normal tracking-normal text-ink-muted">
                  Version {APP_VERSION}
                </span>
              </h2>
              <p className="mt-0.5 text-[12px] text-ink-muted">{APP_TAGLINE}</p>
            </div>
          </div>
          <div className="border-t border-graphite-700/60 px-5 py-4">
            <p className="text-[12px] leading-relaxed text-ink-muted">
              Conversations, attachments, and preferences are stored{" "}
              {desktop ? "in a local SQLite database on this device" : "in this browser"}; nothing
              is sent anywhere except the messages you send to your chosen AI provider once a key
              is configured. Research, memory, the Knowledge Vault, coding, study mode, voice, and
              computer control are not built yet.
            </p>
            <p className="mt-3 text-[11px] text-ink-muted/60">
              © {new Date().getFullYear()} ULTRON · Built for Windows
            </p>
          </div>
        </section>
      </div>
    </main>
  );
}
