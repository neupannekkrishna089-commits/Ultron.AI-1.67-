import { useState } from "react";
import type { Settings } from "~/lib/ultron";
import { IconEye, IconEyeOff, IconSearch } from "~/components/icons";

type WebResearchSectionProps = {
  desktop: boolean;
  researchSettings: Settings["research"];
  hasSearchApiKey: boolean | null;
  onSaveSearchApiKey: (key: string) => void | Promise<void>;
  onClearSearchApiKey: () => void | Promise<void>;
  onResearchSettingsChange: (patch: Partial<Settings["research"]>) => void;
};

export function WebResearchSection({
  desktop,
  researchSettings,
  hasSearchApiKey,
  onSaveSearchApiKey,
  onClearSearchApiKey,
  onResearchSettingsChange,
}: WebResearchSectionProps) {
  const [apiKeyInput, setApiKeyInput] = useState("");
  const [showKey, setShowKey] = useState(false);

  return (
    <section className="ultron-elevate mb-5 rounded-[14px] border border-graphite-700/70 bg-graphite-900">
      <div className="flex items-start gap-3 border-b border-graphite-700/60 px-5 py-4">
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[9px] bg-graphite-800 text-crimson ring-1 ring-inset ring-graphite-700">
          <IconSearch size={14} />
        </span>
        <div>
          <h2 className="text-[13px] font-medium text-ink">Web research</h2>
          <p className="mt-0.5 text-[12px] leading-relaxed text-ink-muted">
            ULTRON only searches the web when you explicitly ask (e.g. "search the web for…",
            "look up…", "what's the latest…") or turn on Quick Search / Deep Research for a
            message — never automatically during ordinary conversation.
          </p>
        </div>
      </div>

      <div className="space-y-4 px-5 py-4.5">
        <div className="flex items-center gap-3">
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-[8px] bg-graphite-800 text-ink-muted">
            <IconSearch size={13} />
          </span>
          <div className="min-w-0 flex-1">
            <div className="text-[12.5px] font-medium text-ink-soft">Enable web research</div>
            <div className="mt-0.5 text-[10.5px] leading-snug text-ink-muted">
              Turn off to disable web research entirely, regardless of phrasing or the composer
              toggle.
            </div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={researchSettings.enabled}
            aria-label="Enable web research"
            onClick={() => onResearchSettingsChange({ enabled: !researchSettings.enabled })}
            className={
              "relative h-5 w-9 shrink-0 rounded-full transition-colors duration-150 ease-out " +
              (researchSettings.enabled ? "bg-crimson" : "bg-graphite-700")
            }
          >
            <span
              className={
                "absolute top-0.5 h-4 w-4 rounded-full bg-white transition-transform duration-150 ease-out " +
                (researchSettings.enabled ? "translate-x-[18px]" : "translate-x-0.5")
              }
            />
          </button>
        </div>

        <div className="h-px bg-graphite-700/60" />

        <div>
          <label className="mb-1.5 block text-[11.5px] font-medium text-ink-soft" htmlFor="search-api-key-input">
            Search API key (Brave Search)
          </label>
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <input
                id="search-api-key-input"
                type={showKey ? "text" : "password"}
                value={apiKeyInput}
                disabled={!desktop}
                onChange={(e) => setApiKeyInput(e.target.value)}
                placeholder={hasSearchApiKey ? "•••••••••••••••••••• (key saved)" : "Paste your Brave Search API key"}
                className="w-full rounded-[9px] border border-graphite-700 bg-graphite-800 py-2 pl-3 pr-9 text-[12.5px] text-ink outline-none transition-colors focus:border-graphite-500 disabled:cursor-not-allowed disabled:opacity-50"
              />
              <button
                type="button"
                onClick={() => setShowKey((v) => !v)}
                aria-label={showKey ? "Hide key" : "Show key"}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-ink-muted hover:text-ink"
              >
                {showKey ? <IconEyeOff size={13.5} /> : <IconEye size={13.5} />}
              </button>
            </div>
            <button
              type="button"
              disabled={!desktop || !apiKeyInput.trim()}
              onClick={() => {
                void onSaveSearchApiKey(apiKeyInput.trim());
                setApiKeyInput("");
              }}
              className="rounded-[9px] bg-crimson px-3.5 py-2 text-[12px] font-semibold text-white transition-all duration-150 ease-out hover:bg-crimson-hover active:scale-[0.97] disabled:cursor-not-allowed disabled:bg-graphite-700 disabled:text-ink-muted/40"
            >
              Save
            </button>
            {hasSearchApiKey && (
              <button
                type="button"
                disabled={!desktop}
                onClick={() => void onClearSearchApiKey()}
                className="rounded-[9px] border border-graphite-700 px-3 py-2 text-[12px] text-ink-muted transition-colors duration-150 ease-out hover:border-graphite-600 hover:text-ink disabled:cursor-not-allowed disabled:opacity-50"
              >
                Remove
              </button>
            )}
          </div>
          <p className="mt-1.5 text-[11px] text-ink-muted">
            {!desktop
              ? "Search needs the installed desktop app — not available in this browser preview."
              : hasSearchApiKey === null
                ? " "
                : hasSearchApiKey
                  ? "A search key is saved. Stored the same way as your AI provider key — in the Windows Credential Manager, never in this app's settings file."
                  : "No search key saved yet — web research will tell you honestly if you ask it to search without one."}
          </p>
        </div>
      </div>
    </section>
  );
}
