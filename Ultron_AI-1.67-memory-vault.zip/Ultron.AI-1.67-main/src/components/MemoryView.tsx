import { useEffect, useState } from "react";
import type { MemoryItem } from "~/lib/memory/types";
import { createMemory, deleteMemory, listMemory, searchMemory, updateMemory } from "~/lib/memory/store";
import { IconBrain, IconPlus, IconSearch, IconTrash } from "~/components/icons";

export function MemoryView() {
  const [items, setItems] = useState<MemoryItem[] | null>(null);
  const [query, setQuery] = useState("");
  const [draft, setDraft] = useState("");
  const [draftImportance, setDraftImportance] = useState(3);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState("");

  const refresh = async (q = query) => {
    setItems(q.trim() ? await searchMemory(q) : await listMemory());
  };

  useEffect(() => {
    void refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onSearchChange = (v: string) => {
    setQuery(v);
    void refresh(v);
  };

  const onAdd = async () => {
    if (!draft.trim()) return;
    await createMemory({ content: draft.trim(), importance: draftImportance });
    setDraft("");
    setDraftImportance(3);
    void refresh();
  };

  const onToggle = async (item: MemoryItem) => {
    await updateMemory(item.id, { enabled: !item.enabled });
    void refresh();
  };

  const onDelete = async (id: string) => {
    await deleteMemory(id);
    void refresh();
  };

  const startEdit = (item: MemoryItem) => {
    setEditingId(item.id);
    setEditingText(item.content);
  };

  const saveEdit = async () => {
    if (!editingId) return;
    await updateMemory(editingId, { content: editingText.trim() });
    setEditingId(null);
    void refresh();
  };

  return (
    <main className="ultron-canvas ultron-scroll h-full min-w-0 flex-1 overflow-y-auto">
      <div className="mx-auto w-full max-w-2xl px-6 py-10">
        <header className="mb-6 flex items-start gap-3">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[9px] bg-graphite-800 text-crimson ring-1 ring-inset ring-graphite-700">
            <IconBrain size={15} />
          </span>
          <div>
            <h1 className="text-[19px] font-medium tracking-[-0.01em] text-ink">Memory</h1>
            <p className="mt-1 text-[12.5px] text-ink-muted">
              Facts ULTRON remembers about you — nothing is added automatically. Disabled memories
              stay here but are never sent to the AI.
            </p>
          </div>
        </header>

        {/* Add new */}
        <div className="ultron-elevate mb-5 rounded-[14px] border border-graphite-700/70 bg-graphite-900 p-4">
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="e.g. I'm allergic to peanuts, or: I prefer TypeScript over JavaScript"
            rows={2}
            className="ultron-scroll w-full resize-none rounded-[9px] border border-graphite-700 bg-graphite-800 px-3 py-2 text-[12.5px] text-ink outline-none transition-colors focus:border-graphite-500 placeholder:text-ink-muted/55"
          />
          <div className="mt-2.5 flex items-center justify-between gap-3">
            <label className="flex items-center gap-2 text-[11.5px] text-ink-muted">
              Importance
              <select
                value={draftImportance}
                onChange={(e) => setDraftImportance(parseInt(e.target.value, 10))}
                className="rounded-md border border-graphite-700 bg-graphite-800 px-1.5 py-0.5 text-[11.5px] text-ink outline-none"
              >
                {[1, 2, 3, 4, 5].map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </label>
            <button
              type="button"
              onClick={() => void onAdd()}
              disabled={!draft.trim()}
              className="flex items-center gap-1.5 rounded-[9px] bg-crimson px-3.5 py-1.5 text-[12px] font-semibold text-white transition-all duration-150 ease-out hover:bg-crimson-hover active:scale-[0.97] disabled:cursor-not-allowed disabled:bg-graphite-700 disabled:text-ink-muted/40"
            >
              <IconPlus size={13} /> Remember this
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="mb-4 flex items-center gap-2 rounded-[10px] border border-graphite-700 bg-graphite-850 px-3 py-2">
          <IconSearch size={13} className="text-ink-muted" />
          <input
            value={query}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search memory…"
            className="w-full bg-transparent text-[12.5px] text-ink outline-none placeholder:text-ink-muted/55"
          />
        </div>

        {/* List */}
        {items === null ? (
          <p className="text-[12.5px] text-ink-muted">Loading…</p>
        ) : items.length === 0 ? (
          <p className="rounded-[10px] border border-graphite-700 bg-graphite-850/40 px-4 py-6 text-center text-[12.5px] text-ink-muted">
            {query.trim() ? "No memories match that search." : "Nothing remembered yet."}
          </p>
        ) : (
          <ul className="space-y-2">
            {items.map((item) => (
              <li
                key={item.id}
                className={
                  "ultron-elevate rounded-[12px] border px-4 py-3 transition-colors " +
                  (item.enabled ? "border-graphite-700/70 bg-graphite-900" : "border-graphite-700/40 bg-graphite-900/50 opacity-60")
                }
              >
                {editingId === item.id ? (
                  <div className="flex flex-col gap-2">
                    <textarea
                      value={editingText}
                      onChange={(e) => setEditingText(e.target.value)}
                      rows={2}
                      className="ultron-scroll w-full resize-none rounded-[9px] border border-graphite-700 bg-graphite-800 px-3 py-2 text-[12.5px] text-ink outline-none focus:border-graphite-500"
                    />
                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setEditingId(null)}
                        className="rounded-md px-2.5 py-1 text-[11.5px] text-ink-muted hover:text-ink"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={() => void saveEdit()}
                        className="rounded-md bg-crimson px-2.5 py-1 text-[11.5px] font-medium text-white hover:bg-crimson-hover"
                      >
                        Save
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start gap-3">
                    <button
                      type="button"
                      onClick={() => startEdit(item)}
                      className="flex-1 text-left text-[13px] leading-relaxed text-ink-soft hover:text-ink"
                    >
                      {item.content}
                    </button>
                    <div className="flex shrink-0 items-center gap-2">
                      <span
                        title="Importance"
                        className="rounded-full bg-graphite-800 px-1.5 py-0.5 text-[10px] tabular-nums text-ink-muted"
                      >
                        {item.importance}
                      </span>
                      <button
                        type="button"
                        role="switch"
                        aria-checked={item.enabled}
                        aria-label={item.enabled ? "Disable memory" : "Enable memory"}
                        onClick={() => void onToggle(item)}
                        className={
                          "relative h-4.5 w-8 shrink-0 rounded-full transition-colors duration-150 ease-out " +
                          (item.enabled ? "bg-crimson" : "bg-graphite-700")
                        }
                      >
                        <span
                          className={
                            "absolute top-0.5 h-3.5 w-3.5 rounded-full bg-white transition-transform duration-150 ease-out " +
                            (item.enabled ? "translate-x-[15px]" : "translate-x-0.5")
                          }
                        />
                      </button>
                      <button
                        type="button"
                        onClick={() => void onDelete(item.id)}
                        aria-label="Delete memory"
                        className="text-ink-muted/60 hover:text-crimson"
                      >
                        <IconTrash size={13} />
                      </button>
                    </div>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </main>
  );
}
