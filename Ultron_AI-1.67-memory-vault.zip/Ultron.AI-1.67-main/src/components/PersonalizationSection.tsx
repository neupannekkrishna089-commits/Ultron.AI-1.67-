import { useEffect, useState } from "react";
import type { Instruction } from "~/lib/personalization/types";
import {
  createInstruction,
  deleteInstruction,
  listInstructions,
  reorderInstruction,
  setInstructionEnabled,
  updateInstruction,
} from "~/lib/personalization/store";
import { IconChevronDown, IconChevronUp, IconPencil, IconPlus, IconSparkle, IconTrash } from "~/components/icons";

export function PersonalizationSection() {
  const [items, setItems] = useState<Instruction[] | null>(null);
  const [draft, setDraft] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState("");

  const refresh = async () => setItems(await listInstructions());

  useEffect(() => {
    void refresh();
  }, []);

  const onAdd = async () => {
    if (!draft.trim()) return;
    await createInstruction(draft.trim());
    setDraft("");
    void refresh();
  };

  const onToggle = async (item: Instruction) => {
    await setInstructionEnabled(item.id, !item.enabled);
    void refresh();
  };

  const onDelete = async (id: string) => {
    await deleteInstruction(id);
    void refresh();
  };

  const onMove = async (id: string, dir: "up" | "down") => {
    await reorderInstruction(id, dir);
    void refresh();
  };

  const startEdit = (item: Instruction) => {
    setEditingId(item.id);
    setEditingText(item.text);
  };

  const saveEdit = async () => {
    if (!editingId) return;
    await updateInstruction(editingId, editingText.trim());
    setEditingId(null);
    void refresh();
  };

  return (
    <section className="ultron-elevate mb-5 rounded-[14px] border border-graphite-700/70 bg-graphite-900">
      <div className="flex items-start gap-3 border-b border-graphite-700/60 px-5 py-4">
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[9px] bg-graphite-800 text-crimson ring-1 ring-inset ring-graphite-700">
          <IconSparkle size={15} />
        </span>
        <div>
          <h2 className="text-[13px] font-medium text-ink">Personalization</h2>
          <p className="mt-0.5 text-[12px] leading-relaxed text-ink-muted">
            Standing instructions that shape how ULTRON responds. Only enabled instructions, in
            this order, are sent with every request.
          </p>
        </div>
      </div>

      <div className="px-5 py-4.5">
        <div className="mb-3 flex gap-2">
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && void onAdd()}
            placeholder="Add an instruction…"
            className="w-full rounded-[9px] border border-graphite-700 bg-graphite-800 px-3 py-2 text-[12.5px] text-ink outline-none transition-colors focus:border-graphite-500 placeholder:text-ink-muted/55"
          />
          <button
            type="button"
            onClick={() => void onAdd()}
            disabled={!draft.trim()}
            className="flex shrink-0 items-center gap-1 rounded-[9px] bg-crimson px-3 py-2 text-[12px] font-semibold text-white transition-all duration-150 ease-out hover:bg-crimson-hover active:scale-[0.97] disabled:cursor-not-allowed disabled:bg-graphite-700 disabled:text-ink-muted/40"
          >
            <IconPlus size={13} />
          </button>
        </div>

        {items === null ? (
          <p className="text-[12px] text-ink-muted">Loading…</p>
        ) : (
          <ul className="space-y-1.5">
            {items.map((item, idx) => (
              <li
                key={item.id}
                className={
                  "flex items-center gap-2 rounded-[9px] border px-3 py-2 transition-colors " +
                  (item.enabled ? "border-graphite-700/70 bg-graphite-800/50" : "border-graphite-700/30 bg-graphite-800/20 opacity-55")
                }
              >
                <div className="flex shrink-0 flex-col">
                  <button
                    type="button"
                    onClick={() => void onMove(item.id, "up")}
                    disabled={idx === 0}
                    aria-label="Move up"
                    className="text-ink-muted/60 hover:text-ink disabled:opacity-30"
                  >
                    <IconChevronUp size={12} />
                  </button>
                  <button
                    type="button"
                    onClick={() => void onMove(item.id, "down")}
                    disabled={idx === items.length - 1}
                    aria-label="Move down"
                    className="text-ink-muted/60 hover:text-ink disabled:opacity-30"
                  >
                    <IconChevronDown size={12} />
                  </button>
                </div>

                {editingId === item.id ? (
                  <input
                    value={editingText}
                    onChange={(e) => setEditingText(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && void saveEdit()}
                    onBlur={() => void saveEdit()}
                    autoFocus
                    className="flex-1 rounded-md border border-graphite-600 bg-graphite-800 px-2 py-1 text-[12px] text-ink outline-none"
                  />
                ) : (
                  <span className="flex-1 text-[12px] leading-snug text-ink-soft">{item.text}</span>
                )}

                <button type="button" onClick={() => startEdit(item)} aria-label="Edit" className="text-ink-muted/60 hover:text-ink">
                  <IconPencil size={12} />
                </button>
                <button
                  type="button"
                  role="switch"
                  aria-checked={item.enabled}
                  aria-label={item.enabled ? "Disable" : "Enable"}
                  onClick={() => void onToggle(item)}
                  className={
                    "relative h-4.5 w-8 shrink-0 rounded-full transition-colors duration-150 ease-out " +
                    (item.enabled ? "bg-crimson" : "bg-graphite-700")
                  }
                >
                  <span
                    className={
                      "absolute top-0.5 h-3.5 w-3.5 rounded-full bg-white transition-transform duration-150 ease-out " +
                      (item.enabled ? "translate-x-[15px]" : "translate-x-0.5")
                    }
                  />
                </button>
                <button type="button" onClick={() => void onDelete(item.id)} aria-label="Delete" className="text-ink-muted/60 hover:text-crimson">
                  <IconTrash size={12} />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
