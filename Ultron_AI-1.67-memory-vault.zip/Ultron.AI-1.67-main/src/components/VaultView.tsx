import { useEffect, useState } from "react";
import type { VaultItem } from "~/lib/vault/types";
import { createVaultItem, deleteVaultItem, listVault, searchVault, updateVaultItem } from "~/lib/vault/store";
import { IconPencil, IconPlus, IconSearch, IconTrash, IconVault, IconX } from "~/components/icons";

type FormState = {
  id: string | null;
  title: string;
  content: string;
  category: string;
  tags: string; // comma-separated in the form, split on save
};

const EMPTY_FORM: FormState = { id: null, title: "", content: "", category: "General", tags: "" };

export function VaultView() {
  const [items, setItems] = useState<VaultItem[] | null>(null);
  const [query, setQuery] = useState("");
  const [form, setForm] = useState<FormState | null>(null);

  const refresh = async (q = query) => {
    setItems(q.trim() ? await searchVault(q) : await listVault());
  };

  useEffect(() => {
    void refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onSearchChange = (v: string) => {
    setQuery(v);
    void refresh(v);
  };

  const openNew = () => setForm({ ...EMPTY_FORM });
  const openEdit = (item: VaultItem) =>
    setForm({ id: item.id, title: item.title, content: item.content, category: item.category, tags: item.tags.join(", ") });

  const save = async () => {
    if (!form || !form.title.trim() || !form.content.trim()) return;
    const tags = form.tags
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean);
    if (form.id) {
      await updateVaultItem(form.id, { title: form.title, content: form.content, category: form.category, tags });
    } else {
      await createVaultItem({ title: form.title, content: form.content, category: form.category, tags });
    }
    setForm(null);
    void refresh();
  };

  const onDelete = async (id: string) => {
    await deleteVaultItem(id);
    if (form?.id === id) setForm(null);
    void refresh();
  };

  return (
    <main className="ultron-canvas ultron-scroll h-full min-w-0 flex-1 overflow-y-auto">
      <div className="mx-auto w-full max-w-2xl px-6 py-10">
        <header className="mb-6 flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[9px] bg-graphite-800 text-crimson ring-1 ring-inset ring-graphite-700">
              <IconVault size={15} />
            </span>
            <div>
              <h1 className="text-[19px] font-medium tracking-[-0.01em] text-ink">Knowledge Vault</h1>
              <p className="mt-1 text-[12.5px] text-ink-muted">
                Notes, projects, and reference material you've intentionally given ULTRON. Only
                what's relevant to a question gets pulled in — not the whole vault.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={openNew}
            className="flex shrink-0 items-center gap-1.5 rounded-[9px] bg-crimson px-3 py-1.5 text-[12px] font-semibold text-white transition-all duration-150 ease-out hover:bg-crimson-hover active:scale-[0.97]"
          >
            <IconPlus size={13} /> New
          </button>
        </header>

        {/* Add/edit form */}
        {form && (
          <div className="ultron-elevate mb-5 rounded-[14px] border border-graphite-700/70 bg-graphite-900 p-4">
            <div className="mb-2.5 flex items-center justify-between">
              <span className="text-[12.5px] font-medium text-ink">{form.id ? "Edit entry" : "New entry"}</span>
              <button type="button" onClick={() => setForm(null)} className="text-ink-muted hover:text-ink">
                <IconX size={14} />
              </button>
            </div>
            <input
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="Title"
              className="mb-2 w-full rounded-[9px] border border-graphite-700 bg-graphite-800 px-3 py-2 text-[12.5px] text-ink outline-none transition-colors focus:border-graphite-500 placeholder:text-ink-muted/55"
            />
            <textarea
              value={form.content}
              onChange={(e) => setForm({ ...form, content: e.target.value })}
              placeholder="Content"
              rows={5}
              className="ultron-scroll mb-2 w-full resize-none rounded-[9px] border border-graphite-700 bg-graphite-800 px-3 py-2 text-[12.5px] text-ink outline-none transition-colors focus:border-graphite-500 placeholder:text-ink-muted/55"
            />
            <div className="mb-3 flex gap-2">
              <input
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                placeholder="Category (e.g. School, Projects)"
                className="w-1/2 rounded-[9px] border border-graphite-700 bg-graphite-800 px-3 py-2 text-[12.5px] text-ink outline-none transition-colors focus:border-graphite-500 placeholder:text-ink-muted/55"
              />
              <input
                value={form.tags}
                onChange={(e) => setForm({ ...form, tags: e.target.value })}
                placeholder="Tags, comma-separated"
                className="w-1/2 rounded-[9px] border border-graphite-700 bg-graphite-800 px-3 py-2 text-[12.5px] text-ink outline-none transition-colors focus:border-graphite-500 placeholder:text-ink-muted/55"
              />
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setForm(null)}
                className="rounded-[9px] px-3 py-1.5 text-[12px] text-ink-muted hover:text-ink"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void save()}
                disabled={!form.title.trim() || !form.content.trim()}
                className="rounded-[9px] bg-crimson px-3.5 py-1.5 text-[12px] font-semibold text-white transition-all duration-150 ease-out hover:bg-crimson-hover active:scale-[0.97] disabled:cursor-not-allowed disabled:bg-graphite-700 disabled:text-ink-muted/40"
              >
                Save
              </button>
            </div>
          </div>
        )}

        {/* Search */}
        <div className="mb-4 flex items-center gap-2 rounded-[10px] border border-graphite-700 bg-graphite-850 px-3 py-2">
          <IconSearch size={13} className="text-ink-muted" />
          <input
            value={query}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search the vault…"
            className="w-full bg-transparent text-[12.5px] text-ink outline-none placeholder:text-ink-muted/55"
          />
        </div>

        {/* List */}
        {items === null ? (
          <p className="text-[12.5px] text-ink-muted">Loading…</p>
        ) : items.length === 0 ? (
          <p className="rounded-[10px] border border-graphite-700 bg-graphite-850/40 px-4 py-6 text-center text-[12.5px] text-ink-muted">
            {query.trim() ? "No entries match that search." : "The vault is empty — add something ULTRON should know."}
          </p>
        ) : (
          <ul className="space-y-2">
            {items.map((item) => (
              <li key={item.id} className="ultron-elevate rounded-[12px] border border-graphite-700/70 bg-graphite-900 px-4 py-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="rounded-full bg-graphite-800 px-2 py-0.5 text-[10px] font-medium text-ink-muted">
                        {item.category}
                      </span>
                      {item.tags.map((t) => (
                        <span key={t} className="text-[10px] text-ink-muted/70">
                          #{t}
                        </span>
                      ))}
                    </div>
                    <h3 className="mt-1.5 truncate text-[13px] font-medium text-ink">{item.title}</h3>
                    <p className="mt-1 line-clamp-2 text-[12px] leading-relaxed text-ink-muted">{item.content}</p>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <button type="button" onClick={() => openEdit(item)} aria-label="Edit" className="text-ink-muted/60 hover:text-ink">
                      <IconPencil size={13} />
                    </button>
                    <button
                      type="button"
                      onClick={() => void onDelete(item.id)}
                      aria-label="Delete"
                      className="text-ink-muted/60 hover:text-crimson"
                    >
                      <IconTrash size={13} />
                    </button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </main>
  );
}
