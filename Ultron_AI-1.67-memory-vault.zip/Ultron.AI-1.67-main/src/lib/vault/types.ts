// Knowledge Vault — reference material the user intentionally hands
// ULTRON: school notes, personal instructions, project docs, technical
// notes, anything they want available as context later. Distinct from
// long-term memory (~/lib/memory): a vault item is content, not a fact
// about the user, and there's no importance ranking — relevance to a given
// question is what determines whether it's retrieved (see
// ~/lib/memory/retrieval.ts).

export type VaultItem = {
  id: string;
  title: string;
  content: string;
  category: string; // free-form, e.g. "School", "Projects", "Reference" — no fixed enum yet
  tags: string[];
  source: string; // e.g. "user" or where it came from — free text for now
  createdAt: number;
  updatedAt: number;
};

export type VaultDraft = {
  title: string;
  content: string;
  category?: string;
  tags?: string[];
  source?: string;
};
