// Knowledge Vault store — CRUD + keyword search over vault_items.
//
// Desktop: a real SQLite table. Browser preview: a JSON array in
// localStorage, filtered in JS. Same shape either way.

import { getDatabase } from "~/lib/db";
import type { VaultDraft, VaultItem } from "~/lib/vault/types";

const FALLBACK_KEY = "ultron.vault.v1";

function uid(): string {
  return "vault_" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

function loadFallback(): VaultItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(FALLBACK_KEY);
    return raw ? (JSON.parse(raw) as VaultItem[]) : [];
  } catch {
    return [];
  }
}

function saveFallback(items: VaultItem[]): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(FALLBACK_KEY, JSON.stringify(items));
  } catch {
    // ignore
  }
}

type Row = {
  id: string;
  title: string;
  content: string;
  category: string;
  tags: string; // JSON array, stored as text
  source: string;
  created_at: number;
  updated_at: number;
};

function fromRow(r: Row): VaultItem {
  let tags: string[] = [];
  try {
    tags = JSON.parse(r.tags);
  } catch {
    tags = [];
  }
  return {
    id: r.id,
    title: r.title,
    content: r.content,
    category: r.category,
    tags,
    source: r.source,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

export async function listVault(): Promise<VaultItem[]> {
  const db = await getDatabase();
  if (!db) return loadFallback().sort((a, b) => b.updatedAt - a.updatedAt);
  const rows = await db.select<Row>("SELECT * FROM vault_items ORDER BY updated_at DESC");
  return rows.map(fromRow);
}

export async function searchVault(query: string): Promise<VaultItem[]> {
  const all = await listVault();
  const q = query.trim().toLowerCase();
  if (!q) return all;
  return all.filter(
    (v) =>
      v.title.toLowerCase().includes(q) ||
      v.content.toLowerCase().includes(q) ||
      v.tags.some((t) => t.toLowerCase().includes(q)) ||
      v.category.toLowerCase().includes(q),
  );
}

export async function createVaultItem(draft: VaultDraft): Promise<VaultItem> {
  const now = Date.now();
  const item: VaultItem = {
    id: uid(),
    title: draft.title.trim(),
    content: draft.content.trim(),
    category: draft.category?.trim() || "General",
    tags: draft.tags ?? [],
    source: draft.source?.trim() || "user",
    createdAt: now,
    updatedAt: now,
  };
  const db = await getDatabase();
  if (!db) {
    const items = loadFallback();
    items.push(item);
    saveFallback(items);
    return item;
  }
  await db.execute(
    "INSERT INTO vault_items (id, title, content, category, tags, source, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)",
    [item.id, item.title, item.content, item.category, JSON.stringify(item.tags), item.source, item.createdAt, item.updatedAt],
  );
  return item;
}

export async function updateVaultItem(id: string, patch: Partial<VaultDraft>): Promise<void> {
  const updatedAt = Date.now();
  const db = await getDatabase();
  if (!db) {
    const items = loadFallback();
    const idx = items.findIndex((v) => v.id === id);
    if (idx === -1) return;
    items[idx] = { ...items[idx], ...patch, updatedAt } as VaultItem;
    saveFallback(items);
    return;
  }
  const sets: string[] = [];
  const values: unknown[] = [];
  let i = 1;
  if (patch.title !== undefined) { sets.push(`title = $${i++}`); values.push(patch.title); }
  if (patch.content !== undefined) { sets.push(`content = $${i++}`); values.push(patch.content); }
  if (patch.category !== undefined) { sets.push(`category = $${i++}`); values.push(patch.category); }
  if (patch.tags !== undefined) { sets.push(`tags = $${i++}`); values.push(JSON.stringify(patch.tags)); }
  if (patch.source !== undefined) { sets.push(`source = $${i++}`); values.push(patch.source); }
  sets.push(`updated_at = $${i++}`);
  values.push(updatedAt);
  values.push(id);
  if (sets.length === 1) return;
  await db.execute(`UPDATE vault_items SET ${sets.join(", ")} WHERE id = $${i}`, values);
}

export async function deleteVaultItem(id: string): Promise<void> {
  const db = await getDatabase();
  if (!db) {
    saveFallback(loadFallback().filter((v) => v.id !== id));
    return;
  }
  await db.execute("DELETE FROM vault_items WHERE id = $1", [id]);
}
