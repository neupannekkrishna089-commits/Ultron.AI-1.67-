// ULTRON AI Core — shared types.
//
// This is the provider-agnostic contract every adapter implements. The chat
// UI (App.tsx) only ever talks to this shape — never to a specific
// provider's SDK or request format — so a provider can be added, replaced,
// or removed without touching ChatView, SettingsView, or the conversation
// model in ~/lib/ultron.
//
// The actual network request happens in Rust (src-tauri/src/ai.rs), not
// here — adapters in this app are thin wrappers around Tauri's invoke/event
// bridge so that API keys never enter the frontend bundle. See
// src/lib/ai/providers/anthropic.ts.

export type AIProviderId = "anthropic" | "openai" | "google" | "xai" | "openrouter";

/** Task categories the AI Router can eventually assign to different
 *  models/providers. Only CHAT is actually used by the UI right now —
 *  the rest exist so the router's shape doesn't need to change when
 *  Research/Coding/Study/etc. are built later. */
export type AITaskType =
  | "CHAT"
  | "RESEARCH"
  | "CODING"
  | "DOCUMENT_ANALYSIS"
  | "STUDY"
  | "VISION"
  | "PLANNING"
  | "VOICE";

export type AIRole = "user" | "assistant";

export type AIMessage = {
  role: AIRole;
  content: string;
};

export type AIRequest = {
  taskType: AITaskType;
  systemInstruction?: string;
  messages: AIMessage[];
  model?: string; // overrides the provider's configured default model
  temperature?: number;
  maxOutputTokens?: number;
};

export type AIUsage = {
  inputTokens?: number;
  outputTokens?: number;
};

export type AIErrorCode =
  | "no_api_key"
  | "invalid_api_key"
  | "network_error"
  | "provider_unavailable"
  | "rate_limited"
  | "model_unavailable"
  | "timeout"
  | "cancelled"
  | "unknown";

export type AIError = {
  code: AIErrorCode;
  message: string;
};

export type AIStreamHandlers = {
  onDelta: (text: string) => void;
  onDone: (usage: AIUsage) => void;
  onError: (error: AIError) => void;
};

/** What every provider adapter must implement. Adapters are thin — the real
 *  work happens behind the Tauri command boundary — but the interface is
 *  what makes providers swappable from the chat layer's point of view. */
export interface AIProvider {
  readonly id: AIProviderId;
  readonly label: string;
  readonly implemented: boolean;
  readonly models: string[];
  readonly defaultModel: string;

  /** Starts a streaming request; returns immediately with a request id used
   *  for cancellation. Delivery of the reply happens via `handlers`. */
  sendMessage: (request: AIRequest, handlers: AIStreamHandlers) => Promise<string>;
  cancel: (requestId: string) => Promise<void>;
}

/** Human-readable fallback text for each error code, used when a provider
 *  error doesn't include its own message. */
export const AI_ERROR_FALLBACK: Record<AIErrorCode, string> = {
  no_api_key: "No API key is saved for this provider yet — add one in Settings.",
  invalid_api_key: "That API key was rejected — check it in Settings.",
  network_error: "Couldn't reach the provider — check your internet connection.",
  provider_unavailable: "The provider is unavailable right now.",
  rate_limited: "Rate limit reached — wait a moment and try again.",
  model_unavailable: "That model isn't available.",
  timeout: "The request timed out.",
  cancelled: "Stopped.",
  unknown: "Something went wrong.",
};
