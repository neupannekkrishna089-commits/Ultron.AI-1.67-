// AI Core orchestrator — the one function App.tsx calls to get a streamed
// reply. Ties together the router (which provider/model), the context
// builder (which messages to send), and the provider registry (how to
// actually send them). Nothing else in the app needs to know those three
// pieces exist separately.

import type { AISettings, Message } from "~/lib/ultron";
import type { AIStreamHandlers, AITaskType } from "~/lib/ai/types";
import { buildContext } from "~/lib/ai/context";
import { routeTask } from "~/lib/ai/router";
import { getProvider } from "~/lib/ai/registry";

export type { AIError, AIErrorCode, AIProviderId, AIUsage } from "~/lib/ai/types";
export { AI_ERROR_FALLBACK } from "~/lib/ai/types";
export { getProvider, PROVIDER_LIST } from "~/lib/ai/registry";

/** Starts a streaming AI reply for the given conversation history. Returns
 *  a requestId (for cancellation) plus which provider ended up handling it,
 *  once the request has actually been dispatched. */
export async function streamAiReply(
  history: Message[],
  settings: AISettings,
  handlers: AIStreamHandlers,
  taskType: AITaskType = "CHAT",
): Promise<{ requestId: string; providerId: string }> {
  const latestUserMessage = [...history].reverse().find((m) => m.role === "user")?.text ?? "";
  const decision = await routeTask(taskType, settings, latestUserMessage);
  const provider = getProvider(decision.providerId);

  const requestId = await provider.sendMessage(
    {
      taskType,
      systemInstruction: decision.systemInstruction,
      messages: buildContext(history),
      model: decision.model,
      temperature: settings.temperature,
      maxOutputTokens: settings.maxOutputTokens,
    },
    handlers,
  );

  return { requestId, providerId: decision.providerId };
}

export async function cancelAiReply(providerId: string, requestId: string): Promise<void> {
  if (!requestId) return;
  const provider = getProvider(providerId as Parameters<typeof getProvider>[0]);
  await provider.cancel(requestId);
}
