// Context management — turns ULTRON's conversation history into the message
// list actually sent to a provider.
//
// Deliberately simple right now: a fixed-size recency window, no token
// counting, no summarization. That's a real limitation (a long conversation
// will eventually drop early messages entirely), but building real
// token-aware trimming/summarization now would be guessing at requirements
// Long-term Memory and the Knowledge Vault haven't defined yet. This file is
// the seam where that logic will attach later — everything above it
// (router, provider adapters) just consumes whatever `buildContext` returns.

import type { Message } from "~/lib/ultron";
import type { AIMessage } from "~/lib/ai/types";

/** How many prior messages (user + assistant) to include as context.
 *  A crude stand-in for a real token budget — fine for short conversations,
 *  not a long-term solution. */
const DEFAULT_MAX_MESSAGES = 20;

export function buildContext(messages: Message[], maxMessages = DEFAULT_MAX_MESSAGES): AIMessage[] {
  const recent = messages.slice(-maxMessages);
  return recent
    .filter((m) => m.text.trim().length > 0) // skip attachment-only messages — no content to send yet
    .map((m) => ({
      role: m.role,
      content: m.attachment ? `${m.text}\n\n[Attached: ${m.attachment.name} — not yet readable by ULTRON]` : m.text,
    }));
}
