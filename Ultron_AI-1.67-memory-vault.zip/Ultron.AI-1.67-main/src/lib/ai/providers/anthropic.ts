// Anthropic provider adapter.
//
// This file does NOT make the HTTP request and never sees the API key —
// it invokes the Rust `send_chat_message` command and listens for the
// `ultron://ai-stream` / `ultron://ai-done` / `ultron://ai-error` events
// that command emits, filtering by requestId. The actual network call and
// key storage live in src-tauri/src/ai.rs. That split is what keeps
// secrets out of the frontend bundle.

import type { AIError, AIErrorCode, AIProvider, AIRequest, AIStreamHandlers, AIUsage } from "~/lib/ai/types";
import { AI_ERROR_FALLBACK } from "~/lib/ai/types";

function newRequestId(): string {
  return "req_" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

export const anthropicProvider: AIProvider = {
  id: "anthropic",
  label: "Anthropic",
  implemented: true,
  models: ["claude-sonnet-5", "claude-opus-4-8", "claude-haiku-4-5-20251001"],
  defaultModel: "claude-sonnet-5",

  async sendMessage(request: AIRequest, handlers: AIStreamHandlers): Promise<string> {
    const requestId = newRequestId();
    const { invoke } = await import("@tauri-apps/api/core");
    const { listen } = await import("@tauri-apps/api/event");

    type StreamPayload = { requestId: string; delta: string };
    type DonePayload = { requestId: string; usage: { inputTokens?: number; outputTokens?: number } };
    type ErrorPayload = { requestId: string; code: AIErrorCode; message: string };

    let unlistenStream: (() => void) | undefined;
    let unlistenDone: (() => void) | undefined;
    let unlistenError: (() => void) | undefined;
    const cleanup = () => {
      unlistenStream?.();
      unlistenDone?.();
      unlistenError?.();
    };

    unlistenStream = await listen<StreamPayload>("ultron://ai-stream", (e) => {
      if (e.payload.requestId !== requestId) return;
      handlers.onDelta(e.payload.delta);
    });
    unlistenDone = await listen<DonePayload>("ultron://ai-done", (e) => {
      if (e.payload.requestId !== requestId) return;
      const usage: AIUsage = {
        inputTokens: e.payload.usage.inputTokens,
        outputTokens: e.payload.usage.outputTokens,
      };
      cleanup();
      handlers.onDone(usage);
    });
    unlistenError = await listen<ErrorPayload>("ultron://ai-error", (e) => {
      if (e.payload.requestId !== requestId) return;
      const error: AIError = {
        code: e.payload.code,
        message: e.payload.message || AI_ERROR_FALLBACK[e.payload.code] || AI_ERROR_FALLBACK.unknown,
      };
      cleanup();
      handlers.onError(error);
    });

    try {
      await invoke("send_chat_message", {
        req: {
          request_id: requestId,
          provider: "anthropic",
          model: request.model || this.defaultModel,
          system: request.systemInstruction ?? null,
          messages: request.messages.map((m) => ({ role: m.role, content: m.content })),
          temperature: request.temperature ?? null,
          max_tokens: request.maxOutputTokens ?? null,
        },
      });
    } catch (err) {
      cleanup();
      handlers.onError({ code: "unknown", message: String(err) });
    }

    return requestId;
  },

  async cancel(requestId: string): Promise<void> {
    const { invoke } = await import("@tauri-apps/api/core");
    await invoke("cancel_ai_request", { requestId });
  },
};
