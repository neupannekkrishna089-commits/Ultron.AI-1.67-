// Provider registry — every provider ULTRON intends to support eventually,
// with a flag for whether it's actually wired up. Settings uses `implemented`
// to grey out / label the rest as "coming soon" rather than hiding them or
// pretending they work.
//
// Adding a real provider later means: write src/lib/ai/providers/<id>.ts
// implementing AIProvider, add it to `PROVIDERS` below, and (for anything
// beyond a simple REST+SSE API) add a matching branch in
// src-tauri/src/ai.rs's `run_request`. Nothing in App.tsx, ChatView, or
// SettingsView needs to change beyond picking the new id from this list.

import type { AIProvider, AIProviderId } from "~/lib/ai/types";
import { anthropicProvider } from "~/lib/ai/providers/anthropic";

type ProviderEntry = AIProvider;

/** Placeholder entry for a provider that's named but not implemented yet —
 *  calling `sendMessage` reports `provider_unavailable` immediately instead
 *  of pretending to work. */
function notImplemented(id: AIProviderId, label: string, models: string[]): ProviderEntry {
  return {
    id,
    label,
    implemented: false,
    models,
    defaultModel: models[0] ?? "",
    async sendMessage(_request, handlers) {
      handlers.onError({
        code: "provider_unavailable",
        message: `${label} isn't wired up yet — Anthropic is the only provider implemented in this build.`,
      });
      return "";
    },
    async cancel() {
      // nothing to cancel — sendMessage above never starts a real request
    },
  };
}

export const PROVIDERS: Record<AIProviderId, ProviderEntry> = {
  anthropic: anthropicProvider,
  openai: notImplemented("openai", "OpenAI", ["gpt-5.1", "gpt-5.1-mini"]),
  google: notImplemented("google", "Google Gemini", ["gemini-3-pro", "gemini-3-flash"]),
  xai: notImplemented("xai", "xAI Grok", ["grok-4"]),
  openrouter: notImplemented("openrouter", "OpenRouter", ["openrouter/auto"]),
};

export const PROVIDER_LIST: ProviderEntry[] = Object.values(PROVIDERS);

export function getProvider(id: AIProviderId): ProviderEntry {
  return PROVIDERS[id];
}
