// Personalization — standing behavior instructions fed into the AI Core's
// system prompt for every request (see ~/lib/ai/router.ts). Distinct from
// memory/vault: these shape *how* ULTRON responds, not *what* it knows.

export type Instruction = {
  id: string;
  text: string;
  enabled: boolean;
  order: number;
  isDefault: boolean; // seeded instruction vs. user-added — cosmetic only, both are editable/deletable
  createdAt: number;
  updatedAt: number;
};

export const DEFAULT_INSTRUCTIONS: string[] = [
  "Use emojis naturally when useful.",
  "Keep answers short to moderate unless more detail is necessary.",
  "Consider relevant possibilities and important edge cases before answering.",
  "Prioritize accuracy over speed.",
  "Explain complicated concepts clearly.",
  "Avoid unnecessary repetition.",
  "Be honest about uncertainty.",
  "Adapt explanations to the user's request.",
  "Never claim an action was performed unless it was actually performed.",
  "Be loyal, disciplined, calm, naturally humorous and respectful.",
  'Use "sir" naturally and sparingly.',
];
