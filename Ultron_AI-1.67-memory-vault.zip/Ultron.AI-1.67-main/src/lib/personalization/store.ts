// Personalization store — CRUD + reorder over personalization_instructions,
// plus `buildPersonalizationBlock`, which is what makes this real rather
// than decorative: the AI Router (~/lib/ai/router.ts) calls it and appends
// the result to every request's system instruction.

import { getDatabase } from "~/lib/db";
import { DEFAULT_INSTRUCTIONS } from "~/lib/personalization/types";
import type { Instruction } from "~/lib/personalization/types";

const FALLBACK_KEY = "ultron.personalization.v1";
const SEEDED_FLAG_KEY = "ultron.personalization.seeded.v1";

function uid(): string {
  return "instr_" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

function loadFallback(): Instruction[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(FALLBACK_KEY);
    return raw ? (JSON.parse(raw) as Instruction[]) : [];
  } catch {
    return [];
  }
}

function saveFallback(items: Instruction[]): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(FALLBACK_KEY, JSON.stringify(items));
  } catch {
    // ignore
  }
}

type Row = {
  id: string;
  text: string;
  enabled: number;
  sort_order: number;
  is_default: number;
  created_at: number;
  updated_at: number;
};

function fromRow(r: Row): Instruction {
  return {
    id: r.id,
    text: r.text,
    enabled: r.enabled === 1,
    order: r.sort_order,
    isDefault: r.is_default === 1,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

async function seedDefaultsIfNeeded(): Promise<void> {
  const db = await getDatabase();
  if (!db) {
    if (typeof window === "undefined") return;
    if (window.localStorage.getItem(SEEDED_FLAG_KEY)) return;
    const now = Date.now();
    const seeded = DEFAULT_INSTRUCTIONS.map((text, i) => ({
      id: uid(),
      text,
      enabled: true,
      order: i,
      isDefault: true,
      createdAt: now,
      updatedAt: now,
    }));
    saveFallback([...loadFallback(), ...seeded]);
    window.localStorage.setItem(SEEDED_FLAG_KEY, "1");
    return;
  }
  const existing = await db.select<{ n: number }>("SELECT COUNT(*) as n FROM personalization_instructions");
  if ((existing[0]?.n ?? 0) > 0) return; // already seeded (or user cleared everything, in which case we leave it empty)
  const now = Date.now();
  for (let i = 0; i < DEFAULT_INSTRUCTIONS.length; i++) {
    await db.execute(
      "INSERT INTO personalization_instructions (id, text, enabled, sort_order, is_default, created_at, updated_at) VALUES ($1,$2,1,$3,1,$4,$4)",
      [uid(), DEFAULT_INSTRUCTIONS[i], i, now],
    );
  }
}

export async function listInstructions(): Promise<Instruction[]> {
  await seedDefaultsIfNeeded();
  const db = await getDatabase();
  if (!db) return loadFallback().sort((a, b) => a.order - b.order);
  const rows = await db.select<Row>("SELECT * FROM personalization_instructions ORDER BY sort_order ASC");
  return rows.map(fromRow);
}

export async function createInstruction(text: string): Promise<Instruction> {
  const all = await listInstructions();
  const now = Date.now();
  const item: Instruction = {
    id: uid(),
    text: text.trim(),
    enabled: true,
    order: all.length,
    isDefault: false,
    createdAt: now,
    updatedAt: now,
  };
  const db = await getDatabase();
  if (!db) {
    saveFallback([...all, item]);
    return item;
  }
  await db.execute(
    "INSERT INTO personalization_instructions (id, text, enabled, sort_order, is_default, created_at, updated_at) VALUES ($1,$2,1,$3,0,$4,$4)",
    [item.id, item.text, item.order, item.createdAt],
  );
  return item;
}

export async function updateInstruction(id: string, text: string): Promise<void> {
  const updatedAt = Date.now();
  const db = await getDatabase();
  if (!db) {
    const items = loadFallback();
    const idx = items.findIndex((i) => i.id === id);
    if (idx === -1) return;
    items[idx] = { ...items[idx], text, updatedAt };
    saveFallback(items);
    return;
  }
  await db.execute("UPDATE personalization_instructions SET text = $1, updated_at = $2 WHERE id = $3", [
    text,
    updatedAt,
    id,
  ]);
}

export async function setInstructionEnabled(id: string, enabled: boolean): Promise<void> {
  const updatedAt = Date.now();
  const db = await getDatabase();
  if (!db) {
    const items = loadFallback();
    const idx = items.findIndex((i) => i.id === id);
    if (idx === -1) return;
    items[idx] = { ...items[idx], enabled, updatedAt };
    saveFallback(items);
    return;
  }
  await db.execute("UPDATE personalization_instructions SET enabled = $1, updated_at = $2 WHERE id = $3", [
    enabled ? 1 : 0,
    updatedAt,
    id,
  ]);
}

export async function deleteInstruction(id: string): Promise<void> {
  const db = await getDatabase();
  if (!db) {
    saveFallback(loadFallback().filter((i) => i.id !== id));
    return;
  }
  await db.execute("DELETE FROM personalization_instructions WHERE id = $1", [id]);
}

/** Swaps the sort order of two adjacent instructions — the reordering
 *  primitive the UI's up/down controls call. */
export async function reorderInstruction(id: string, direction: "up" | "down"): Promise<void> {
  const all = await listInstructions();
  const idx = all.findIndex((i) => i.id === id);
  if (idx === -1) return;
  const swapWith = direction === "up" ? idx - 1 : idx + 1;
  if (swapWith < 0 || swapWith >= all.length) return;

  const a = all[idx];
  const b = all[swapWith];
  const updatedAt = Date.now();
  const db = await getDatabase();
  if (!db) {
    const items = loadFallback();
    const ia = items.findIndex((i) => i.id === a.id);
    const ib = items.findIndex((i) => i.id === b.id);
    if (ia === -1 || ib === -1) return;
    items[ia] = { ...items[ia], order: b.order, updatedAt };
    items[ib] = { ...items[ib], order: a.order, updatedAt };
    saveFallback(items);
    return;
  }
  await db.execute("UPDATE personalization_instructions SET sort_order = $1, updated_at = $2 WHERE id = $3", [
    b.order,
    updatedAt,
    a.id,
  ]);
  await db.execute("UPDATE personalization_instructions SET sort_order = $1, updated_at = $2 WHERE id = $3", [
    a.order,
    updatedAt,
    b.id,
  ]);
}

/** What actually reaches the AI Core: enabled instructions only, in order,
 *  formatted as a labeled block. Called from ~/lib/ai/router.ts on every
 *  request — not cached, so a change in Settings takes effect on the very
 *  next message. */
export async function buildPersonalizationBlock(): Promise<string> {
  const all = await listInstructions();
  const enabled = all.filter((i) => i.enabled);
  if (enabled.length === 0) return "";
  return "Personalization instructions (follow these):\n" + enabled.map((i) => `- ${i.text}`).join("\n");
}
