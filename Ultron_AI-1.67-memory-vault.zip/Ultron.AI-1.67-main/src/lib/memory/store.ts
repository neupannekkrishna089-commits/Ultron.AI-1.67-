// Long-term memory store — CRUD + search over memory_items.
//
// Desktop: a real SQLite table (see the migration in src-tauri/src/lib.rs).
// Browser preview (no Tauri): a JSON array in localStorage, filtered in JS —
// same shape, so the UI behaves identically either way, just without
// SQL-level indexing.

import { getDatabase } from "~/lib/db";
import type { MemoryDraft, MemoryItem } from "~/lib/memory/types";

const FALLBACK_KEY = "ultron.memory.v1";

function uid(): string {
  return "mem_" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

// ---- browser-preview fallback ---------------------------------------------

function loadFallback(): MemoryItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(FALLBACK_KEY);
    return raw ? (JSON.parse(raw) as MemoryItem[]) : [];
  } catch {
    return [];
  }
}

function saveFallback(items: MemoryItem[]): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(FALLBACK_KEY, JSON.stringify(items));
  } catch {
    // ignore
  }
}

// ---- row mapping ------------------------------------------------------------

type Row = {
  id: string;
  content: string;
  source: string;
  importance: number;
  enabled: number;
  created_at: number;
  updated_at: number;
};

function fromRow(r: Row): MemoryItem {
  return {
    id: r.id,
    content: r.content,
    source: r.source as MemoryItem["source"],
    importance: r.importance,
    enabled: r.enabled === 1,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

// ---- public API ---------------------------------------------------------

export async function listMemory(): Promise<MemoryItem[]> {
  const db = await getDatabase();
  if (!db) return loadFallback().sort((a, b) => b.updatedAt - a.updatedAt);
  const rows = await db.select<Row>(
    "SELECT * FROM memory_items ORDER BY importance DESC, updated_at DESC",
  );
  return rows.map(fromRow);
}

export async function searchMemory(query: string): Promise<MemoryItem[]> {
  const all = await listMemory();
  const q = query.trim().toLowerCase();
  if (!q) return all;
  return all.filter((m) => m.content.toLowerCase().includes(q));
}

export async function createMemory(draft: MemoryDraft): Promise<MemoryItem> {
  const now = Date.now();
  const item: MemoryItem = {
    id: uid(),
    content: draft.content.trim(),
    source: draft.source ?? "user",
    importance: draft.importance ?? 3,
    enabled: draft.enabled ?? true,
    createdAt: now,
    updatedAt: now,
  };
  const db = await getDatabase();
  if (!db) {
    const items = loadFallback();
    items.push(item);
    saveFallback(items);
    return item;
  }
  await db.execute(
    "INSERT INTO memory_items (id, content, source, importance, enabled, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7)",
    [item.id, item.content, item.source, item.importance, item.enabled ? 1 : 0, item.createdAt, item.updatedAt],
  );
  return item;
}

export async function updateMemory(id: string, patch: Partial<MemoryDraft>): Promise<void> {
  const updatedAt = Date.now();
  const db = await getDatabase();
  if (!db) {
    const items = loadFallback();
    const idx = items.findIndex((m) => m.id === id);
    if (idx === -1) return;
    items[idx] = { ...items[idx], ...patch, updatedAt };
    saveFallback(items);
    return;
  }
  const sets: string[] = [];
  const values: unknown[] = [];
  let i = 1;
  if (patch.content !== undefined) { sets.push(`content = $${i++}`); values.push(patch.content); }
  if (patch.source !== undefined) { sets.push(`source = $${i++}`); values.push(patch.source); }
  if (patch.importance !== undefined) { sets.push(`importance = $${i++}`); values.push(patch.importance); }
  if (patch.enabled !== undefined) { sets.push(`enabled = $${i++}`); values.push(patch.enabled ? 1 : 0); }
  sets.push(`updated_at = $${i++}`);
  values.push(updatedAt);
  values.push(id);
  if (sets.length === 1) return; // nothing but updated_at — no real change
  await db.execute(`UPDATE memory_items SET ${sets.join(", ")} WHERE id = $${i}`, values);
}

export async function deleteMemory(id: string): Promise<void> {
  const db = await getDatabase();
  if (!db) {
    saveFallback(loadFallback().filter((m) => m.id !== id));
    return;
  }
  await db.execute("DELETE FROM memory_items WHERE id = $1", [id]);
}

/** Memories actually eligible to reach the AI Core — enabled only, most
 *  important first, capped so a long memory list can't blow out context. */
export async function getActiveMemoryForContext(limit = 12): Promise<MemoryItem[]> {
  const all = await listMemory();
  return all.filter((m) => m.enabled).slice(0, limit);
}
