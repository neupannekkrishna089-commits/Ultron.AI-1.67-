// Long-term memory — discrete facts ULTRON has been told to remember about
// the user, one at a time. Not a transcript, not automatic: nothing lands
// here unless it's explicitly created (by the user, or later by the AI
// Core proposing a memory the user approves — that flow doesn't exist yet).
//
// Kept separate from:
//  - conversation history (~/lib/ultron Conversation/Message) — the raw
//    back-and-forth, not curated facts,
//  - the Knowledge Vault (~/lib/vault) — reference material the user hands
//    ULTRON, not facts *about* the user,
//  - temporary context — in-flight React state (composer draft, streaming
//    text) that's never persisted at all.

export type MemorySource = "user" | "ai" | "system";

export type MemoryItem = {
  id: string;
  content: string;
  source: MemorySource;
  importance: number; // 1 (trivial) – 5 (critical), used to rank what gets included in context
  enabled: boolean; // disabled memories are kept but never fed to the AI Core
  createdAt: number;
  updatedAt: number;
};

export type MemoryDraft = {
  content: string;
  source?: MemorySource;
  importance?: number;
  enabled?: boolean;
};
