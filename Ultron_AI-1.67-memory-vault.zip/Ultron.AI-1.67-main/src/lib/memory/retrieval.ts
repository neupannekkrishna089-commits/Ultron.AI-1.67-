// Context retrieval — decides what from the Knowledge Vault and long-term
// memory (if anything) is relevant enough to include for a given question,
// and formats it as a clearly-labeled context block. Conversation history
// itself is NOT handled here (see ~/lib/ai/context.ts buildContext) — this
// module only covers user-provided knowledge and memory.
//
// Retrieval today is plain keyword overlap — good enough to be genuinely
// useful for a personal vault of modest size, and honest about not being
// semantic search. `embedding` columns already exist on memory_items and
// vault_items (see the SQLite migration) so a real vector index can replace
// `scoreByKeywordOverlap` later without changing the table schema or the
// call sites in ~/lib/ai/router.ts.

import { searchVault } from "~/lib/vault/store";
import type { VaultItem } from "~/lib/vault/types";
import { getActiveMemoryForContext } from "~/lib/memory/store";

const MAX_VAULT_RESULTS = 4;
const MAX_CONTENT_CHARS = 600; // per vault item — avoid one huge note dominating the prompt

function tokenize(s: string): string[] {
  return s
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter((t) => t.length > 2);
}

function scoreByKeywordOverlap(query: string[], haystack: string): number {
  const hay = haystack.toLowerCase();
  let score = 0;
  for (const term of query) if (hay.includes(term)) score += 1;
  return score;
}

async function retrieveRelevantVaultItems(query: string, limit = MAX_VAULT_RESULTS): Promise<VaultItem[]> {
  const terms = tokenize(query);
  if (terms.length === 0) return [];
  const candidates = await searchVault(""); // full list; scored/ranked below rather than SQL LIKE-only matching
  return candidates
    .map((item) => ({ item, score: scoreByKeywordOverlap(terms, `${item.title} ${item.content} ${item.tags.join(" ")}`) }))
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((r) => r.item);
}

/** Builds the "user-provided knowledge" + "user memory" context block for a
 *  question — empty string if nothing relevant was found, so an unrelated
 *  question doesn't drag in vault content that has nothing to do with it. */
export async function buildKnowledgeContext(query: string): Promise<string> {
  const [vaultMatches, memories] = await Promise.all([
    retrieveRelevantVaultItems(query),
    getActiveMemoryForContext(),
  ]);

  const sections: string[] = [];

  if (memories.length > 0) {
    sections.push(
      "What you remember about the user (only what's enabled below — nothing here was inferred automatically):\n" +
        memories.map((m) => `- ${m.content}`).join("\n"),
    );
  }

  if (vaultMatches.length > 0) {
    sections.push(
      "Relevant material the user has added to their Knowledge Vault (use only if it actually helps answer the question):\n" +
        vaultMatches
          .map((v) => {
            const content =
              v.content.length > MAX_CONTENT_CHARS ? v.content.slice(0, MAX_CONTENT_CHARS) + "…" : v.content;
            return `[${v.category}] ${v.title}\n${content}`;
          })
          .join("\n\n"),
    );
  }

  // Placeholder for a future section — deliberately not implemented:
  // web research results would be labeled and appended here, clearly
  // separated from user-provided knowledge, once that system exists.

  return sections.join("\n\n");
}
