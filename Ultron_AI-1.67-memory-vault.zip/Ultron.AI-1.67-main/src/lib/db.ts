// Shared SQLite connection for ULTRON's structured tables — memory_items,
// vault_items, personalization_instructions (see the migration in
// src-tauri/src/lib.rs). This is deliberately separate from the kv_store
// wrapper in ~/lib/storage: that one holds opaque JSON blobs (conversations,
// settings); these tables have real columns and are queried/filtered
// directly (search, importance, enabled/disabled, etc.).
//
// Both connect to the same "sqlite:ultron.db" file — tauri-plugin-sql shares
// the underlying connection per path, so this doesn't open a second
// database.

import { isDesktop } from "~/lib/storage";

type TauriDatabase = {
  select: <T>(query: string, bindValues?: unknown[]) => Promise<T[]>;
  execute: (query: string, bindValues?: unknown[]) => Promise<unknown>;
};

let dbPromise: Promise<TauriDatabase | null> | null = null;

/** Resolves to the shared SQLite connection on desktop, or null in a plain
 *  browser preview (callers fall back to a localStorage-backed store — see
 *  ~/lib/memory/store.ts, ~/lib/vault/store.ts, ~/lib/personalization/store.ts). */
export function getDatabase(): Promise<TauriDatabase | null> {
  if (!isDesktop()) return Promise.resolve(null);
  if (!dbPromise) {
    dbPromise = (async () => {
      try {
        const { default: Database } = await import("@tauri-apps/plugin-sql");
        return (await Database.load("sqlite:ultron.db")) as unknown as TauriDatabase;
      } catch (err) {
        console.error("[ultron/db] failed to open SQLite database", err);
        return null;
      }
    })();
  }
  return dbPromise;
}

export type { TauriDatabase };
