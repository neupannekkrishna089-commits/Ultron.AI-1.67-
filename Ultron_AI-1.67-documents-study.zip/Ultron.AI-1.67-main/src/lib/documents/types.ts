// Document Intelligence types.
//
// A DocumentRecord is one ingested file (PDF/DOCX/TXT/MD/image); its text
// is split into DocumentChunks for retrieval (see chunk.ts/retrieval.ts) —
// the whole document is never sent to the AI Core at once (see
// ~/lib/ai/router.ts, which only receives retrieved chunks).

export type DocumentFileType = "pdf" | "docx" | "txt" | "md" | "image";
export type DocumentStatus = "ready" | "pending_vision" | "error";

export type DocumentRecord = {
  id: string;
  title: string;
  fileName: string;
  fileType: DocumentFileType;
  sourcePath: string | null;
  category: string;
  status: DocumentStatus;
  statusNote: string | null;
  pageCount: number | null;
  charCount: number | null;
  createdAt: number;
  updatedAt: number;
};

export type DocumentChunk = {
  id: string;
  documentId: string;
  chunkIndex: number;
  section: string | null;
  page: number | null;
  content: string;
};

/** A retrieved chunk with enough of its parent document attached to cite —
 *  title/section/page, per the source-grounding requirement. */
export type RetrievedChunk = DocumentChunk & {
  documentTitle: string;
  score: number;
};
