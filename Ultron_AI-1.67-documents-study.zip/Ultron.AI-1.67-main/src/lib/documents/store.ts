// Document store — CRUD over documents + document_chunks.
//
// Desktop: real SQLite tables (see the migration in src-tauri/src/lib.rs).
// Browser preview: two JSON arrays in localStorage. Same shape either way.

import { getDatabase } from "~/lib/db";
import { chunkText } from "~/lib/documents/chunk";
import type { DocumentChunk, DocumentFileType, DocumentRecord, DocumentStatus } from "~/lib/documents/types";

const DOCS_FALLBACK_KEY = "ultron.documents.v1";
const CHUNKS_FALLBACK_KEY = "ultron.document_chunks.v1";

function uid(prefix: string): string {
  return prefix + "_" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

function loadFallback<T>(key: string): T[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T[]) : [];
  } catch {
    return [];
  }
}

function saveFallback<T>(key: string, items: T[]): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(items));
  } catch {
    // ignore
  }
}

type DocRow = {
  id: string;
  title: string;
  file_name: string;
  file_type: string;
  source_path: string | null;
  category: string;
  status: string;
  status_note: string | null;
  page_count: number | null;
  char_count: number | null;
  created_at: number;
  updated_at: number;
};

function docFromRow(r: DocRow): DocumentRecord {
  return {
    id: r.id,
    title: r.title,
    fileName: r.file_name,
    fileType: r.file_type as DocumentFileType,
    sourcePath: r.source_path,
    category: r.category,
    status: r.status as DocumentStatus,
    statusNote: r.status_note,
    pageCount: r.page_count,
    charCount: r.char_count,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

type ChunkRow = {
  id: string;
  document_id: string;
  chunk_index: number;
  section: string | null;
  page: number | null;
  content: string;
};

function chunkFromRow(r: ChunkRow): DocumentChunk {
  return {
    id: r.id,
    documentId: r.document_id,
    chunkIndex: r.chunk_index,
    section: r.section,
    page: r.page,
    content: r.content,
  };
}

export async function listDocuments(): Promise<DocumentRecord[]> {
  const db = await getDatabase();
  if (!db) return loadFallback<DocumentRecord>(DOCS_FALLBACK_KEY).sort((a, b) => b.updatedAt - a.updatedAt);
  const rows = await db.select<DocRow>("SELECT * FROM documents ORDER BY updated_at DESC");
  return rows.map(docFromRow);
}

export async function getDocumentChunkCount(documentId: string): Promise<number> {
  const db = await getDatabase();
  if (!db) return loadFallback<DocumentChunk>(CHUNKS_FALLBACK_KEY).filter((c) => c.documentId === documentId).length;
  const rows = await db.select<{ n: number }>("SELECT COUNT(*) as n FROM document_chunks WHERE document_id = $1", [
    documentId,
  ]);
  return rows[0]?.n ?? 0;
}

export type IngestInput = {
  title: string;
  fileName: string;
  fileType: DocumentFileType;
  sourcePath: string | null;
  category: string;
  status: DocumentStatus;
  statusNote: string | null;
  pageCount: number | null;
  content: string; // empty for images (pending_vision) or failed extractions
};

/** Stores a document record and chunks its extracted content (if any) into
 *  document_chunks. This is the single write path used by the ingestion
 *  flow — see ~/lib/documents/ingest.ts. */
export async function saveIngestedDocument(input: IngestInput): Promise<DocumentRecord> {
  const now = Date.now();
  const doc: DocumentRecord = {
    id: uid("doc"),
    title: input.title,
    fileName: input.fileName,
    fileType: input.fileType,
    sourcePath: input.sourcePath,
    category: input.category,
    status: input.status,
    statusNote: input.statusNote,
    pageCount: input.pageCount,
    charCount: input.content.length || null,
    createdAt: now,
    updatedAt: now,
  };
  const pieces = input.content.trim() ? chunkText(input.content) : [];
  const chunks: DocumentChunk[] = pieces.map((p) => ({
    id: uid("chunk"),
    documentId: doc.id,
    chunkIndex: p.chunkIndex,
    section: p.section,
    page: null, // page tracking isn't implemented for any format yet — see chunk.ts
    content: p.content,
  }));

  const db = await getDatabase();
  if (!db) {
    saveFallback(DOCS_FALLBACK_KEY, [...loadFallback<DocumentRecord>(DOCS_FALLBACK_KEY), doc]);
    saveFallback(CHUNKS_FALLBACK_KEY, [...loadFallback<DocumentChunk>(CHUNKS_FALLBACK_KEY), ...chunks]);
    return doc;
  }

  await db.execute(
    "INSERT INTO documents (id, title, file_name, file_type, source_path, category, status, status_note, page_count, char_count, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)",
    [
      doc.id,
      doc.title,
      doc.fileName,
      doc.fileType,
      doc.sourcePath,
      doc.category,
      doc.status,
      doc.statusNote,
      doc.pageCount,
      doc.charCount,
      doc.createdAt,
      doc.updatedAt,
    ],
  );
  for (const c of chunks) {
    await db.execute(
      "INSERT INTO document_chunks (id, document_id, chunk_index, section, page, content, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7)",
      [c.id, c.documentId, c.chunkIndex, c.section, c.page, c.content, now],
    );
  }
  return doc;
}

export async function deleteDocument(id: string): Promise<void> {
  const db = await getDatabase();
  if (!db) {
    saveFallback(DOCS_FALLBACK_KEY, loadFallback<DocumentRecord>(DOCS_FALLBACK_KEY).filter((d) => d.id !== id));
    saveFallback(
      CHUNKS_FALLBACK_KEY,
      loadFallback<DocumentChunk>(CHUNKS_FALLBACK_KEY).filter((c) => c.documentId !== id),
    );
    return;
  }
  await db.execute("DELETE FROM document_chunks WHERE document_id = $1", [id]);
  await db.execute("DELETE FROM documents WHERE id = $1", [id]);
}

export async function updateDocumentCategory(id: string, category: string): Promise<void> {
  const updatedAt = Date.now();
  const db = await getDatabase();
  if (!db) {
    const docs = loadFallback<DocumentRecord>(DOCS_FALLBACK_KEY);
    const idx = docs.findIndex((d) => d.id === id);
    if (idx === -1) return;
    docs[idx] = { ...docs[idx], category, updatedAt };
    saveFallback(DOCS_FALLBACK_KEY, docs);
    return;
  }
  await db.execute("UPDATE documents SET category = $1, updated_at = $2 WHERE id = $3", [category, updatedAt, id]);
}

/** All chunks for every "ready" document, paired with their parent doc —
 *  used by retrieval (~/lib/documents/retrieval.ts), which scores/filters
 *  this in JS rather than relying on SQL-level text search. Fine at the
 *  scale a personal study library reaches. */
export async function listAllChunksWithDocs(): Promise<{ chunk: DocumentChunk; doc: DocumentRecord }[]> {
  const docs = await listDocuments();
  const db = await getDatabase();
  const readyDocs = new Map(docs.filter((d) => d.status === "ready").map((d) => [d.id, d]));
  if (readyDocs.size === 0) return [];

  let chunks: DocumentChunk[];
  if (!db) {
    chunks = loadFallback<DocumentChunk>(CHUNKS_FALLBACK_KEY);
  } else {
    const rows = await db.select<ChunkRow>("SELECT * FROM document_chunks");
    chunks = rows.map(chunkFromRow);
  }
  return chunks
    .filter((c) => readyDocs.has(c.documentId))
    .map((chunk) => ({ chunk, doc: readyDocs.get(chunk.documentId)! }));
}
