// Document ingestion — the glue between the native file dialog, Rust
// extraction (src-tauri/src/documents.rs), and storage
// (~/lib/documents/store.ts). This is the only place that orchestrates all
// three; the UI (DocumentsView) just calls `pickAndIngestDocuments`.

import { isDesktop } from "~/lib/storage";
import { saveIngestedDocument } from "~/lib/documents/store";
import type { DocumentFileType, DocumentRecord, DocumentStatus } from "~/lib/documents/types";

type ExtractedDocument = {
  fileName: string;
  fileType: string;
  status: string;
  statusNote: string | null;
  content: string;
  pageCount: number | null;
  charCount: number;
};

function titleFromFileName(fileName: string): string {
  const withoutExt = fileName.replace(/\.[^.]+$/, "");
  return withoutExt.replace(/[_-]+/g, " ").trim() || fileName;
}

/** Opens the native "choose files" dialog and ingests every file the user
 *  picks. Desktop-only — there's no privileged file access to extract from
 *  in a plain browser preview, so this is a no-op there (returns []). */
export async function pickAndIngestDocuments(category: string): Promise<DocumentRecord[]> {
  if (!isDesktop()) return [];

  const { invoke } = await import("@tauri-apps/api/core");
  const paths = await invoke<string[]>("pick_document_files");
  if (!paths || paths.length === 0) return [];

  const results: DocumentRecord[] = [];
  for (const path of paths) {
    try {
      const extracted = await invoke<ExtractedDocument>("extract_document", { path });
      const doc = await saveIngestedDocument({
        title: titleFromFileName(extracted.fileName),
        fileName: extracted.fileName,
        fileType: extracted.fileType as DocumentFileType,
        sourcePath: path,
        category,
        status: extracted.status as DocumentStatus,
        statusNote: extracted.statusNote,
        pageCount: extracted.pageCount,
        content: extracted.content,
      });
      results.push(doc);
    } catch (err) {
      const fileName = path.split(/[/\\]/).pop() ?? path;
      const doc = await saveIngestedDocument({
        title: titleFromFileName(fileName),
        fileName,
        fileType: "txt",
        sourcePath: path,
        category,
        status: "error",
        statusNote: String(err),
        pageCount: null,
        content: "",
      });
      results.push(doc);
    }
  }
  return results;
}
