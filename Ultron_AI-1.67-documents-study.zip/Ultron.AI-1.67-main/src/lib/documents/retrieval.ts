// Document chunk retrieval — same keyword-overlap approach as
// ~/lib/memory/retrieval.ts (see that file's comment for why keyword
// scoring is the deliberate starting point, not semantic/vector search).
// Kept as its own module because documents need per-chunk citation info
// (document title + section + page) that vault/memory retrieval doesn't.

import { listAllChunksWithDocs } from "~/lib/documents/store";
import type { RetrievedChunk } from "~/lib/documents/types";
import { tokenize, scoreByKeywordOverlap } from "~/lib/retrieval-utils";

export async function retrieveRelevantChunks(query: string, limit: number): Promise<RetrievedChunk[]> {
  const terms = tokenize(query);
  if (terms.length === 0) return [];
  const all = await listAllChunksWithDocs();
  return all
    .map(({ chunk, doc }) => ({
      ...chunk,
      documentTitle: doc.title,
      score: scoreByKeywordOverlap(terms, `${doc.title} ${chunk.section ?? ""} ${chunk.content}`),
    }))
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}

/** Formats retrieved chunks as a labeled, cited context block. Empty string
 *  if nothing relevant was found. */
export function formatChunksForContext(chunks: RetrievedChunk[], label: string): string {
  if (chunks.length === 0) return "";
  const body = chunks
    .map((c) => {
      const citation = [c.documentTitle, c.section, c.page ? `p.${c.page}` : null].filter(Boolean).join(" — ");
      return `[${citation}]\n${c.content}`;
    })
    .join("\n\n");
  return `${label}:\n${body}`;
}
