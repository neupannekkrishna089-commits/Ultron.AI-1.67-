// Chunking — splits a document's extracted text into pieces sized for
// retrieval, so the AI Core only ever sees the relevant handful of chunks
// for a question, never the whole document (see ~/lib/documents/retrieval.ts
// and ~/lib/ai/router.ts).
//
// Plain character-length windowing on paragraph/sentence boundaries — no
// tokenizer, no NLP dependency. That's intentionally simple for a
// Celeron-class CPU: this runs once per imported document, not per request.

const TARGET_CHUNK_CHARS = 1000;
const MIN_CHUNK_CHARS = 200; // avoid a trailing sliver chunk with almost nothing in it

export type PlainChunk = {
  chunkIndex: number;
  section: string | null;
  content: string;
};

/** Splits `text` into paragraphs, then greedily packs paragraphs into
 *  chunks up to ~TARGET_CHUNK_CHARS, breaking on a paragraph boundary
 *  whenever possible so a chunk doesn't cut a sentence in half. A single
 *  paragraph longer than the target is further split on sentence
 *  boundaries so one huge block of text still produces retrievable pieces. */
export function chunkText(text: string): PlainChunk[] {
  const paragraphs = text
    .split(/\n{2,}/)
    .map((p) => p.trim())
    .filter(Boolean);

  const pieces: string[] = [];
  for (const para of paragraphs) {
    if (para.length <= TARGET_CHUNK_CHARS * 1.4) {
      pieces.push(para);
    } else {
      pieces.push(...splitLongParagraph(para));
    }
  }

  const chunks: string[] = [];
  let current = "";
  for (const piece of pieces) {
    const candidate = current ? current + "\n\n" + piece : piece;
    if (candidate.length > TARGET_CHUNK_CHARS && current.length >= MIN_CHUNK_CHARS) {
      chunks.push(current);
      current = piece;
    } else {
      current = candidate;
    }
  }
  if (current.trim()) chunks.push(current);

  return chunks.map((content, chunkIndex) => ({ chunkIndex, section: detectSection(content), content }));
}

function splitLongParagraph(para: string): string[] {
  const sentences = para.split(/(?<=[.!?])\s+/);
  const out: string[] = [];
  let current = "";
  for (const s of sentences) {
    const candidate = current ? current + " " + s : s;
    if (candidate.length > TARGET_CHUNK_CHARS && current) {
      out.push(current);
      current = s;
    } else {
      current = candidate;
    }
  }
  if (current) out.push(current);
  return out;
}

/** Best-effort section label: the first line of a chunk if it looks like a
 *  heading (short, no terminal punctuation) — used for citations. Returns
 *  null rather than guessing when nothing heading-like is present. */
function detectSection(content: string): string | null {
  const firstLine = content.split("\n")[0]?.trim() ?? "";
  if (firstLine.length > 0 && firstLine.length <= 80 && !/[.!?]$/.test(firstLine)) {
    return firstLine;
  }
  return null;
}
