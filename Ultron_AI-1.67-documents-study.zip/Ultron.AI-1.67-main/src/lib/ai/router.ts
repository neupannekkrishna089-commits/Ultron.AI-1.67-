// AI Router — decides which provider/model handles a given task, and
// assembles the system instruction that actually reaches the model.
//
// This phase only ever routes CHAT, because that's the only task type that
// exists yet. The other task types are listed so the router's shape is
// already correct when Research/Coding/Document Analysis/Study/Vision/
// Planning/Voice arrive — each will get its own case (e.g. a cheaper/faster
// model for quick chat, a stronger one for coding), without another rewrite
// of this file's signature or its callers.
//
// The system instruction is built from clearly separate, labeled sections —
// per the project's context-retrieval requirement, ULTRON must never blur
// "the user told me this", "I looked this up in the vault", and "the model's
// own knowledge" into one undifferentiated blob:
//   1. Base identity (fixed)
//   2. Personalization instructions (~/lib/personalization — user-editable)
//   3. Retrieved memory + Knowledge Vault context (~/lib/memory/retrieval —
//      only what's relevant to *this* question, never the whole vault)
// Conversation history itself is assembled separately, in
// ~/lib/ai/context.ts, and passed as the `messages` array, not the system
// instruction.

import type { AISettings } from "~/lib/ultron";
import type { AIProviderId, AITaskType } from "~/lib/ai/types";
import { getProvider } from "~/lib/ai/registry";
import { buildPersonalizationBlock } from "~/lib/personalization/store";
import { buildKnowledgeContext } from "~/lib/memory/retrieval";
import { retrieveRelevantChunks, formatChunksForContext } from "~/lib/documents/retrieval";
import { STUDY_MODE_INSTRUCTION } from "~/lib/study/prompts";

const STUDY_DOCUMENT_CHUNK_LIMIT = 10; // heavier than ordinary chat's 3 — see memory/retrieval.ts

export type RoutingDecision = {
  providerId: AIProviderId;
  model: string;
  systemInstruction: string;
};

const BASE_SYSTEM_INSTRUCTION =
  "You are ULTRON, a personal AI assistant running as a Windows desktop app. " +
  "Be direct, concise, and genuinely useful. If you don't know something or " +
  "can't do it yet, say so plainly rather than guessing.";

/** `latestUserMessage` drives context retrieval — pass the message the user
 *  just sent so retrieval can judge relevance against it. Empty string is
 *  fine (e.g. no relevant context needed) and simply retrieves nothing. */
export async function routeTask(
  taskType: AITaskType,
  settings: AISettings,
  latestUserMessage: string,
): Promise<RoutingDecision> {
  // Every case currently resolves similarly except STUDY, which gets its own
  // system instruction and heavier document retrieval. The switch exists so
  // the remaining task types are additions here later, not a restructure.
  switch (taskType) {
    case "STUDY": {
      const [personalization, documentChunks] = await Promise.all([
        buildPersonalizationBlock(),
        retrieveRelevantChunks(latestUserMessage, STUDY_DOCUMENT_CHUNK_LIMIT),
      ]);
      const studyMaterial = formatChunksForContext(documentChunks, "Study material supplied by the user");
      const systemInstruction = [BASE_SYSTEM_INSTRUCTION, STUDY_MODE_INSTRUCTION, personalization, studyMaterial]
        .filter((s) => s.trim().length > 0)
        .join("\n\n---\n\n");

      return {
        providerId: settings.provider,
        model: settings.model || getProvider(settings.provider).defaultModel,
        systemInstruction,
      };
    }
    case "CHAT":
    case "RESEARCH":
    case "CODING":
    case "DOCUMENT_ANALYSIS":
    case "VISION":
    case "PLANNING":
    case "VOICE":
    default: {
      const [personalization, knowledge] = await Promise.all([
        buildPersonalizationBlock(),
        buildKnowledgeContext(latestUserMessage),
      ]);
      const systemInstruction = [BASE_SYSTEM_INSTRUCTION, personalization, knowledge]
        .filter((s) => s.trim().length > 0)
        .join("\n\n---\n\n");

      return {
        providerId: settings.provider,
        model: settings.model || getProvider(settings.provider).defaultModel,
        systemInstruction,
      };
    }
  }
}
