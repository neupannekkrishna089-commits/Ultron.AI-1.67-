// Shared keyword-overlap scoring for retrieval (~/lib/memory/retrieval.ts,
// ~/lib/documents/retrieval.ts). One implementation so a fix here — like the
// stopword filter below — applies everywhere retrieval happens, instead of
// silently drifting between copies.
//
// This is deliberately simple substring/term-overlap scoring, not semantic
// search — see the comment in memory/retrieval.ts for why that's the
// intentional starting point.

// Common English function words excluded from scoring — without this,
// "the"/"and"/"what" etc. match almost any document and cause unrelated
// content to be retrieved just because it shares filler words with the
// query, not because it's actually relevant.
const STOPWORDS = new Set([
  "the", "and", "for", "are", "but", "not", "you", "all", "can", "has",
  "have", "had", "was", "were", "been", "being", "with", "this", "that",
  "these", "those", "what", "when", "where", "which", "who", "why", "how",
  "does", "did", "doing", "will", "would", "should", "could", "about",
  "into", "onto", "from", "than", "then", "them", "they", "their", "there",
  "here", "your", "our", "its", "it's", "and/or", "any", "some", "such",
  "each", "more", "most", "other", "only", "own", "same", "very", "just",
]);

export function tokenize(s: string): string[] {
  return s
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter((t) => t.length > 2 && !STOPWORDS.has(t));
}

export function scoreByKeywordOverlap(queryTerms: string[], haystack: string): number {
  const hay = haystack.toLowerCase();
  let score = 0;
  for (const term of queryTerms) if (hay.includes(term)) score += 1;
  return score;
}
