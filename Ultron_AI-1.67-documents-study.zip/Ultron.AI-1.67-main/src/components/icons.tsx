import type { ReactElement, ReactNode, SVGProps } from "react";

type IconProps = SVGProps<SVGSVGElement> & { size?: number };

function make(children: ReactNode, filled = false): (props: IconProps) => ReactElement {
  return function Icon({ size = 16, ...rest }: IconProps) {
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill={filled ? "currentColor" : "none"}
        stroke="currentColor"
        strokeWidth={2}
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
        {...rest}
      >
        {children}
      </svg>
    );
  };
}

export const IconPlus = make(<path d="M12 5v14M5 12h14" />);
export const IconX = make(<path d="M18 6 6 18M6 6l12 12" />);
export const IconCheck = make(<path d="M20 6 9 17l-5-5" />);
export const IconTrash = make(
  <>
    <path d="M3 6h18" />
    <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
    <path d="M10 11v6M14 11v6" />
  </>,
);
export const IconPaperclip = make(
  <path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />,
);
export const IconMic = make(
  <>
    <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" />
    <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
    <path d="M12 19v4" />
  </>,
);
export const IconSend = make(<path d="M22 2 11 13M22 2l-7 20-4-9-9-4 20-7z" />, true);
export const IconGear = make(
  <>
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.09a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h.09a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.09a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
  </>,
);
export const IconKeyboard = make(
  <>
    <rect x="2" y="6" width="20" height="12" rx="2" />
    <path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M6 14h.01M18 14h.01M9 14h6" />
  </>,
);
export const IconSparkle = make(<path d="M12 3l2.1 5.9L20 11l-5.9 2.1L12 19l-2.1-5.9L4 11l5.9-2.1L12 3z" />, true);
export const IconMinus = make(<path d="M5 12h14" />);
export const IconMaximize = make(
  <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3" />,
);
export const IconClose = make(<path d="M18 6 6 18M6 6l12 12" />);
export const IconStopCircle = make(
  <>
    <circle cx="12" cy="12" r="10" />
    <rect x="9" y="9" width="6" height="6" rx="1" fill="currentColor" stroke="none" />
  </>,
);
export const IconEye = make(
  <>
    <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z" />
    <circle cx="12" cy="12" r="3" />
  </>,
);
export const IconEyeOff = make(
  <>
    <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a17.7 17.7 0 0 1-3.06 4.2M6.16 6.16C3.4 7.9 1.5 10.5 1 12c0 0 4 8 11 8a9.98 9.98 0 0 0 5.14-1.44" />
    <path d="M14.12 14.12a3 3 0 1 1-4.24-4.24M1 1l22 22" />
  </>,
);
export const IconBrain = make(
  <>
    <path d="M9.5 3a3.5 3.5 0 0 0-3.5 3.5v.09A3.5 3.5 0 0 0 4 9.75v.5a3.5 3.5 0 0 0-1 2.6v.5A3.5 3.5 0 0 0 6.5 17H9V6.5A3.5 3.5 0 0 0 9.5 3Z" />
    <path d="M14.5 3a3.5 3.5 0 0 1 3.5 3.5v.09A3.5 3.5 0 0 1 20 9.75v.5a3.5 3.5 0 0 1 1 2.6v.5A3.5 3.5 0 0 1 17.5 17H15V6.5A3.5 3.5 0 0 1 14.5 3Z" />
    <path d="M9 17v2.5A1.5 1.5 0 0 0 10.5 21h0A1.5 1.5 0 0 0 12 19.5V17M15 17v2.5a1.5 1.5 0 0 1-1.5 1.5h0a1.5 1.5 0 0 1-1.5-1.5V17" />
  </>,
);
export const IconVault = make(
  <>
    <rect x="3" y="4" width="18" height="16" rx="2" />
    <circle cx="12" cy="12" r="3.2" />
    <path d="M12 8.8v.5M12 14.7v.5M8.8 12h.5M14.7 12h.5" />
  </>,
);
export const IconSearch = make(
  <>
    <circle cx="11" cy="11" r="7" />
    <path d="m21 21-4.3-4.3" />
  </>,
);
export const IconChevronUp = make(<path d="m18 15-6-6-6 6" />);
export const IconChevronDown = make(<path d="m6 9 6 6 6-6" />);
export const IconPencil = make(
  <path d="M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z" />,
);
export const IconGraduationCap = make(
  <>
    <path d="m22 10-10-5L2 10l10 5 10-5Z" />
    <path d="M6 12v5c0 1.5 2.5 3 6 3s6-1.5 6-3v-5" />
    <path d="M22 10v6" />
  </>,
);
export const IconFileText = make(
  <>
    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2Z" />
    <path d="M14 2v6h6" />
    <path d="M8 13h8M8 17h8M8 9h2" />
  </>,
);
export const IconUpload = make(
  <>
    <path d="M12 3v12" />
    <path d="m7 8 5-5 5 5" />
    <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
  </>,
);
export const IconImage = make(
  <>
    <rect x="3" y="3" width="18" height="18" rx="2" />
    <circle cx="8.5" cy="8.5" r="1.5" />
    <path d="m21 15-5-5L5 21" />
  </>,
);
export const IconAlertCircle = make(
  <>
    <circle cx="12" cy="12" r="10" />
    <path d="M12 8v4M12 16h.01" />
  </>,
);

/**
 * ULTRON identity mark — a graphite badge with a hairline edge and an
 * abstract monogram: two converging strokes that meet at a single crimson
 * point. Deliberately quiet and geometric, not a literal "U" or a solid
 * red tile — reads as a precision instrument rather than a game emblem.
 */
export function ULTRONMark({ size = 22, className }: { size?: number; className?: string }) {
  const id = "um" + Math.round(size * 10);
  return (
    <span
      className={"relative inline-flex shrink-0 items-center justify-center rounded-[7px] " + (className ?? "")}
      style={{
        width: size,
        height: size,
        background: "linear-gradient(155deg, #26272d 0%, #1a1b1f 100%)",
        boxShadow:
          "inset 0 0 0 1px rgba(255,255,255,0.06), inset 0 -1px 1px rgba(0,0,0,0.4), 0 1px 2px rgba(0,0,0,0.35)",
      }}
      aria-hidden="true"
    >
      <svg
        width={Math.round(size * 0.6)}
        height={Math.round(size * 0.6)}
        viewBox="0 0 24 24"
        fill="none"
      >
        <defs>
          <linearGradient id={id} x1="3" y1="4" x2="21" y2="20" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#9aa0aa" />
            <stop offset="100%" stopColor="#dfe1e4" />
          </linearGradient>
        </defs>
        <path
          d="M4 4v8.2C4 16.5 7.6 20 12 20s8-3.5 8-7.8V4"
          stroke={`url(#${id})`}
          strokeWidth={2.1}
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle cx="12" cy="14.4" r="1.35" fill="var(--color-crimson)" />
      </svg>
    </span>
  );
}
