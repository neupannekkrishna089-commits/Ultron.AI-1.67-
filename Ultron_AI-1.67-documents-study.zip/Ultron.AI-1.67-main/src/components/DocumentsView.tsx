import { useEffect, useState } from "react";
import type { DocumentRecord } from "~/lib/documents/types";
import { deleteDocument, listDocuments, updateDocumentCategory } from "~/lib/documents/store";
import { pickAndIngestDocuments } from "~/lib/documents/ingest";
import { isDesktop } from "~/lib/storage";
import {
  IconAlertCircle,
  IconFileText,
  IconImage,
  IconTrash,
  IconUpload,
} from "~/components/icons";

const STATUS_LABEL: Record<DocumentRecord["status"], string> = {
  ready: "Ready",
  pending_vision: "Awaiting image support",
  error: "Failed to read",
};

function fileIcon(fileType: DocumentRecord["fileType"]) {
  return fileType === "image" ? IconImage : IconFileText;
}

export function DocumentsView() {
  const [docs, setDocs] = useState<DocumentRecord[] | null>(null);
  const [category, setCategory] = useState("General");
  const [uploading, setUploading] = useState(false);
  const desktop = isDesktop();

  const refresh = async () => setDocs(await listDocuments());

  useEffect(() => {
    void refresh();
  }, []);

  const onUpload = async () => {
    setUploading(true);
    try {
      await pickAndIngestDocuments(category.trim() || "General");
      await refresh();
    } finally {
      setUploading(false);
    }
  };

  const onDelete = async (id: string) => {
    await deleteDocument(id);
    void refresh();
  };

  const onCategoryEdit = async (id: string, next: string) => {
    await updateDocumentCategory(id, next);
    void refresh();
  };

  return (
    <main className="ultron-canvas ultron-scroll h-full min-w-0 flex-1 overflow-y-auto">
      <div className="mx-auto w-full max-w-2xl px-6 py-10">
        <header className="mb-6 flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[9px] bg-graphite-800 text-crimson ring-1 ring-inset ring-graphite-700">
              <IconFileText size={15} />
            </span>
            <div>
              <h1 className="text-[19px] font-medium tracking-[-0.01em] text-ink">Documents</h1>
              <p className="mt-1 text-[12.5px] text-ink-muted">
                Notes, PDFs, and study material ULTRON can search when answering — split into
                chunks and retrieved only when relevant, never sent whole.
              </p>
            </div>
          </div>
        </header>

        {!desktop && (
          <div className="mb-5 flex items-center gap-2 rounded-[10px] border border-graphite-700 bg-graphite-850/60 px-3.5 py-2.5 text-[12px] text-ink-muted">
            <IconAlertCircle size={13} className="shrink-0" />
            File upload needs privileged filesystem access, only available in the installed
            desktop app — not this browser preview.
          </div>
        )}

        <div className="ultron-elevate mb-5 flex items-center gap-2 rounded-[14px] border border-graphite-700/70 bg-graphite-900 p-4">
          <input
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            placeholder="Category (e.g. Science, History)"
            className="w-full rounded-[9px] border border-graphite-700 bg-graphite-800 px-3 py-2 text-[12.5px] text-ink outline-none transition-colors focus:border-graphite-500 placeholder:text-ink-muted/55"
          />
          <button
            type="button"
            onClick={() => void onUpload()}
            disabled={!desktop || uploading}
            className="flex shrink-0 items-center gap-1.5 rounded-[9px] bg-crimson px-3.5 py-2 text-[12px] font-semibold text-white transition-all duration-150 ease-out hover:bg-crimson-hover active:scale-[0.97] disabled:cursor-not-allowed disabled:bg-graphite-700 disabled:text-ink-muted/40"
          >
            <IconUpload size={13} />
            {uploading ? "Reading…" : "Upload files"}
          </button>
        </div>

        {docs === null ? (
          <p className="text-[12.5px] text-ink-muted">Loading…</p>
        ) : docs.length === 0 ? (
          <p className="rounded-[10px] border border-graphite-700 bg-graphite-850/40 px-4 py-6 text-center text-[12.5px] text-ink-muted">
            No documents yet — upload PDFs, DOCX, TXT, Markdown, or images of notes.
          </p>
        ) : (
          <ul className="space-y-2">
            {docs.map((doc) => {
              const Icon = fileIcon(doc.fileType);
              return (
                <li
                  key={doc.id}
                  className="ultron-elevate rounded-[12px] border border-graphite-700/70 bg-graphite-900 px-4 py-3"
                >
                  <div className="flex items-start gap-3">
                    <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-[8px] bg-graphite-800 text-ink-muted">
                      <Icon size={14} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="truncate text-[13px] font-medium text-ink">{doc.title}</h3>
                        <span
                          className={
                            "shrink-0 rounded-full px-1.5 py-0.5 text-[10px] font-medium " +
                            (doc.status === "ready"
                              ? "bg-graphite-800 text-ink-muted"
                              : doc.status === "error"
                                ? "bg-crimson-soft/50 text-crimson"
                                : "bg-graphite-800 text-ink-muted/70")
                          }
                        >
                          {STATUS_LABEL[doc.status]}
                        </span>
                      </div>
                      <p className="mt-0.5 truncate text-[11px] text-ink-muted">
                        {doc.fileName} · {doc.fileType.toUpperCase()}
                        {doc.charCount ? ` · ${doc.charCount.toLocaleString()} chars` : ""}
                      </p>
                      {doc.statusNote && (
                        <p className="mt-1 text-[11px] leading-snug text-ink-muted/80">{doc.statusNote}</p>
                      )}
                      <input
                        defaultValue={doc.category}
                        onBlur={(e) => {
                          if (e.target.value.trim() && e.target.value !== doc.category) {
                            void onCategoryEdit(doc.id, e.target.value.trim());
                          }
                        }}
                        className="mt-1.5 w-40 rounded-md border border-graphite-700 bg-graphite-800 px-2 py-1 text-[11px] text-ink-soft outline-none focus:border-graphite-500"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => void onDelete(doc.id)}
                      aria-label="Delete document"
                      className="shrink-0 text-ink-muted/60 hover:text-crimson"
                    >
                      <IconTrash size={13} />
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </main>
  );
}
