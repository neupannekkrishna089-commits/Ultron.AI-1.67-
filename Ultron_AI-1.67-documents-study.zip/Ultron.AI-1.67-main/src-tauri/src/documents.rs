// ULTRON Document Intelligence — extraction (Rust side).
//
// Extraction happens here, not in the frontend, for two reasons: privileged
// filesystem access (the native file dialog gives Rust a real path; nothing
// pipes raw file bytes through the JS bridge), and performance — parsing a
// PDF/DOCX in Rust is both faster and lighter on a Celeron-class CPU than
// doing it in JS. Chunking, storage, and retrieval happen on the TypeScript
// side (src/lib/documents) using the same SQLite pattern as memory/vault.
//
// Images are NOT OCR'd yet. Rather than faking extraction, an ingested image
// is stored with status "pending_vision" and empty content — honest about
// what actually happened, with the field this module returns already shaped
// for whichever OCR/vision path gets built later (a local OCR pass or a
// cloud vision call through the same AI Core provider boundary).

use std::path::Path;

use serde::Serialize;

#[derive(Clone, Serialize)]
pub struct ExtractedDocument {
    pub file_name: String,
    pub file_type: String, // "pdf" | "docx" | "txt" | "md" | "image"
    pub status: String,    // "ready" | "pending_vision" | "error"
    pub status_note: Option<String>,
    pub content: String,
    pub page_count: Option<u32>,
    pub char_count: u32,
}

fn classify(ext: &str) -> &'static str {
    match ext.to_ascii_lowercase().as_str() {
        "pdf" => "pdf",
        "docx" => "docx",
        "md" | "markdown" => "md",
        "txt" => "txt",
        "png" | "jpg" | "jpeg" | "webp" | "bmp" | "gif" => "image",
        _ => "txt", // unknown extensions are treated as plain text rather than rejected
    }
}

#[tauri::command]
pub fn extract_document(path: String) -> Result<ExtractedDocument, String> {
    let p = Path::new(&path);
    let file_name = p
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_else(|| path.clone());
    let ext = p.extension().map(|e| e.to_string_lossy().to_string()).unwrap_or_default();
    let file_type = classify(&ext);

    log::info!("[documents] extracting '{file_name}' as {file_type}");

    if file_type == "image" {
        return Ok(ExtractedDocument {
            file_name,
            file_type: file_type.to_string(),
            status: "pending_vision".to_string(),
            status_note: Some(
                "Image text extraction (OCR/vision) isn't implemented yet — the file is \
                 stored, but ULTRON can't read its contents until that pipeline is built."
                    .to_string(),
            ),
            content: String::new(),
            page_count: None,
            char_count: 0,
        });
    }

    let result = match file_type {
        "pdf" => extract_pdf(&path),
        "docx" => extract_docx(&path),
        _ => extract_plain_text(&path), // txt, md, and anything unrecognized
    };

    match result {
        Ok((content, page_count)) => Ok(ExtractedDocument {
            file_name,
            file_type: file_type.to_string(),
            status: "ready".to_string(),
            status_note: None,
            char_count: content.chars().count() as u32,
            content,
            page_count,
        }),
        Err(err) => {
            log::warn!("[documents] extraction failed for '{path}': {err}");
            Ok(ExtractedDocument {
                file_name,
                file_type: file_type.to_string(),
                status: "error".to_string(),
                status_note: Some(err),
                content: String::new(),
                page_count: None,
                char_count: 0,
            })
        }
    }
}

fn extract_plain_text(path: &str) -> Result<(String, Option<u32>), String> {
    std::fs::read_to_string(path)
        .map(|s| (s, None))
        .map_err(|e| format!("Couldn't read file: {e}"))
}

fn extract_pdf(path: &str) -> Result<(String, Option<u32>), String> {
    let text = pdf_extract::extract_text(path).map_err(|e| format!("PDF extraction failed: {e}"))?;
    // Page count isn't extracted yet — pdf-extract's public API for this is
    // uncertain enough (unverified without a compiler in hand) that it's
    // safer to leave it None than guess at a method name. Chunking/retrieval
    // both work fine without it; it just means citations can't say "page N"
    // for PDFs yet (DOCX/TXT/MD never had page numbers to begin with).
    Ok((text, None))
}

fn extract_docx(path: &str) -> Result<(String, Option<u32>), String> {
    let file = std::fs::File::open(path).map_err(|e| format!("Couldn't open file: {e}"))?;
    let mut archive = zip::ZipArchive::new(file).map_err(|e| format!("Not a valid DOCX/zip: {e}"))?;
    let mut xml = String::new();
    {
        let mut doc_xml = archive
            .by_name("word/document.xml")
            .map_err(|_| "DOCX is missing word/document.xml — not a valid Word document.".to_string())?;
        use std::io::Read;
        doc_xml.read_to_string(&mut xml).map_err(|e| format!("Couldn't read document.xml: {e}"))?;
    }
    Ok((docx_xml_to_text(&xml), None))
}

/// Pulls visible text runs (`<w:t>`) out of a DOCX's document.xml, inserting
/// a newline at each paragraph boundary (`<w:p>`). Deliberately minimal —
/// this recovers readable plain text for chunking/retrieval, not a
/// structural document model (no tables-as-tables, no styling).
fn docx_xml_to_text(xml: &str) -> String {
    use quick_xml::events::Event;
    use quick_xml::reader::Reader;

    let mut reader = Reader::from_str(xml);
    reader.config_mut().trim_text(false);

    let mut out = String::new();
    let mut in_text_run = false;
    let mut buf = Vec::new();

    loop {
        match reader.read_event_into(&mut buf) {
            Ok(Event::Start(e)) => {
                let local = e.name().as_ref().to_vec();
                if ends_with_tag(&local, b"t") {
                    in_text_run = true;
                }
            }
            Ok(Event::Text(e)) => {
                if in_text_run {
                    if let Ok(t) = e.unescape() {
                        out.push_str(&t);
                    }
                }
            }
            Ok(Event::End(e)) => {
                let local = e.name().as_ref().to_vec();
                if ends_with_tag(&local, b"t") {
                    in_text_run = false;
                } else if ends_with_tag(&local, b"p") {
                    out.push('\n');
                }
            }
            Ok(Event::Eof) => break,
            Err(_) => break, // malformed XML — return whatever text was recovered so far
            _ => {}
        }
        buf.clear();
    }

    out
}

#[tauri::command]
pub async fn pick_document_files(app: tauri::AppHandle) -> Result<Vec<String>, String> {
    use tauri_plugin_dialog::DialogExt;
    let (tx, rx) = std::sync::mpsc::channel();
    app.dialog()
        .file()
        .add_filter("Documents", &["pdf", "docx", "txt", "md", "markdown", "png", "jpg", "jpeg", "webp"])
        .pick_files(move |paths| {
            let _ = tx.send(paths);
        });
    let paths = rx.recv().map_err(|e| e.to_string())?;
    Ok(paths
        .unwrap_or_default()
        .into_iter()
        .map(|p| p.to_string())
        .collect())
}

/// True if `name` is exactly `suffix` or ends with `:suffix` — matches
/// namespaced XML element names (e.g. `w:t`) without needing a full
/// namespace-aware parser for this narrow use case.
fn ends_with_tag(name: &[u8], suffix: &[u8]) -> bool {
    if name == suffix {
        return true;
    }
    if name.len() > suffix.len() + 1 {
        let (prefix, tail) = name.split_at(name.len() - suffix.len());
        return prefix.ends_with(b":") && tail == suffix;
    }
    false
}
